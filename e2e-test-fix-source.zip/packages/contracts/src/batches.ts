import { z } from 'zod';

import {
  apiDateTimeSchema,
  apiIdentifierSchema,
  createCollectionResponseSchema,
  createResourceResponseSchema,
  paginationQuerySchema,
} from './api';
import { sourceIdentifierSchema } from './season-upload';

export const BATCH_PACKAGE_VERSION = '1.0' as const;
export const BATCH_PACKAGE_VERSIONS = ['1.0', '1.1'] as const;
export const BATCH_MEDIA_TYPES = ['application/json', 'text/csv', 'application/x-ndjson'] as const;
export const BATCH_STATES = [
  'received',
  'stored',
  'validating',
  'rejected',
  'awaiting_review',
  'correction_requested',
  'publishing',
  'published',
  'partially_published',
  'failed',
  'superseded',
] as const;

export const batchReferenceSchema = z.string().uuid();
export const batchMetadataSchema = z
  .object({
    competitionId: apiIdentifierSchema.regex(/^[1-9]\d*$/, 'Expected a positive competition ID.'),
    idempotencyKey: z.string().trim().min(1).max(255),
    packageVersion: z.enum(BATCH_PACKAGE_VERSIONS),
    fileName: z.string().trim().min(1).max(255),
    mediaType: z.enum(BATCH_MEDIA_TYPES),
    replacesBatchReference: batchReferenceSchema.optional(),
  })
  .strict();

export const batchReceiptSchema = z
  .object({
    batchReference: batchReferenceSchema,
    status: z.enum(['stored', 'received']),
    statusUrl: z.string().startsWith('/api/v1/batches/'),
    receivedAt: apiDateTimeSchema,
  })
  .strict();

export const batchReceiptResponseSchema = createResourceResponseSchema(batchReceiptSchema);

export const BATCH_REVIEW_DECISIONS = ['approved', 'rejected', 'returned_for_correction'] as const;

export const batchReviewDecisionSchema = z
  .object({
    decision: z.enum(BATCH_REVIEW_DECISIONS),
    actor: z
      .object({
        accountId: apiIdentifierSchema,
        displayName: z.string().nullable(),
      })
      .strict(),
    decidedAt: apiDateTimeSchema,
    reason: z.string().min(1),
  })
  .strict();

export const batchReviewRequestSchema = z
  .object({
    decision: z.enum(BATCH_REVIEW_DECISIONS),
    reason: z.string().trim().min(1).max(2000),
  })
  .strict()
  .superRefine((value, context) => {
    if (value.decision !== 'approved' && value.reason.length < 10) {
      context.addIssue({
        code: z.ZodIssueCode.too_small,
        minimum: 10,
        type: 'string',
        inclusive: true,
        path: ['reason'],
        message: 'Explain the rejection or correction in at least 10 characters.',
      });
    }
  });

export const batchStatusSchema = z
  .object({
    batchReference: batchReferenceSchema,
    competitionId: apiIdentifierSchema,
    status: z.enum(BATCH_STATES),
    statusUrl: z.string().startsWith('/api/v1/batches/'),
    receivedAt: apiDateTimeSchema,
    updatedAt: apiDateTimeSchema,
    source: z
      .object({
        fileName: z.string().min(1).nullable(),
        checksum: z
          .string()
          .regex(/^[0-9a-f]{64}$/)
          .nullable(),
        packageVersion: z.string().min(1),
        submitter: z
          .object({ accountId: apiIdentifierSchema, displayName: z.string().nullable() })
          .strict(),
      })
      .strict(),
    progress: z
      .object({
        total: z.number().int().nonnegative(),
        processed: z.number().int().nonnegative(),
        accepted: z.number().int().nonnegative(),
        rejected: z.number().int().nonnegative(),
      })
      .strict(),
    counts: z
      .object({
        accepted: z.number().int().nonnegative(),
        rejected: z.number().int().nonnegative(),
        unresolved: z.number().int().nonnegative(),
        duplicate: z.number().int().nonnegative(),
        conflicting: z.number().int().nonnegative(),
      })
      .strict(),
    lineage: z
      .object({
        replacesBatchReference: batchReferenceSchema.nullable(),
        supersededByBatchReference: batchReferenceSchema.nullable(),
      })
      .strict(),
    review: batchReviewDecisionSchema.nullable(),
  })
  .strict();

export const batchStatusResponseSchema = createResourceResponseSchema(batchStatusSchema);
export const batchReviewResponseSchema = createResourceResponseSchema(batchStatusSchema);

export const batchListQuerySchema = paginationQuerySchema.extend({
  status: z.enum(BATCH_STATES).optional(),
});
export const batchListResponseSchema = createCollectionResponseSchema(batchStatusSchema);

export const batchReportQuerySchema = paginationQuerySchema;

export const batchReportLocationSchema = z
  .object({
    filePath: z.string().nullable(),
    sheetName: z.string().nullable(),
    rowNumber: z.number().int().positive().nullable(),
    jsonPath: z.string().nullable(),
    ordinal: z.number().int().nonnegative(),
  })
  .strict();

export const batchReportContextSchema = z
  .object({
    eventReference: z.string().nullable(),
    fixtureId: apiIdentifierSchema.nullable(),
    fixtureLabel: z.string().min(1).nullable(),
    inningsId: apiIdentifierSchema.nullable(),
    overNumber: z.number().int().nonnegative().nullable(),
    positionInOver: z.number().int().nonnegative().nullable(),
    description: z.string().min(1),
  })
  .strict();

export const batchReferenceEntityTypeSchema = z.enum([
  'competition',
  'team',
  'fixture',
  'innings',
  'participant',
]);

/**
 * Why a participant named by the batch could not be onboarded into the new
 * fixture's squad, and therefore which decision a reviewer has to make. A
 * participant is never matched on a name alone, so every value here is a
 * decision rather than a guess the platform could have made for itself.
 */
export const batchFixtureOnboardingUnresolvedReasonSchema = z.enum([
  /** The submitted team is missing, or is not one of the fixture's two teams. */
  'team_not_recognised',
  /** No source identifier, and at most one existing person carries the name. */
  'no_durable_identifier',
  /** No source identifier, and the name belongs to more than one existing person. */
  'ambiguous_name',
  /** An application identifier was supplied but names no existing person. */
  'identifier_not_found',
]);

export const batchReferenceResolutionSchema = z
  .object({
    referencePath: z.string().min(1),
    entityType: batchReferenceEntityTypeSchema,
    state: z.enum(['ambiguous', 'unresolved', 'invalid']),
    submittedReference: z.unknown(),
    reason: z.string().min(1).nullable(),
    requiredAction: z.enum(['select_candidate', 'contact_reviewer', 'onboard_participant']),
    candidates: z.array(
      z
        .object({
          candidateReference: z.string().uuid(),
          label: z.string().min(1),
        })
        .strict(),
    ),
    /**
     * Present when `requiredAction` is `onboard_participant`: the outstanding
     * onboarding task this reference is waiting on. `taskReference` is the
     * handle a decision addresses, and is never derived from anything the
     * decision supplies.
     */
    onboardingTask: z
      .object({
        taskReference: z.string().uuid(),
        reason: batchFixtureOnboardingUnresolvedReasonSchema,
        candidates: z.array(
          z.object({ personId: apiIdentifierSchema, displayName: z.string().min(1) }).strict(),
        ),
      })
      .strict()
      .optional(),
  })
  .strict();

export const batchReportErrorSchema = z
  .object({
    ruleCode: z.string().regex(/^[A-Z][A-Z0-9_]*$/),
    message: z.string().min(1),
    location: batchReportLocationSchema,
    context: batchReportContextSchema,
  })
  .strict();

export const batchPublishedConflictDifferenceSchema = z
  .object({
    fieldPath: z.string().min(1),
    submittedValue: z.unknown(),
    publishedValue: z.unknown(),
  })
  .strict();

export const batchPublishedConflictSchema = z
  .object({
    existingDeliveryId: apiIdentifierSchema,
    existingSourceEventId: z.string().uuid().nullable(),
    correctionPermitted: z.boolean(),
    differences: z.array(batchPublishedConflictDifferenceSchema).min(1),
  })
  .strict();

export const batchConflictResolutionRequestSchema = z
  .object({
    itemOrdinal: z.number().int().nonnegative(),
    existingDeliveryId: apiIdentifierSchema,
    decision: z.enum(['use_existing', 'replace_published']),
    reason: z.string().trim().min(10).max(2000),
  })
  .strict();

export const batchReportItemSchema = z
  .object({
    ordinal: z.number().int().nonnegative(),
    outcome: z.enum(['pending', 'accepted', 'rejected', 'unresolved', 'duplicate', 'conflicting']),
    location: batchReportLocationSchema,
    context: batchReportContextSchema,
    stagedRecordId: apiIdentifierSchema.nullable(),
    acceptedRecordId: apiIdentifierSchema.nullable(),
    operation: z.enum(['upsert', 'correction']).default('upsert'),
    correctionTarget: z
      .object({
        sourceEventId: sourceIdentifierSchema,
        resolvedDeliveryId: apiIdentifierSchema.nullable(),
      })
      .strict()
      .nullable()
      .default(null),
    publishedConflict: batchPublishedConflictSchema.nullable().optional(),
    referenceResolutions: z.array(batchReferenceResolutionSchema),
    errors: z.array(batchReportErrorSchema),
  })
  .strict();

export const batchReportRuleGroupSchema = z
  .object({
    ruleCode: z.string().regex(/^[A-Z][A-Z0-9_]*$/),
    count: z.number().int().positive(),
  })
  .strict();

export const batchFixtureSummarySchema = z
  .object({
    fixtureId: apiIdentifierSchema.nullable(),
    label: z.string().min(1),
    total: z.number().int().nonnegative(),
    accepted: z.number().int().nonnegative(),
    rejected: z.number().int().nonnegative(),
    unresolved: z.number().int().nonnegative(),
  })
  .strict();

export const batchReviewSummarySchema = z
  .object({
    validation: z
      .object({
        accepted: z.number().int().nonnegative(),
        rejected: z.number().int().nonnegative(),
        blockingErrors: z.number().int().nonnegative(),
        duplicate: z.number().int().nonnegative(),
        conflicting: z.number().int().nonnegative(),
      })
      .strict(),
    resolution: z
      .object({
        resolved: z.number().int().nonnegative(),
        ambiguous: z.number().int().nonnegative(),
        unresolved: z.number().int().nonnegative(),
        invalid: z.number().int().nonnegative(),
        proposed: z.number().int().nonnegative(),
      })
      .strict(),
    approvalBlocked: z.boolean(),
    blockingReasons: z.array(z.string().min(1)),
  })
  .strict();

/**
 * One outstanding participant onboarding task, listed once for the batch.
 *
 * The same task also appears as an `onboard_participant` action on every
 * reference waiting on it, which for a player named in three hundred
 * deliveries is three hundred appearances of one decision. This list is that
 * work deduplicated: one entry per decision a reviewer actually has to make.
 */
export const batchParticipantOnboardingTaskSchema = z
  .object({
    taskReference: z.string().uuid(),
    fixtureId: apiIdentifierSchema,
    submittedName: z.string().min(1),
    submittedTeamName: z.string().min(1).nullable(),
    reason: batchFixtureOnboardingUnresolvedReasonSchema,
    candidates: z.array(
      z.object({ personId: apiIdentifierSchema, displayName: z.string().min(1) }).strict(),
    ),
    /**
     * The two teams of this task's fixture, in fixture order.
     *
     * A team decision is checked by exact name against these, so without them
     * a reviewer answering `team_not_recognised` would be typing a name the
     * platform already knows and could simply have offered. Listing them makes
     * that answer a choice between two, which is what it always was.
     */
    teams: z.array(z.object({ teamId: apiIdentifierSchema, name: z.string().min(1) }).strict()),
  })
  .strict();

export const batchReportSchema = z
  .object({
    batch: batchStatusSchema,
    errorGroups: z.array(batchReportRuleGroupSchema),
    reviewSummary: batchReviewSummarySchema,
    fixtureSummaries: z.array(batchFixtureSummarySchema),
    participantOnboarding: z.array(batchParticipantOnboardingTaskSchema),
    acceptedSamples: z.array(batchReportItemSchema).max(15),
    blockingItems: z.array(batchReportItemSchema),
    items: z.array(batchReportItemSchema),
    pagination: z.object({ nextCursor: z.string().min(1).nullable() }).strict(),
    downloadUrl: z.string().startsWith('/api/v1/batches/'),
  })
  .strict();

export const batchReportResponseSchema = createResourceResponseSchema(batchReportSchema);

export const batchReportDownloadSchema = batchReportSchema.omit({
  blockingItems: true,
  pagination: true,
  downloadUrl: true,
});
export const batchReportDownloadResponseSchema =
  createResourceResponseSchema(batchReportDownloadSchema);

export const batchReferenceMappingRequestSchema = z
  .object({
    itemOrdinal: z.number().int().nonnegative(),
    referencePath: z.string().trim().min(1).max(1_000),
    candidateReference: z.string().uuid(),
    decisionKey: z.string().trim().min(1).max(255),
  })
  .strict();

/**
 * One reviewer decision settling one outstanding participant onboarding task.
 *
 * The task is addressed by `taskReference` and never by anything derivable from
 * the answer: supplying an identifier or a team changes what the task's
 * participant key would derive to, so a re-derived handle would match no task.
 *
 * A decision answers two separate questions, and they are not interchangeable.
 * Who the participant is comes from exactly one of `personId`, which picks a
 * candidate the task itself offered, or `sourceId`, which supplies a durable
 * registry identifier; two identities for one participant have no meaning, so
 * both together are refused. Which of the fixture's two teams they belong to
 * comes from `teamName`, which is optional because the submission usually
 * carried a team the fixture recognises.
 *
 * A `team_not_recognised` task is the case that needs both at once: the team
 * the submission carried is missing or is not one of the fixture's two, and the
 * task holds no identity of its own, so neither half can be inferred from the
 * other. That is why `teamName` is not itself an identity, and why a decision
 * carrying it alone is refused rather than accepted and faulted later.
 */
export const batchParticipantOnboardingDecisionSchema = z
  .object({
    taskReference: z.string().uuid(),
    personId: apiIdentifierSchema.optional(),
    sourceId: sourceIdentifierSchema.optional(),
    teamName: z.string().trim().min(1).max(255).optional(),
  })
  .strict()
  .superRefine((value, context) => {
    const identities = [value.personId, value.sourceId].filter(
      (identity) => identity !== undefined,
    );
    if (identities.length !== 1) {
      context.addIssue({
        code: z.ZodIssueCode.custom,
        message: 'Give exactly one of personId or sourceId.',
      });
    }
  });

/**
 * A whole array of decisions is applied together and the batch is revalidated
 * once. One decision per revalidation would mean a season-scale batch with
 * twenty-two outstanding tasks paying for twenty-two full revalidation passes.
 */
export const batchParticipantOnboardingRequestSchema = z
  .object({
    decisionKey: z.string().trim().min(1).max(255),
    decisions: z.array(batchParticipantOnboardingDecisionSchema).min(1).max(200),
  })
  .strict();

export const batchParticipantOnboardingReceiptSchema = z
  .object({
    batchReference: batchReferenceSchema,
    decisionReference: z.string().uuid(),
    status: z.enum(['queued', 'applied']),
    statusUrl: z.string().startsWith('/api/v1/batches/'),
    submittedAt: apiDateTimeSchema,
    /** Tasks this request settled. */
    onboarded: z.number().int().nonnegative(),
    /** Tasks already settled when it arrived, which a replay reports as its whole result. */
    alreadyOnboarded: z.number().int().nonnegative(),
    /** False when nothing changed, because then there is nothing to revalidate. */
    revalidationQueued: z.boolean(),
  })
  .strict();

export const batchParticipantOnboardingResponseSchema = createResourceResponseSchema(
  batchParticipantOnboardingReceiptSchema,
);

export const batchCanonicalFixtureRequestSchema = z
  .object({
    itemOrdinal: z.number().int().nonnegative(),
    referencePath: z.string().trim().min(1).max(1_000),
    decisionKey: z.string().trim().min(1).max(255),
  })
  .strict();

export const batchFixtureOnboardingUnresolvedParticipantSchema = z
  .object({
    name: z.string().min(1),
    teamName: z.string().min(1).optional(),
    reason: batchFixtureOnboardingUnresolvedReasonSchema,
    candidates: z.array(
      z.object({ personId: apiIdentifierSchema, displayName: z.string().min(1) }).strict(),
    ),
  })
  .strict();

export const batchFixtureOnboardingSummarySchema = z
  .object({
    inningsCreated: z.number().int().nonnegative(),
    squadCreated: z.number().int().nonnegative(),
    unresolvedParticipants: z.array(batchFixtureOnboardingUnresolvedParticipantSchema),
  })
  .strict();

export const batchReferenceMappingReceiptSchema = z
  .object({
    batchReference: batchReferenceSchema,
    decisionReference: z.string().uuid(),
    status: z.enum(['queued', 'applied']),
    statusUrl: z.string().startsWith('/api/v1/batches/'),
    submittedAt: apiDateTimeSchema,
    onboarding: batchFixtureOnboardingSummarySchema.optional(),
  })
  .strict();

export const batchReferenceMappingResponseSchema = createResourceResponseSchema(
  batchReferenceMappingReceiptSchema,
);

export type BatchMetadata = z.infer<typeof batchMetadataSchema>;
export type BatchReceiptResponse = z.infer<typeof batchReceiptResponseSchema>;
export type BatchStatusResponse = z.infer<typeof batchStatusResponseSchema>;
export type BatchReviewDecision = z.infer<typeof batchReviewDecisionSchema>;
export type BatchReviewRequest = z.infer<typeof batchReviewRequestSchema>;
export type BatchReviewResponse = z.infer<typeof batchReviewResponseSchema>;
export type BatchConflictResolutionRequest = z.infer<typeof batchConflictResolutionRequestSchema>;
export type BatchStatus = z.infer<typeof batchStatusSchema>;
export type BatchListQuery = z.infer<typeof batchListQuerySchema>;
export type BatchListResponse = z.infer<typeof batchListResponseSchema>;
export type BatchReportQuery = z.infer<typeof batchReportQuerySchema>;
export type BatchReportItem = z.infer<typeof batchReportItemSchema>;
export type BatchReportRuleGroup = z.infer<typeof batchReportRuleGroupSchema>;
export type BatchFixtureSummary = z.infer<typeof batchFixtureSummarySchema>;
export type BatchReportResponse = z.infer<typeof batchReportResponseSchema>;
export type BatchReportDownloadResponse = z.infer<typeof batchReportDownloadResponseSchema>;
export type BatchReferenceEntityType = z.infer<typeof batchReferenceEntityTypeSchema>;
export type BatchReferenceMappingRequest = z.infer<typeof batchReferenceMappingRequestSchema>;
export type BatchCanonicalFixtureRequest = z.infer<typeof batchCanonicalFixtureRequestSchema>;
export type BatchParticipantOnboardingTask = z.infer<typeof batchParticipantOnboardingTaskSchema>;
export type BatchParticipantOnboardingDecision = z.infer<
  typeof batchParticipantOnboardingDecisionSchema
>;
export type BatchParticipantOnboardingRequest = z.infer<
  typeof batchParticipantOnboardingRequestSchema
>;
export type BatchParticipantOnboardingResponse = z.infer<
  typeof batchParticipantOnboardingResponseSchema
>;
export type BatchFixtureOnboardingSummary = z.infer<typeof batchFixtureOnboardingSummarySchema>;
export type BatchReferenceMappingResponse = z.infer<typeof batchReferenceMappingResponseSchema>;
