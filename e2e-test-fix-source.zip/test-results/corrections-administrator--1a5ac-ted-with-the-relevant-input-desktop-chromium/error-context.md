# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: corrections.spec.ts >> administrator correction validation remains associated with the relevant input
- Location: tests/e2e/corrections.spec.ts:284:5

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('radio', { name: /Advanced technical JSON/ })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to main content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - banner [ref=e5]:
    - generic [ref=e6]:
      - link "Stat'sTheGame home" [ref=e7] [cursor=pointer]:
        - /url: /
        - img "Stat'sTheGame" [ref=e9]
      - navigation "Public records" [ref=e10]:
        - button "Explore Data" [ref=e12] [cursor=pointer]: Explore Data ▾
        - link "Downloads" [ref=e13] [cursor=pointer]:
          - /url: /dataset-releases
        - link "API" [ref=e14] [cursor=pointer]:
          - /url: /api
      - generic [ref=e15]:
        - navigation "Account" [ref=e16]:
          - link "Sign in" [ref=e17] [cursor=pointer]:
            - /url: /sign-in
        - generic [ref=e18]:
          - generic [ref=e19]: Theme
          - generic [ref=e20] [cursor=pointer]:
            - checkbox "Switch to Night Match theme" [ref=e21]
            - generic [ref=e24]: Day Match
  - main [ref=e25]:
    - region [ref=e27]:
      - generic [ref=e28]:
        - paragraph [ref=e29]: Supabase managed authentication
        - heading "Login or Sign up" [level=1] [ref=e30]
        - paragraph [ref=e31]: Supabase will securely handle your Google login or sign-up.
        - button "Sign in with Google" [ref=e32] [cursor=pointer]:
          - generic [ref=e38]: Sign in
  - contentinfo [ref=e39]:
    - generic [ref=e40]:
      - generic [ref=e41]:
        - img "Stat'sTheGame" [ref=e43]
        - paragraph [ref=e44]: The game, measured ball by ball.
      - navigation "Footer navigation" [ref=e45]:
        - link "API Explorer" [ref=e46] [cursor=pointer]:
          - /url: /api
        - link "API Documentation" [ref=e47] [cursor=pointer]:
          - /url: https://sports-analytics-tool.pages.dev/api/overview/
        - link "Privacy Notice" [ref=e48] [cursor=pointer]:
          - /url: /privacy
        - link "Terms of Use" [ref=e49] [cursor=pointer]:
          - /url: /terms
        - link "Accessibility" [ref=e50] [cursor=pointer]:
          - /url: /accessibility
```

# Test source

```ts
  24  |   startDate: '2026-08-20',
  25  |   endDate: '2026-08-20',
  26  | };
  27  | 
  28  | /**
  29  |  * The submission page reads its competitions from the competitions API (#779);
  30  |  * an administrator gets the paged list rather than a per-scope read.
  31  |  */
  32  | const competitions = [{ competitionId: '5', name: 'Premier T20' }];
  33  | 
  34  | const events = [
  35  |   {
  36  |     eventId,
  37  |     inningsId: '10',
  38  |     sequenceNumber: 1,
  39  |     overNumber: 0,
  40  |     positionInOver: 0,
  41  |     ballNumber: '0.1',
  42  |     strikerId: '20',
  43  |     nonStrikerId: '21',
  44  |     bowlerId: '22',
  45  |     runs: { offBat: 4, extras: 0, total: 4, nonBoundary: false },
  46  |     extras: {},
  47  |     wickets: [],
  48  |   },
  49  | ];
  50  | 
  51  | function currentUser(role: 'viewer' | 'submitter' | 'admin') {
  52  |   return {
  53  |     user: {
  54  |       id: '17',
  55  |       subject: 'approved-user',
  56  |       displayName: 'Submitter User',
  57  |       role,
  58  |       approvalState: role === 'viewer' ? 'pending' : 'approved',
  59  |       requestedCompetition: role === 'viewer' ? null : { competitionId: '5', name: 'Premier T20' },
  60  |       competitionIds: role === 'viewer' ? [] : ['5'],
  61  |     },
  62  |   };
  63  | }
  64  | 
  65  | function statistics(totalRuns: number) {
  66  |   return {
  67  |     data: {
  68  |       fixtureId: '7',
  69  |       status: 'complete',
  70  |       scope: { superOversIncluded: false },
  71  |       outcome: {
  72  |         kind: 'no_result',
  73  |         winnerCompetitorId: null,
  74  |         winnerCompetitorName: null,
  75  |         eliminatorCompetitorId: null,
  76  |         eliminatorCompetitorName: null,
  77  |         margin: null,
  78  |         method: null,
  79  |         decidedByBowlOut: false,
  80  |       },
  81  |       highestScorers: [],
  82  |       warnings: [],
  83  |       statistics: [
  84  |         {
  85  |           statisticId: '100',
  86  |           fixtureId: '7',
  87  |           scope: 'innings',
  88  |           statisticCode: 'team_total',
  89  |           inningsId: '10',
  90  |           inningsOrdinal: 0,
  91  |           competitorId: '30',
  92  |           competitorName: 'Wanderers',
  93  |           sourceEventCount: 1,
  94  |           metrics: {
  95  |             deliveryRuns: totalRuns,
  96  |             penaltyRuns: 0,
  97  |             totalRuns,
  98  |             wicketsLost: 0,
  99  |             legalBalls: 1,
  100 |             overs: '0.1',
  101 |             runRate: totalRuns * 6,
  102 |             powerplay: null,
  103 |             extras: {
  104 |               total: 0,
  105 |               wides: 0,
  106 |               noBalls: 0,
  107 |               byes: 0,
  108 |               legByes: 0,
  109 |               penaltyRuns: 0,
  110 |             },
  111 |           },
  112 |         },
  113 |       ],
  114 |     },
  115 |   };
  116 | }
  117 | 
  118 | async function fulfill(route: Route, status: number, body: unknown) {
  119 |   await route.fulfill({ status, contentType: 'application/json', body: JSON.stringify(body) });
  120 | }
  121 | 
  122 | async function openAcceptedSubmission(page: Page) {
  123 |   await page.goto('/submissions/new');
> 124 |   await page.getByRole('radio', { name: /Advanced technical JSON/ }).click();
      |                                                                      ^ Error: locator.click: Test timeout of 30000ms exceeded.
  125 | 
  126 |   // Since #779 the page loads fixtures only for the chosen competition, so the
  127 |   // administrator picks the competition and then the fixture rather than
  128 |   // finding one already selected.
  129 |   const fixtureSelector = page.getByLabel('Fixture', { exact: true });
  130 |   await expect(fixtureSelector).toBeDisabled();
  131 |   await page.getByRole('button', { name: 'Show competition options' }).click();
  132 |   await page.getByRole('option', { name: 'Premier T20' }).click();
  133 |   await expect(page.getByRole('combobox', { name: 'Competition' })).toHaveValue('Premier T20');
  134 |   await page.getByRole('button', { name: 'Show fixture options' }).click();
  135 |   await page
  136 |     .getByRole('option', { name: /2026-08-20 — Wanderers v Strikers — Premier T20, 2026 \(T20\)/ })
  137 |     .click();
  138 |   await expect(fixtureSelector).toHaveValue(
  139 |     '2026-08-20 — Wanderers v Strikers — Premier T20, 2026 (T20)',
  140 |   );
  141 | 
  142 |   await page.getByLabel('Delivery events JSON').fill(JSON.stringify(events, null, 2));
  143 |   await page.getByRole('button', { name: 'Submit events' }).click();
  144 |   await expect(page.getByRole('heading', { name: 'Submission accepted' })).toBeFocused();
  145 |   await expect(page.getByRole('button', { name: 'Save correction' })).toBeVisible();
  146 | }
  147 | 
  148 | test.beforeEach(async ({ page }) => {
  149 |   await page.addInitScript(() => {
  150 |     const now = Math.floor(Date.now() / 1_000);
  151 |     window.localStorage.setItem(
  152 |       'sb-e2e-auth-token',
  153 |       JSON.stringify({
  154 |         access_token: 'approved-e2e-token',
  155 |         refresh_token: 'managed-by-supabase',
  156 |         expires_in: 3_600,
  157 |         expires_at: now + 3_600,
  158 |         token_type: 'bearer',
  159 |         user: {
  160 |           id: 'approved-user',
  161 |           aud: 'authenticated',
  162 |           role: 'authenticated',
  163 |           email: 'submitter@example.com',
  164 |           app_metadata: {},
  165 |           user_metadata: {},
  166 |           identities: [],
  167 |           created_at: '2026-08-16T00:00:00.000Z',
  168 |         },
  169 |       }),
  170 |     );
  171 |   });
  172 | });
  173 | 
  174 | test('administrator direct-import correction works by keyboard and refreshes statistics', async ({
  175 |   page,
  176 | }) => {
  177 |   let statisticsRequests = 0;
  178 | 
  179 |   await page.route('**/api/v1/**', async (route) => {
  180 |     const request = route.request();
  181 |     const url = new URL(request.url());
  182 | 
  183 |     if (url.pathname.endsWith('/auth/me')) {
  184 |       await fulfill(route, 200, currentUser('admin'));
  185 |       return;
  186 |     }
  187 |     if (url.pathname.endsWith('/competitions')) {
  188 |       await fulfill(route, 200, { data: competitions, pagination: { nextCursor: null } });
  189 |       return;
  190 |     }
  191 |     if (url.pathname.endsWith('/fixtures')) {
  192 |       await fulfill(route, 200, {
  193 |         data: [fixture],
  194 |         pagination: { nextCursor: null, totalPages: 1 },
  195 |       });
  196 |       return;
  197 |     }
  198 |     if (url.pathname.endsWith('/submissions') && request.method() === 'POST') {
  199 |       await fulfill(route, 201, {
  200 |         data: {
  201 |           submissionId: '300',
  202 |           fixtureId: '7',
  203 |           submitterId: '17',
  204 |           status: 'accepted',
  205 |           receivedAt: '2026-08-16T09:30:00.000Z',
  206 |           schemaVersion: '1.0',
  207 |           eventCount: 1,
  208 |         },
  209 |       });
  210 |       return;
  211 |     }
  212 |     if (url.pathname.endsWith('/participants')) {
  213 |       await fulfill(route, 200, {
  214 |         data: [
  215 |           { participantId: '20', displayName: 'Opening Batter' },
  216 |           { participantId: '21', displayName: 'Non-striker' },
  217 |           { participantId: '22', displayName: 'Opening Bowler' },
  218 |         ],
  219 |         pagination: { nextCursor: null },
  220 |       });
  221 |       return;
  222 |     }
  223 |     if (url.pathname.endsWith('/fixtures/7/statistics')) {
  224 |       statisticsRequests += 1;
```