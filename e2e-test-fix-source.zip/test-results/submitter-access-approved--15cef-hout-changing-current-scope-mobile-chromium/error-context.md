# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: submitter-access.spec.ts >> approved submitter requests an additional competition without changing current scope
- Location: tests/e2e/submitter-access.spec.ts:133:5

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: getByRole('region', { name: 'Submitter access' }).locator('p').filter({ hasText: 'Current competition scope:' })
Expected substring: "Premier T20"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" with timeout 5000ms
  - waiting for getByRole('region', { name: 'Submitter access' }).locator('p').filter({ hasText: 'Current competition scope:' })

```

```yaml
- link "Skip to main content":
  - /url: "#main-content"
- banner:
  - link "Stat'sTheGame home":
    - /url: /
    - img "Stat'sTheGame"
  - text: Theme
  - checkbox "Switch to Night Match theme"
  - text: Day Match
  - button "Menu"
- main:
  - region "Account":
    - paragraph: Identity and access
    - heading "Account" [level=1]
    - paragraph:
      - text: You are signed out.
      - link "Login or Sign up":
        - /url: /sign-in
      - text: to view your account.
- contentinfo:
  - img "Stat'sTheGame"
  - paragraph: The game, measured ball by ball.
  - navigation "Footer navigation":
    - link "API Explorer":
      - /url: /api
    - link "API Documentation":
      - /url: https://sports-analytics-tool.pages.dev/api/overview/
    - link "Privacy Notice":
      - /url: /privacy
    - link "Terms of Use":
      - /url: /terms
    - link "Accessibility":
      - /url: /accessibility
```

# Test source

```ts
  93  |     await expect(competitionSelect).toBeVisible();
  94  |     await expect(competitionSelect.locator('option')).toHaveText([
  95  |       'Premier T20',
  96  |       'University League',
  97  |     ]);
  98  |     await competitionSelect.selectOption('8');
  99  |     await expect(accessPanel.getByRole('combobox', { name: /fixture/i })).toHaveCount(0);
  100 | 
  101 |     const requestButton = page.getByRole('button', { name: 'Request submitter access' });
  102 |     await expect(requestButton).toBeVisible();
  103 |     await requestButton.focus();
  104 |     await expect(requestButton).toBeFocused();
  105 |     await page.keyboard.press('Enter');
  106 | 
  107 |     await expect(page.getByText('Pending approval')).toBeVisible();
  108 |     await expect(
  109 |       page
  110 |         .locator('.submitter-access-panel__message')
  111 |         .filter({ hasText: /request for University League.*awaiting administrator/i }),
  112 |     ).toBeVisible();
  113 |     await expect(requestButton).toHaveCount(0);
  114 | 
  115 |     await page.reload();
  116 | 
  117 |     await expect(page.getByText('Pending approval')).toBeVisible();
  118 |     await expect(requestButton).toHaveCount(0);
  119 | 
  120 |     const hasHorizontalOverflow = await page.evaluate(
  121 |       () => document.documentElement.scrollWidth > document.documentElement.clientWidth,
  122 |     );
  123 |     expect(hasHorizontalOverflow).toBe(false);
  124 | 
  125 |     const results = await new AxeBuilder({ page }).analyze();
  126 |     const seriousOrCriticalViolations = results.violations.filter(
  127 |       (violation) => violation.impact === 'serious' || violation.impact === 'critical',
  128 |     );
  129 |     expect(seriousOrCriticalViolations).toEqual([]);
  130 |   },
  131 | );
  132 | 
  133 | test(
  134 |   'approved submitter requests an additional competition without changing current scope',
  135 |   { tag: '@mobile' },
  136 |   async ({ page }) => {
  137 |     let requestedCompetition: { competitionId: string; name: string } | null = null;
  138 | 
  139 |     await page.route('**/api/v1/auth/me', async (route) => {
  140 |       await route.fulfill({
  141 |         status: 200,
  142 |         contentType: 'application/json',
  143 |         body: JSON.stringify({
  144 |           user: {
  145 |             id: '17',
  146 |             subject: 'requesting-user',
  147 |             displayName: 'Approved Submitter',
  148 |             role: 'submitter',
  149 |             approvalState: 'approved',
  150 |             requestedCompetition,
  151 |             competitionIds: ['5'],
  152 |           },
  153 |         }),
  154 |       });
  155 |     });
  156 | 
  157 |     await page.route('**/api/v1/competitions?*', async (route) => {
  158 |       await route.fulfill({
  159 |         status: 200,
  160 |         contentType: 'application/json',
  161 |         body: JSON.stringify({
  162 |           data: [
  163 |             { competitionId: '5', name: 'Premier T20' },
  164 |             { competitionId: '8', name: 'University League' },
  165 |           ],
  166 |           pagination: { nextCursor: null },
  167 |         }),
  168 |       });
  169 |     });
  170 | 
  171 |     await page.route('**/api/v1/submitter-scope-requests', async (route) => {
  172 |       expect(route.request().method()).toBe('POST');
  173 |       expect(route.request().headers().authorization).toBe('Bearer requesting-e2e-token');
  174 |       expect(route.request().postDataJSON()).toEqual({ competitionId: '8' });
  175 |       requestedCompetition = { competitionId: '8', name: 'University League' };
  176 | 
  177 |       await route.fulfill({
  178 |         status: 201,
  179 |         contentType: 'application/json',
  180 |         body: JSON.stringify({
  181 |           data: {
  182 |             accountId: '17',
  183 |             requestedCompetition,
  184 |           },
  185 |         }),
  186 |       });
  187 |     });
  188 | 
  189 |     await page.goto('/account/access');
  190 | 
  191 |     const accessPanel = page.getByRole('region', { name: 'Submitter access' });
  192 |     const currentScope = accessPanel.locator('p').filter({ hasText: 'Current competition scope:' });
> 193 |     await expect(currentScope).toContainText('Premier T20');
      |                                ^ Error: expect(locator).toContainText(expected) failed
  194 | 
  195 |     const requestButton = accessPanel.getByRole('button', {
  196 |       name: 'Request additional competition',
  197 |     });
  198 |     await expect(accessPanel.getByRole('combobox', { name: 'Additional competition' })).toHaveCount(
  199 |       0,
  200 |     );
  201 |     await requestButton.focus();
  202 |     await expect(requestButton).toBeFocused();
  203 |     await page.keyboard.press('Enter');
  204 | 
  205 |     const dialog = page.getByRole('dialog', { name: 'Request additional competition' });
  206 |     await expect(dialog).toBeVisible();
  207 |     const competitionSelect = dialog.getByRole('combobox', { name: 'Additional competition' });
  208 |     await expect(competitionSelect).toBeFocused();
  209 |     await expect(competitionSelect.locator('option')).toHaveText(['University League']);
  210 |     await expect(competitionSelect.locator('option[value="5"]')).toHaveCount(0);
  211 | 
  212 |     await page.keyboard.press('Escape');
  213 |     await expect(dialog).toHaveCount(0);
  214 |     await expect(requestButton).toBeFocused();
  215 | 
  216 |     await requestButton.click();
  217 |     await expect(dialog).toBeVisible();
  218 |     const confirmButton = dialog.getByRole('button', { name: 'Request competition' });
  219 |     await confirmButton.click();
  220 | 
  221 |     await expect(dialog).toHaveCount(0);
  222 |     await expect(
  223 |       accessPanel.getByText(/Additional scope request pending for University League/i),
  224 |     ).toBeVisible();
  225 |     await expect(accessPanel.getByText(/existing submission access is unchanged/i)).toBeVisible();
  226 |     await expect(requestButton).toHaveCount(0);
  227 |     await expect(currentScope).toContainText('Premier T20');
  228 | 
  229 |     await page.reload();
  230 | 
  231 |     await expect(
  232 |       page
  233 |         .getByRole('region', { name: 'Submitter access' })
  234 |         .getByText(/Additional scope request pending for University League/i),
  235 |     ).toBeVisible();
  236 |     await expect(
  237 |       page
  238 |         .getByRole('region', { name: 'Submitter access' })
  239 |         .getByRole('button', { name: 'Request additional competition' }),
  240 |     ).toHaveCount(0);
  241 | 
  242 |     const hasHorizontalOverflow = await page.evaluate(
  243 |       () => document.documentElement.scrollWidth > document.documentElement.clientWidth,
  244 |     );
  245 |     expect(hasHorizontalOverflow).toBe(false);
  246 | 
  247 |     const results = await new AxeBuilder({ page }).analyze();
  248 |     const seriousOrCriticalViolations = results.violations.filter(
  249 |       (violation) => violation.impact === 'serious' || violation.impact === 'critical',
  250 |     );
  251 |     expect(seriousOrCriticalViolations).toEqual([]);
  252 |   },
  253 | );
  254 | 
```