# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: batch-review-workspace.spec.ts >> reviewer sees a generic failure, then keeps the published delivery
- Location: tests/e2e/batch-review-workspace.spec.ts:462:5

# Error details

```
Error: expect(locator).toContainText(expected) failed

Locator: locator('.published-conflict-resolution').getByRole('row', { name: /ballNumber/ })
Expected substring: "5.2"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toContainText" with timeout 5000ms
  - waiting for locator('.published-conflict-resolution').getByRole('row', { name: /ballNumber/ })

```

```yaml
- link "Skip to main content":
  - /url: "#main-content"
- banner:
  - link "Stat'sTheGame home":
    - /url: /
    - img "Stat'sTheGame"
  - navigation "Public records":
    - button "Explore Data"
    - link "Downloads":
      - /url: /dataset-releases
    - link "API":
      - /url: /api
  - navigation "Account":
    - link "Sign in":
      - /url: /sign-in
  - text: Theme
  - checkbox "Switch to Night Match theme"
  - text: Day Match
- main:
  - region "Login or Sign up":
    - paragraph: Supabase managed authentication
    - heading "Login or Sign up" [level=1]
    - paragraph: Supabase will securely handle your Google login or sign-up.
    - button "Sign in with Google"
- contentinfo:
  - img "Stat'sTheGame"
  - paragraph: The game, measured ball by ball.
  - navigation "Footer navigation":
    - link "API Explorer":
      - /url: /api
    - link "API Documentation":
      - /url: https://sports-analytics-tool.pages.dev/api/overview/
    - link "Privacy Notice":
      - /url: /privacy
    - link "Terms of Use":
      - /url: /terms
    - link "Accessibility":
      - /url: /accessibility
```

# Test source

```ts
  514 |           validation: {
  515 |             accepted: 0,
  516 |             rejected: kept ? 0 : 1,
  517 |             blockingErrors: kept ? 0 : 1,
  518 |             duplicate: kept ? 1 : 0,
  519 |             conflicting: kept ? 0 : 1,
  520 |           },
  521 |           resolution: { resolved: 1, ambiguous: 0, unresolved: 0, invalid: 0, proposed: 0 },
  522 |           approvalBlocked: !kept,
  523 |           blockingReasons: kept
  524 |             ? []
  525 |             : ['Blocking validation errors remain.', 'Conflicting records remain.'],
  526 |         },
  527 |         fixtureSummaries: [
  528 |           {
  529 |             fixtureId: '22',
  530 |             label: 'Lions vs Bears · 2026-09-01',
  531 |             total: 1,
  532 |             accepted: 0,
  533 |             rejected: kept ? 0 : 1,
  534 |             unresolved: 0,
  535 |           },
  536 |         ],
  537 |         participantOnboarding: [],
  538 |         acceptedSamples: [],
  539 |         items: [
  540 |           {
  541 |             ordinal: 0,
  542 |             outcome: kept ? 'duplicate' : 'conflicting',
  543 |             location,
  544 |             context,
  545 |             stagedRecordId: '41',
  546 |             acceptedRecordId: kept ? '2342246' : null,
  547 |             operation: 'upsert',
  548 |             correctionTarget: null,
  549 |             publishedConflict: kept
  550 |               ? null
  551 |               : {
  552 |                   existingDeliveryId: '2342246',
  553 |                   existingSourceEventId: null,
  554 |                   correctionPermitted: true,
  555 |                   differences: [
  556 |                     { fieldPath: 'ballNumber', submittedValue: '5.2', publishedValue: '5.1' },
  557 |                   ],
  558 |                 },
  559 |             referenceResolutions: [],
  560 |             errors: kept
  561 |               ? []
  562 |               : [
  563 |                   {
  564 |                     ruleCode: 'PUBLISHED_DELIVERY_CONFLICT',
  565 |                     message:
  566 |                       'A published delivery or published source identity exists with different cricket content.',
  567 |                     location,
  568 |                     context,
  569 |                   },
  570 |                 ],
  571 |           },
  572 |         ],
  573 |         pagination: { nextCursor: null },
  574 |         downloadUrl: `/api/v1/batches/${reference}/report/download`,
  575 |       },
  576 |     };
  577 |     return {
  578 |       data: {
  579 |         ...response.data,
  580 |         blockingItems: kept ? [] : response.data.items,
  581 |       },
  582 |     };
  583 |   };
  584 | 
  585 |   await page.route(`**/api/v1/batches/${reference}/report`, async (route) => {
  586 |     await route.fulfill({
  587 |       status: 200,
  588 |       contentType: 'application/json',
  589 |       body: JSON.stringify(report()),
  590 |     });
  591 |   });
  592 |   await page.route(`**/api/v1/batches/${reference}/conflicts/resolve`, async (route) => {
  593 |     requests.push(route.request().postDataJSON());
  594 |     if (requests.length === 1) {
  595 |       await route.fulfill({
  596 |         status: 500,
  597 |         contentType: 'application/json',
  598 |         body: JSON.stringify({
  599 |           error: { code: 'INTERNAL_SERVER_ERROR', message: 'An unexpected server error occurred.' },
  600 |         }),
  601 |       });
  602 |       return;
  603 |     }
  604 |     kept = true;
  605 |     await route.fulfill({
  606 |       status: 200,
  607 |       contentType: 'application/json',
  608 |       body: JSON.stringify({ data: batch() }),
  609 |     });
  610 |   });
  611 | 
  612 |   await page.goto(`/reviews/batches/${reference}`);
  613 |   const conflictCard = page.locator('.published-conflict-resolution');
> 614 |   await expect(conflictCard.getByRole('row', { name: /ballNumber/ })).toContainText('5.2');
      |                                                                       ^ Error: expect(locator).toContainText(expected) failed
  615 | 
  616 |   await page.getByLabel('Resolution reason').fill('The published delivery is the verified record.');
  617 |   await page.getByRole('button', { name: 'Keep published delivery' }).click();
  618 | 
  619 |   await expect(conflictCard.getByRole('status')).toHaveText(
  620 |     'The published-delivery conflict could not be resolved.',
  621 |   );
  622 |   await expect(page.getByText(/INTERNAL_SERVER_ERROR|unexpected server error/)).toHaveCount(0);
  623 |   await expect(conflictCard).toHaveCount(1);
  624 | 
  625 |   await page.getByRole('button', { name: 'Keep published delivery' }).click();
  626 | 
  627 |   await expect(conflictCard).toHaveCount(0);
  628 |   await page.getByRole('tab', { name: 'Review decision' }).click();
  629 |   await expect(page.getByRole('button', { name: 'Approve and publish' })).toBeEnabled();
  630 |   const expectedRequest = {
  631 |     itemOrdinal: 0,
  632 |     existingDeliveryId: '2342246',
  633 |     decision: 'use_existing',
  634 |     reason: 'The published delivery is the verified record.',
  635 |   };
  636 |   expect(requests).toEqual([expectedRequest, expectedRequest]);
  637 | });
  638 | 
  639 | test('reviewer onboards participants in one submission and corrects every fault @mobile', async ({
  640 |   page,
  641 | }) => {
  642 |   const ambiguous = '0b6f2f6e-6f6c-4a1a-9d0f-2a1d3c4b5e6f';
  643 |   const teamTask = '1c7f3a2b-4d5e-4f6a-8b9c-0d1e2f3a4b5c';
  644 |   let settled = false;
  645 | 
  646 |   const report = () => ({
  647 |     data: {
  648 |       batch: {
  649 |         batchReference: reference,
  650 |         competitionId: '5',
  651 |         status: 'awaiting_review',
  652 |         statusUrl: `/api/v1/batches/${reference}`,
  653 |         receivedAt: '2026-09-08T08:00:00.000Z',
  654 |         updatedAt: '2026-09-08T08:05:00.000Z',
  655 |         source: {
  656 |           fileName: 'season.csv',
  657 |           checksum: 'b'.repeat(64),
  658 |           packageVersion: '1.1',
  659 |           submitter: { accountId: '7', displayName: 'Data Submitter' },
  660 |         },
  661 |         progress: { total: 3, processed: 3, accepted: 0, rejected: 0 },
  662 |         counts: { accepted: 0, rejected: 0, unresolved: 3, duplicate: 0, conflicting: 0 },
  663 |         lineage: { replacesBatchReference: null, supersededByBatchReference: null },
  664 |         review: null,
  665 |       },
  666 |       errorGroups: [],
  667 |       reviewSummary: {
  668 |         validation: { accepted: 0, rejected: 0, blockingErrors: 0, duplicate: 0, conflicting: 0 },
  669 |         resolution: { resolved: 0, ambiguous: 0, unresolved: 3, invalid: 0, proposed: 0 },
  670 |         approvalBlocked: true,
  671 |         blockingReasons: ['Unresolved references remain.'],
  672 |       },
  673 |       fixtureSummaries: [
  674 |         {
  675 |           fixtureId: '22',
  676 |           label: 'Lions vs Bears · 2026-09-01',
  677 |           total: 3,
  678 |           accepted: 0,
  679 |           rejected: 0,
  680 |           unresolved: 3,
  681 |         },
  682 |       ],
  683 |       // Settled tasks leave the list, which is how the reviewer sees the work
  684 |       // shrink rather than having to remember what they already answered.
  685 |       participantOnboarding: settled
  686 |         ? []
  687 |         : [
  688 |             {
  689 |               taskReference: ambiguous,
  690 |               fixtureId: '22',
  691 |               submittedName: 'A. Smith',
  692 |               submittedTeamName: 'Lions',
  693 |               reason: 'ambiguous_name',
  694 |               candidates: [
  695 |                 { personId: '11', displayName: 'Alan Smith' },
  696 |                 { personId: '12', displayName: 'Amy Smith' },
  697 |               ],
  698 |               teams: [
  699 |                 { teamId: '30', name: 'Lions' },
  700 |                 { teamId: '31', name: 'Bears' },
  701 |               ],
  702 |             },
  703 |             {
  704 |               taskReference: teamTask,
  705 |               fixtureId: '22',
  706 |               submittedName: 'C. Khumalo',
  707 |               submittedTeamName: 'Wanderers',
  708 |               // The case deployed acceptance testing could not settle: the
  709 |               // reason is not team_not_recognised, but the submitted team is
  710 |               // still not one of the fixture's two, so the decision fails on
  711 |               // the team and the card has to offer that choice anyway.
  712 |               reason: 'no_durable_identifier',
  713 |               candidates: [{ personId: '13', displayName: 'Chris Khumalo' }],
  714 |               teams: [
```