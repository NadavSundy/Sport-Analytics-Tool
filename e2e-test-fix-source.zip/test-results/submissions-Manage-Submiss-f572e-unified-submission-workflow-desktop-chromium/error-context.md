# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: submissions.spec.ts >> Manage Submission opens the unified submission workflow
- Location: tests/e2e/submissions.spec.ts:168:5

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: 'Manage Submission' })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to main content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - banner [ref=e5]:
    - generic [ref=e6]:
      - link "Stat'sTheGame home" [ref=e7] [cursor=pointer]:
        - /url: /
        - img "Stat'sTheGame" [ref=e9]
      - navigation "Public records" [ref=e10]:
        - button "Explore Data" [ref=e12] [cursor=pointer]: Explore Data ▾
        - link "Downloads" [ref=e13] [cursor=pointer]:
          - /url: /dataset-releases
        - link "API" [ref=e14] [cursor=pointer]:
          - /url: /api
      - generic [ref=e15]:
        - navigation "Account" [ref=e16]:
          - link "Sign in" [ref=e17] [cursor=pointer]:
            - /url: /sign-in
        - generic [ref=e18]:
          - generic [ref=e19]: Theme
          - generic [ref=e20] [cursor=pointer]:
            - checkbox "Switch to Night Match theme" [ref=e21]
            - generic [ref=e24]: Day Match
  - main [ref=e25]:
    - region [ref=e27]:
      - generic [ref=e28]:
        - paragraph [ref=e29]: Identity and access
        - heading "Account" [level=1] [ref=e30]
        - paragraph [ref=e31]:
          - text: You are signed out.
          - link "Login or Sign up" [ref=e32] [cursor=pointer]:
            - /url: /sign-in
          - text: to view your account.
  - contentinfo [ref=e33]:
    - generic [ref=e34]:
      - generic [ref=e35]:
        - img "Stat'sTheGame" [ref=e37]
        - paragraph [ref=e38]: The game, measured ball by ball.
      - navigation "Footer navigation" [ref=e39]:
        - link "API Explorer" [ref=e40] [cursor=pointer]:
          - /url: /api
        - link "API Documentation" [ref=e41] [cursor=pointer]:
          - /url: https://sports-analytics-tool.pages.dev/api/overview/
        - link "Privacy Notice" [ref=e42] [cursor=pointer]:
          - /url: /privacy
        - link "Terms of Use" [ref=e43] [cursor=pointer]:
          - /url: /terms
        - link "Accessibility" [ref=e44] [cursor=pointer]:
          - /url: /accessibility
```

# Test source

```ts
  70  |  * fixtures only for the competition that has been chosen, so the fixture
  71  |  * selector starts empty and disabled and a journey that reaches a submit has to
  72  |  * make the selection a submitter would make.
  73  |  */
  74  | async function chooseListedFixture(page: Page) {
  75  |   const competitionSelector = page.getByRole('combobox', { name: 'Competition' });
  76  |   const fixtureSelector = page.getByLabel('Fixture', { exact: true });
  77  | 
  78  |   await expect(fixtureSelector).toBeDisabled();
  79  |   await page.getByRole('button', { name: 'Show competition options' }).click();
  80  |   await page.getByRole('option', { name: 'Example Competition' }).click();
  81  |   await expect(competitionSelector).toHaveValue('Example Competition');
  82  | 
  83  |   await page.getByRole('button', { name: 'Show fixture options' }).click();
  84  |   await page
  85  |     .getByRole('option', {
  86  |       name: /2026-08-20 — Wanderers v Strikers — Example Competition, 2026 \(T20\)/,
  87  |     })
  88  |     .click();
  89  |   await expect(fixtureSelector).toHaveValue(
  90  |     '2026-08-20 — Wanderers v Strikers — Example Competition, 2026 (T20)',
  91  |   );
  92  | }
  93  | 
  94  | test.beforeEach(async ({ page }) => {
  95  |   await page.addInitScript(() => {
  96  |     const now = Math.floor(Date.now() / 1_000);
  97  |     window.localStorage.setItem(
  98  |       'sb-e2e-auth-token',
  99  |       JSON.stringify({
  100 |         access_token: 'approved-e2e-token',
  101 |         refresh_token: 'managed-by-supabase',
  102 |         expires_in: 3_600,
  103 |         expires_at: now + 3_600,
  104 |         token_type: 'bearer',
  105 |         user: {
  106 |           id: 'approved-user',
  107 |           aud: 'authenticated',
  108 |           role: 'authenticated',
  109 |           email: 'submitter@example.com',
  110 |           app_metadata: {},
  111 |           user_metadata: {},
  112 |           identities: [],
  113 |           created_at: '2026-08-16T00:00:00.000Z',
  114 |         },
  115 |       }),
  116 |     );
  117 |   });
  118 | 
  119 |   await page.route('**/api/v1/auth/me', async (route) => {
  120 |     await route.fulfill({
  121 |       status: 200,
  122 |       contentType: 'application/json',
  123 |       body: JSON.stringify({
  124 |         user: {
  125 |           id: '17',
  126 |           subject: 'approved-user',
  127 |           displayName: 'Submitter User',
  128 |           role: 'submitter',
  129 |           approvalState: 'approved',
  130 |           requestedCompetition: { competitionId: '5', name: 'Premier T20' },
  131 |           competitionIds: ['5'],
  132 |         },
  133 |       }),
  134 |     });
  135 |   });
  136 | 
  137 |   await page.route('**/api/v1/competitions?*', async (route) => {
  138 |     await route.fulfill({
  139 |       status: 200,
  140 |       contentType: 'application/json',
  141 |       body: JSON.stringify({
  142 |         data: [
  143 |           { competitionId: '5', name: 'Premier T20' },
  144 |           { competitionId: '8', name: 'University League' },
  145 |         ],
  146 |         pagination: { nextCursor: null },
  147 |       }),
  148 |     });
  149 |   });
  150 | 
  151 |   await page.route('**/api/v1/competitions/5', async (route) => {
  152 |     await route.fulfill({
  153 |       status: 200,
  154 |       contentType: 'application/json',
  155 |       body: JSON.stringify({ data: { competitionId: '5', name: 'Example Competition' } }),
  156 |     });
  157 |   });
  158 | 
  159 |   await page.route('**/api/v1/fixtures?**', async (route) => {
  160 |     await route.fulfill({
  161 |       status: 200,
  162 |       contentType: 'application/json',
  163 |       body: JSON.stringify({ data: [fixture], pagination: { nextCursor: null, totalPages: 1 } }),
  164 |     });
  165 |   });
  166 | });
  167 | 
  168 | test('Manage Submission opens the unified submission workflow', async ({ page }) => {
  169 |   await page.goto('/account/overview');
> 170 |   await page.getByRole('button', { name: 'Manage Submission' }).click();
      |                                                                 ^ Error: locator.click: Test timeout of 30000ms exceeded.
  171 |   await page.getByRole('link', { name: 'Submit data' }).click();
  172 | 
  173 |   await expect(page).toHaveURL(/\/submissions\/new$/);
  174 |   await expect(page.getByRole('heading', { name: 'Submit data' })).toBeVisible();
  175 |   await expect(page.getByRole('radio', { name: /Single fixture/ })).toBeChecked();
  176 |   await expect(page.getByRole('radio', { name: /Season/ })).toBeVisible();
  177 |   await expect(page.getByRole('radio', { name: /Back catalogue/ })).toBeVisible();
  178 |   await expect(page.getByRole('radio', { name: /Advanced technical JSON/ })).toBeVisible();
  179 |   await expect(page.getByRole('link', { name: 'Upload a batch' })).toHaveCount(0);
  180 | 
  181 |   // #500: the guided scopes and the identifier-based mode are separate groups,
  182 |   // and the default guided path shows no JSON editor.
  183 |   const guided = page.getByRole('group', { name: /Guided upload/ });
  184 |   const advanced = page.getByRole('group', { name: /application identifiers required/ });
  185 |   await expect(guided.getByRole('radio')).toHaveCount(3);
  186 |   await expect(guided.getByRole('radio', { name: /Advanced technical JSON/ })).toHaveCount(0);
  187 |   await expect(advanced.getByRole('radio', { name: /Advanced technical JSON/ })).toBeVisible();
  188 |   await expect(page.getByLabel('Delivery events JSON')).toHaveCount(0);
  189 | });
  190 | 
  191 | test('submission workspace uses the centred responsive content boundary', async ({ page }) => {
  192 |   await page.goto('/submissions/new');
  193 | 
  194 |   for (const viewport of [
  195 |     { width: 375, expectedWidth: 351 },
  196 |     { width: 768, expectedWidth: 720 },
  197 |     { width: 1440, expectedWidth: 1200 },
  198 |     { width: 1920, expectedWidth: 1200 },
  199 |   ]) {
  200 |     await page.setViewportSize({ width: viewport.width, height: 900 });
  201 | 
  202 |     const layout = await page.locator('.submission-page').evaluate((element) => {
  203 |       const rect = element.getBoundingClientRect();
  204 |       return {
  205 |         left: Math.round(rect.left),
  206 |         right: Math.round(window.innerWidth - rect.right),
  207 |         width: Math.round(rect.width),
  208 |         overflows: document.documentElement.scrollWidth > document.documentElement.clientWidth,
  209 |       };
  210 |     });
  211 | 
  212 |     expect(layout.width).toBe(viewport.expectedWidth);
  213 |     expect(Math.abs(layout.left - layout.right)).toBeLessThanOrEqual(1);
  214 |     expect(layout.overflows).toBe(false);
  215 |   }
  216 | });
  217 | 
  218 | test('submitter originates a new fixture proposal for reviewer resolution', async ({ page }) => {
  219 |   await page.route('**/api/v1/batches', async (route) => {
  220 |     const request = route.request();
  221 |     expect(request.method()).toBe('POST');
  222 |     expect(request.headers()['x-batch-package-version']).toBe('1.1');
  223 |     expect(request.headers()['x-competition-id']).toBe('5');
  224 |     expect(request.postDataJSON()).toMatchObject({
  225 |       contractVersion: '1.1',
  226 |       competition: { context: { name: 'Example Competition' } },
  227 |       season: { context: { name: '2026' } },
  228 |       fixtures: [
  229 |         {
  230 |           sourceId: expect.stringMatching(/^submitter:fixture:/),
  231 |           context: {
  232 |             date: fixture.startDate,
  233 |             teams: [{ context: { name: 'Wanderers' } }, { context: { name: 'Strikers' } }],
  234 |           },
  235 |           proposal: {
  236 |             endDate: fixture.startDate,
  237 |             matchType: 'T20',
  238 |             teamType: 'club',
  239 |             gender: 'female',
  240 |             ballsPerOver: 6,
  241 |             outcome: 'won',
  242 |             winner: 'Wanderers',
  243 |             sourceVersion: '1',
  244 |             sourceRevision: 0,
  245 |           },
  246 |         },
  247 |       ],
  248 |     });
  249 |     expect(seasonUploadPackageSchema.safeParse(request.postDataJSON()).success).toBe(true);
  250 |     await route.fulfill({
  251 |       status: 202,
  252 |       contentType: 'application/json',
  253 |       body: JSON.stringify({
  254 |         data: {
  255 |           batchReference,
  256 |           status: 'stored',
  257 |           statusUrl: `/api/v1/batches/${batchReference}`,
  258 |           receivedAt: '2026-09-15T09:30:00.000Z',
  259 |         },
  260 |       }),
  261 |     });
  262 |   });
  263 | 
  264 |   await page.goto('/submissions/new');
  265 |   await page.getByRole('button', { name: 'Propose a new fixture' }).click();
  266 |   await expect(page.getByRole('group', { name: 'New fixture metadata' })).toBeVisible();
  267 |   await expect(page.getByRole('combobox', { name: 'Competition' })).toHaveValue(
  268 |     'Example Competition',
  269 |   );
  270 |   await page.getByLabel('Season name').fill('2026');
```