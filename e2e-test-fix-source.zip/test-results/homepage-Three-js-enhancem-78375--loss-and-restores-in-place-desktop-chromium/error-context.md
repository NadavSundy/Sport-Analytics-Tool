# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: homepage.spec.ts >> Three.js enhancement reveals the fallback during context loss and restores in place
- Location: tests/e2e/homepage.spec.ts:187:5

# Error details

```
Error: Three.js should initialise when the browser runtime reports WebGL support.

expect(locator).toHaveAttribute(expected) failed

Locator: locator('[data-hero-enhancement]').locator('.hero-scene')
Expected: "ready"
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Three.js should initialise when the browser runtime reports WebGL support. with timeout 15000ms
  - waiting for locator('[data-hero-enhancement]').locator('.hero-scene')

```

```yaml
- link "Skip to main content":
  - /url: "#main-content"
- banner:
  - link "Stat'sTheGame home":
    - /url: /
    - img "Stat'sTheGame"
  - navigation "Public records":
    - button "Explore Data"
    - link "Downloads":
      - /url: /dataset-releases
    - link "API":
      - /url: /api
  - navigation "Account":
    - link "Sign in":
      - /url: /sign-in
  - text: Theme
  - checkbox "Switch to Night Match theme"
  - text: Day Match
- main:
  - region "The game, measured ball by ball.":
    - paragraph: T20 cricket analytics
    - heading "The game, measured ball by ball." [level=1]
    - paragraph: Explore T20 cricket through the deliveries behind every published statistic, from an individual event to its derived value and traceable source.
    - link "Browse fixtures":
      - /url: /fixtures
    - link "Explore competitions":
      - /url: /competitions
    - link "Browse players":
      - /url: /participants
    - text: Illustrative delivery
    - strong: Event → derived values
  - region "Explosive. Exact. Traceable.":
    - paragraph: How the record moves
    - heading "Explosive. Exact. Traceable." [level=2]
    - paragraph: Broadcast energy, analytical discipline, and a source behind every figure.
    - list:
      - listitem:
        - heading "Explosive" [level=3]
        - paragraph: T20 unfolds delivery by delivery. The interface keeps that event-level pace visible without getting in the way of the record.
      - listitem:
        - heading "Exact" [level=3]
        - paragraph: Runs, balls, wickets and rates are derived from accepted fields and explicit cricket rules—not entered as disconnected totals.
      - listitem:
        - heading "Traceable" [level=3]
        - paragraph: Published fixture statistics retain a calculation path back to the accepted events that contributed to them.
  - region "See the event inside the statistic.":
    - paragraph: One delivery, measured
    - heading "See the event inside the statistic." [level=2]
    - paragraph: This explanatory example uses fields and calculations supported by Stat’sTheGame. It is not a live match or a physical ball path.
    - article:
      - paragraph: Accepted delivery event
      - heading "Delivery 7.3" [level=3]
      - term: Runs off bat
      - definition: "4"
      - term: Extras
      - definition: "0"
      - term: Total
      - definition: "4"
      - code: runs.offBat = 4
    - article:
      - paragraph: Derived contribution
      - heading "Three values move" [level=3]
      - list:
        - listitem:
          - text: Batter runs scored
          - strong: "+4"
        - listitem:
          - text: Innings delivery runs
          - strong: "+4"
        - listitem:
          - text: Bowler runs conceded
          - strong: "+4"
    - paragraph: Traceable source
    - strong: Accepted event retained
    - paragraph: The calculation trace identifies which deliveries contributed to a result.
  - region "Start with the cricket.":
    - paragraph: Enter the public record
    - heading "Start with the cricket." [level=2]
    - paragraph: No account is required to browse published public records.
    - list:
      - listitem:
        - heading "Fixtures" [level=3]
        - paragraph: Open published matches, innings totals, player figures and calculation traces.
        - link "Browse fixtures":
          - /url: /fixtures
      - listitem:
        - heading "Competitions" [level=3]
        - paragraph: Move from a competition into its seasons, teams and published fixtures.
        - link "Explore competitions":
          - /url: /competitions
      - listitem:
        - heading "Players" [level=3]
        - paragraph: Follow a player through named matches with available batting and bowling figures.
        - link "Browse players":
          - /url: /participants
    - paragraph:
      - text: Looking for a side?
      - link "Browse teams":
        - /url: /competitors
      - text: .
  - region "The API is part of the product.":
    - paragraph: The platform beneath the page
    - heading "The API is part of the product." [level=2]
    - paragraph: The same handwritten public API connects fixtures, ordered events and derived statistics. That keeps the record usable in the interface and understandable outside it.
    - list "Existing public API paths":
      - listitem:
        - code: /api/v1/fixtures
        - strong: Published fixtures
      - listitem:
        - code: "/api/v1/fixtures/{fixtureId}/events"
        - strong: Ordered delivery events
      - listitem:
        - code: "/api/v1/fixtures/{fixtureId}/statistics"
        - strong: Derived fixture statistics
  - region "Follow the game from the first ball.":
    - paragraph: First ball to final figure
    - heading "Follow the game from the first ball." [level=2]
    - link "Browse fixtures":
      - /url: /fixtures
- contentinfo:
  - img "Stat'sTheGame"
  - paragraph: The game, measured ball by ball.
  - navigation "Footer navigation":
    - link "API Explorer":
      - /url: /api
    - link "API Documentation":
      - /url: https://sports-analytics-tool.pages.dev/api/overview/
    - link "Privacy Notice":
      - /url: /privacy
    - link "Terms of Use":
      - /url: /terms
    - link "Accessibility":
      - /url: /accessibility
```

# Test source

```ts
  103 |         .getAnimations({ subtree: true })
  104 |         .some((animation) => animation.playState === 'running'),
  105 |     ),
  106 |   ).toBe(false);
  107 | 
  108 |   await page.addInitScript(() => {
  109 |     Object.defineProperty(window, 'WebGLRenderingContext', {
  110 |       configurable: true,
  111 |       value: undefined,
  112 |     });
  113 |   });
  114 |   await page.emulateMedia({ reducedMotion: 'no-preference' });
  115 |   await page.reload();
  116 | 
  117 |   await expect(visual).toHaveAttribute('data-hero-enhancement', 'fallback');
  118 |   await expect(visual.locator('canvas')).toHaveCount(0);
  119 |   await expect(page.getByText('Event → derived values')).toBeVisible();
  120 | });
  121 | 
  122 | test('primary homepage journey works from the keyboard', async ({ page }) => {
  123 |   await page.goto('/');
  124 |   const primaryLink = page.getByRole('link', { name: 'Browse fixtures' }).first();
  125 | 
  126 |   for (let index = 0; index < 16; index += 1) {
  127 |     await page.keyboard.press('Tab');
  128 |     if (await primaryLink.evaluate((element) => element === document.activeElement)) {
  129 |       break;
  130 |     }
  131 |   }
  132 | 
  133 |   await expect(primaryLink).toBeFocused();
  134 |   await page.keyboard.press('Enter');
  135 |   await expect(page).toHaveURL(/\/fixtures$/);
  136 |   await expect(page.getByRole('heading', { level: 1, name: 'Fixtures' })).toBeVisible();
  137 | });
  138 | 
  139 | test('Three.js enhancement pauses off-screen and unmounts without page errors', async ({
  140 |   page,
  141 | }) => {
  142 |   const pageErrors: string[] = [];
  143 |   page.on('pageerror', (error) => pageErrors.push(error.stack ?? error.message));
  144 |   await page.addInitScript(() => {
  145 |     const diagnostics = window as typeof window & { __heroContextLosses?: number };
  146 |     diagnostics.__heroContextLosses = 0;
  147 |     document.addEventListener(
  148 |       'webglcontextlost',
  149 |       (event) => {
  150 |         if (event.target instanceof HTMLCanvasElement && event.target.matches('.hero-scene')) {
  151 |           diagnostics.__heroContextLosses = (diagnostics.__heroContextLosses ?? 0) + 1;
  152 |         }
  153 |       },
  154 |       true,
  155 |     );
  156 |   });
  157 |   await page.goto('/');
  158 | 
  159 |   const visual = page.locator('[data-hero-enhancement]');
  160 |   const canvas = visual.locator('canvas');
  161 |   const webglAvailable = await hasWebGL(page);
  162 | 
  163 |   if (!webglAvailable) {
  164 |     test.skip(true, 'WebGL is unavailable in this browser runtime.');
  165 |   }
  166 | 
  167 |   await expect(visual).toHaveAttribute('data-hero-enhancement', 'three');
  168 |   await expect(canvas).toHaveCount(1);
  169 |   await expect(canvas).toHaveAttribute('data-context-state', 'ready');
  170 |   await expect(canvas).toHaveAttribute('data-animation-state', /running|idle/);
  171 |   await page.waitForTimeout(3_000);
  172 |   expect(
  173 |     await page.evaluate(
  174 |       () => (window as typeof window & { __heroContextLosses?: number }).__heroContextLosses,
  175 |     ),
  176 |   ).toBe(0);
  177 |   await expect(canvas).toHaveAttribute('data-animation-state', /running|idle/);
  178 |   await page.locator('.home-cta').scrollIntoViewIfNeeded();
  179 |   await expect(canvas).toHaveAttribute('data-animation-state', 'paused');
  180 | 
  181 |   await page.getByRole('link', { name: 'Browse fixtures' }).last().click();
  182 |   await expect(page.getByRole('heading', { level: 1, name: 'Fixtures' })).toBeVisible();
  183 |   await expect(page.locator('.hero-scene')).toHaveCount(0);
  184 |   expect(pageErrors).toEqual([]);
  185 | });
  186 | 
  187 | test('Three.js enhancement reveals the fallback during context loss and restores in place', async ({
  188 |   page,
  189 | }) => {
  190 |   const pageErrors: string[] = [];
  191 |   page.on('pageerror', (error) => pageErrors.push(error.stack ?? error.message));
  192 |   await page.goto('/');
  193 | 
  194 |   const webglAvailable = await hasWebGL(page);
  195 |   test.skip(!webglAvailable, 'WebGL is unavailable in this browser runtime.');
  196 | 
  197 |   const visual = page.locator('[data-hero-enhancement]');
  198 |   const canvas = visual.locator('.hero-scene');
  199 | 
  200 |   await expect(
  201 |     canvas,
  202 |     'Three.js should initialise when the browser runtime reports WebGL support.',
> 203 |   ).toHaveAttribute('data-context-state', 'ready', {
      |     ^ Error: Three.js should initialise when the browser runtime reports WebGL support.
  204 |     timeout: THREE_INITIALISATION_TIMEOUT_MS,
  205 |   });
  206 |   await expect(visual).toHaveAttribute('data-hero-enhancement', 'three');
  207 | 
  208 |   const canSimulateContextLoss = await canvas.evaluate((element) => {
  209 |     const context = element.getContext('webgl2') ?? element.getContext('webgl');
  210 |     const extension = context?.getExtension('WEBGL_lose_context');
  211 |     if (!extension) {
  212 |       return false;
  213 |     }
  214 | 
  215 |     element.dataset.rendererInstance = 'original';
  216 |     const diagnostics = window as typeof window & { __restoreHeroContext?: () => void };
  217 |     diagnostics.__restoreHeroContext = () => extension.restoreContext();
  218 |     extension.loseContext();
  219 |     return true;
  220 |   });
  221 |   test.skip(!canSimulateContextLoss, 'WEBGL_lose_context is unavailable in this browser runtime.');
  222 | 
  223 |   await expect(visual).toHaveAttribute('data-hero-enhancement', 'fallback');
  224 |   await expect(canvas).toHaveAttribute('data-context-state', 'lost');
  225 |   await expect(canvas).toHaveAttribute('data-animation-state', 'context-lost');
  226 |   await expect(canvas).toHaveCSS('opacity', '0');
  227 |   await expect(canvas).toHaveCount(1);
  228 | 
  229 |   await page.evaluate(() => {
  230 |     (window as typeof window & { __restoreHeroContext?: () => void }).__restoreHeroContext?.();
  231 |   });
  232 | 
  233 |   await expect(visual).toHaveAttribute('data-hero-enhancement', 'three');
  234 |   await expect(canvas).toHaveAttribute('data-context-state', 'ready');
  235 |   await expect(canvas).toHaveAttribute('data-animation-state', /running|idle/);
  236 |   await expect(canvas).toHaveAttribute('data-renderer-instance', 'original');
  237 |   await expect(canvas).toHaveCount(1);
  238 |   expect(pageErrors).toEqual([]);
  239 | });
  240 | 
```