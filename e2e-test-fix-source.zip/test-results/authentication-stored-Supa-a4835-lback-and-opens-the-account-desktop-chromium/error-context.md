# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: authentication.spec.ts >> stored Supabase identity completes the callback and opens the account
- Location: tests/e2e/authentication.spec.ts:139:5

# Error details

```
Error: expect(page).toHaveURL(expected) failed

Expected pattern: /\/account\/overview$/
Received string:  "http://127.0.0.1:32895/auth/callback"
Timeout: 5000ms

Call log:
  - Expect "toHaveURL" with timeout 5000ms
    13 × locator resolved to <html lang="en" data-theme="day">…</html>
       - unexpected value "http://127.0.0.1:32895/auth/callback"

```

```yaml
- link "Skip to main content":
  - /url: "#main-content"
- banner:
  - link "Stat'sTheGame home":
    - /url: /
    - img "Stat'sTheGame"
  - navigation "Public records":
    - button "Explore Data"
    - link "Downloads":
      - /url: /dataset-releases
    - link "API":
      - /url: /api
  - navigation "Account":
    - link "Sign in":
      - /url: /sign-in
  - text: Theme
  - checkbox "Switch to Night Match theme"
  - text: Day Match
- main:
  - region "Completing Sign In":
    - paragraph: Supabase managed authentication
    - heading "Completing Sign In" [level=1]
    - alert: We could not establish a signed-in session. Please try again.
    - paragraph:
      - link "Try Again":
        - /url: /sign-in
      - text: or
      - link "Return Home":
        - /url: /
- contentinfo:
  - img "Stat'sTheGame"
  - paragraph: The game, measured ball by ball.
  - navigation "Footer navigation":
    - link "API Explorer":
      - /url: /api
    - link "API Documentation":
      - /url: https://sports-analytics-tool.pages.dev/api/overview/
    - link "Privacy Notice":
      - /url: /privacy
    - link "Terms of Use":
      - /url: /terms
    - link "Accessibility":
      - /url: /accessibility
```

# Test source

```ts
  49  |       created_at: '2026-08-09T00:00:00.000Z',
  50  |     },
  51  |   });
  52  | }
  53  | 
  54  | test(
  55  |   'signed-out authentication pages are responsive and keyboard operable',
  56  |   { tag: '@mobile' },
  57  |   async ({ page }) => {
  58  |     await isolateSupabaseClientLock(page);
  59  |     await page.goto('/');
  60  | 
  61  |     const authenticationAction = await signedOutNavigationAction(page);
  62  |     await expect(authenticationAction).toHaveAttribute('href', '/sign-in');
  63  | 
  64  |     const hasHorizontalOverflow = await page.evaluate(
  65  |       () => document.documentElement.scrollWidth > document.documentElement.clientWidth,
  66  |     );
  67  |     expect(hasHorizontalOverflow).toBe(false);
  68  | 
  69  |     await authenticationAction.click();
  70  |     await expect(page).toHaveURL(/\/sign-in$/);
  71  |     await expect(page.getByRole('heading', { name: 'Login or Sign up' })).toBeVisible();
  72  | 
  73  |     const googleAction = page.getByRole('button', { name: 'Sign in with Google' });
  74  |     await expect(googleAction).toHaveText('Sign in');
  75  |     await expect(googleAction.locator('svg[aria-hidden="true"]')).toBeVisible();
  76  |     await googleAction.focus();
  77  |     await expect(googleAction).toBeFocused();
  78  | 
  79  |     const oauthRequest = page.waitForRequest(
  80  |       (request) =>
  81  |         request.url().startsWith('https://e2e.supabase.co/auth/v1/authorize') &&
  82  |         request.url().includes('provider=google'),
  83  |     );
  84  |     await page.route('https://e2e.supabase.co/auth/v1/authorize**', async (route) => {
  85  |       await route.fulfill({ contentType: 'text/html', body: '<p>Managed OAuth boundary</p>' });
  86  |     });
  87  | 
  88  |     await page.keyboard.press('Enter');
  89  | 
  90  |     const port = process.env.PLAYWRIGHT_PORT ?? '4173';
  91  |     expect((await oauthRequest).url()).toContain(encodeURIComponent(`http://127.0.0.1:${port}/`));
  92  |   },
  93  | );
  94  | 
  95  | test('OAuth cancellation returns a safe signed-out callback state', async ({ page }) => {
  96  |   await isolateSupabaseClientLock(page);
  97  | 
  98  |   await page.goto('/auth/callback#error=access_denied&error_description=private+provider+detail');
  99  | 
  100 |   await expect(page.getByRole('heading', { name: 'Completing Sign In' })).toBeVisible();
  101 | 
  102 |   await expect(page.getByRole('alert')).toHaveText('Sign-in was cancelled. No changes were made.');
  103 | 
  104 |   await expect(page).toHaveURL(/\/auth\/callback$/);
  105 | 
  106 |   await expect(page.getByText(/private provider detail/i)).toHaveCount(0);
  107 | 
  108 |   await expect(page.getByRole('link', { name: 'Try Again' })).toHaveAttribute('href', '/sign-in');
  109 | 
  110 |   await expect(page.getByRole('link', { name: 'Return Home' })).toHaveAttribute('href', '/');
  111 | 
  112 |   await expect(
  113 |     page.getByRole('navigation', { name: 'Account' }).getByRole('link', {
  114 |       name: 'Sign in',
  115 |     }),
  116 |   ).toBeVisible();
  117 | });
  118 | 
  119 | test('OAuth provider failure returns a safe recoverable callback state', async ({ page }) => {
  120 |   await isolateSupabaseClientLock(page);
  121 | 
  122 |   await page.goto(
  123 |     '/auth/callback?error=server_error&error_code=500&error_description=provider+secret+response',
  124 |   );
  125 | 
  126 |   await expect(page.getByRole('alert')).toHaveText(
  127 |     'We could not complete sign-in. Please try again.',
  128 |   );
  129 | 
  130 |   await expect(page).toHaveURL(/\/auth\/callback$/);
  131 | 
  132 |   await expect(page.getByText(/provider secret response/i)).toHaveCount(0);
  133 | 
  134 |   await expect(page.getByRole('link', { name: 'Try Again' })).toBeVisible();
  135 | 
  136 |   await expect(page.getByRole('link', { name: 'Return Home' })).toBeVisible();
  137 | });
  138 | 
  139 | test('stored Supabase identity completes the callback and opens the account', async ({ page }) => {
  140 |   await isolateSupabaseClientLock(page);
  141 | 
  142 |   await page.addInitScript(({ key, value }) => window.localStorage.setItem(key, value), {
  143 |     key: authStorageKey,
  144 |     value: createStoredSession(),
  145 |   });
  146 | 
  147 |   await page.goto('/auth/callback');
  148 | 
> 149 |   await expect(page).toHaveURL(/\/account\/overview$/);
      |                      ^ Error: expect(page).toHaveURL(expected) failed
  150 | 
  151 |   await expect(page.getByRole('heading', { name: 'Account', exact: true })).toBeVisible();
  152 | 
  153 |   await expect(page.getByText('browser@example.com')).toBeVisible();
  154 | 
  155 |   await expect(page.getByRole('link', { name: 'Account management' })).toHaveAttribute(
  156 |     'href',
  157 |     '/account/security',
  158 |   );
  159 |   await expect(page.getByRole('link', { name: 'Manage account' })).toHaveAttribute(
  160 |     'href',
  161 |     '/account',
  162 |   );
  163 | });
  164 | 
  165 | test('stored Supabase identity updates navigation and can sign out', async ({ page }) => {
  166 |   await isolateSupabaseClientLock(page);
  167 |   await page.addInitScript(({ key, value }) => window.localStorage.setItem(key, value), {
  168 |     key: authStorageKey,
  169 |     value: createStoredSession(),
  170 |   });
  171 |   await page.route('https://e2e.supabase.co/auth/v1/logout**', async (route) => {
  172 |     await route.fulfill({ status: 204 });
  173 |   });
  174 | 
  175 |   await page.goto('/account/security');
  176 | 
  177 |   await expect(page.getByRole('link', { name: 'Manage account' })).toHaveAttribute(
  178 |     'href',
  179 |     '/account',
  180 |   );
  181 |   await expect(page.getByRole('link', { name: 'Account management' })).toHaveAttribute(
  182 |     'href',
  183 |     '/account/security',
  184 |   );
  185 |   await expect(page.getByRole('button', { name: 'Sign out' })).toBeVisible();
  186 |   await expect(page.getByRole('link', { name: 'Sign in' })).toHaveCount(0);
  187 | 
  188 |   const signOut = page.getByRole('button', { name: 'Sign out' });
  189 |   await signOut.focus();
  190 |   await expect(signOut).toBeFocused();
  191 |   await page.keyboard.press('Enter');
  192 | 
  193 |   await expect(page).toHaveURL('/');
  194 |   await expect(await signedOutNavigationAction(page)).toBeVisible();
  195 |   await expect(page.getByRole('button', { name: 'Sign out' })).toHaveCount(0);
  196 | });
  197 | 
```