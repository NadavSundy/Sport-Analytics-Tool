# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: admin-submitter-rejection.spec.ts >> administrator rejects a pending submitter request with accessible responsive feedback
- Location: tests/e2e/admin-submitter-rejection.spec.ts:30:5

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.focus: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: 'Manage pending.contributor@example.com' })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to main content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - banner [ref=e5]:
    - generic [ref=e6]:
      - link "Stat'sTheGame home" [ref=e7] [cursor=pointer]:
        - /url: /
        - img "Stat'sTheGame" [ref=e9]
      - generic [ref=e10]:
        - generic [ref=e11]:
          - generic [ref=e12]: Theme
          - generic [ref=e13] [cursor=pointer]:
            - checkbox "Switch to Night Match theme" [ref=e14]
            - generic [ref=e17]: Day Match
        - button "Menu" [ref=e19] [cursor=pointer]
  - main [ref=e20]:
    - region [ref=e22]:
      - generic [ref=e23]:
        - paragraph [ref=e24]: Supabase managed authentication
        - heading "Login or Sign up" [level=1] [ref=e25]
        - paragraph [ref=e26]: Supabase will securely handle your Google login or sign-up.
        - button "Sign in with Google" [ref=e27] [cursor=pointer]:
          - generic [ref=e33]: Sign in
  - contentinfo [ref=e34]:
    - generic [ref=e35]:
      - generic [ref=e36]:
        - img "Stat'sTheGame" [ref=e38]
        - paragraph [ref=e39]: The game, measured ball by ball.
      - navigation "Footer navigation" [ref=e40]:
        - link "API Explorer" [ref=e41] [cursor=pointer]:
          - /url: /api
        - link "API Documentation" [ref=e42] [cursor=pointer]:
          - /url: https://sports-analytics-tool.pages.dev/api/overview/
        - link "Privacy Notice" [ref=e43] [cursor=pointer]:
          - /url: /privacy
        - link "Terms of Use" [ref=e44] [cursor=pointer]:
          - /url: /terms
        - link "Accessibility" [ref=e45] [cursor=pointer]:
          - /url: /accessibility
```

# Test source

```ts
  15  |         user: {
  16  |           id: 'administrator-user',
  17  |           aud: 'authenticated',
  18  |           role: 'authenticated',
  19  |           email: 'administrator@example.com',
  20  |           app_metadata: {},
  21  |           user_metadata: {},
  22  |           identities: [],
  23  |           created_at: '2026-08-19T00:00:00.000Z',
  24  |         },
  25  |       }),
  26  |     );
  27  |   });
  28  | });
  29  | 
  30  | test(
  31  |   'administrator rejects a pending submitter request with accessible responsive feedback',
  32  |   { tag: '@mobile' },
  33  |   async ({ page }) => {
  34  |     const updatedAt = '2026-08-19T10:00:00.000Z';
  35  |     let releaseRejection!: () => void;
  36  |     const rejectionCanComplete = new Promise<void>((resolve) => {
  37  |       releaseRejection = resolve;
  38  |     });
  39  | 
  40  |     await page.route('**/api/v1/auth/me', async (route) => {
  41  |       await route.fulfill({
  42  |         status: 200,
  43  |         contentType: 'application/json',
  44  |         body: JSON.stringify({
  45  |           user: {
  46  |             id: '1',
  47  |             subject: 'administrator-user',
  48  |             displayName: 'Administrator',
  49  |             role: 'admin',
  50  |             approvalState: 'approved',
  51  |             requestedCompetition: null,
  52  |             competitionIds: [],
  53  |           },
  54  |         }),
  55  |       });
  56  |     });
  57  | 
  58  |     await page.route('**/api/v1/admin/users', async (route) => {
  59  |       await route.fulfill({
  60  |         status: 200,
  61  |         contentType: 'application/json',
  62  |         body: JSON.stringify({
  63  |           data: {
  64  |             users: [
  65  |               {
  66  |                 id: '42',
  67  |                 email: 'pending.contributor@example.com',
  68  |                 displayName: 'Pending Contributor',
  69  |                 role: 'viewer',
  70  |                 approvalState: 'pending',
  71  |                 requestedCompetition: { competitionId: '7', name: 'Premier T20' },
  72  |                 competitionScopes: [],
  73  |                 disabled: false,
  74  |                 updatedAt,
  75  |                 submitterAccessUpdatedAt: null,
  76  |                 submitterAccessUpdatedBy: null,
  77  |               },
  78  |             ],
  79  |             availableScopes: [{ competitionId: '7', name: 'Premier T20' }],
  80  |           },
  81  |         }),
  82  |       });
  83  |     });
  84  | 
  85  |     await page.route('**/api/v1/admin/users/42/submitter-access/rejection', async (route) => {
  86  |       expect(route.request().method()).toBe('POST');
  87  |       expect(route.request().headers().authorization).toBe('Bearer administrator-e2e-token');
  88  |       await rejectionCanComplete;
  89  |       await route.fulfill({
  90  |         status: 200,
  91  |         contentType: 'application/json',
  92  |         body: JSON.stringify({
  93  |           data: {
  94  |             id: '42',
  95  |             email: 'pending.contributor@example.com',
  96  |             displayName: 'Pending Contributor',
  97  |             role: 'viewer',
  98  |             approvalState: 'rejected',
  99  |             requestedCompetition: { competitionId: '7', name: 'Premier T20' },
  100 |             competitionScopes: [],
  101 |             disabled: false,
  102 |             updatedAt,
  103 |             submitterAccessUpdatedAt: updatedAt,
  104 |             submitterAccessUpdatedBy: { id: '1', displayName: 'Administrator' },
  105 |           },
  106 |         }),
  107 |       });
  108 |     });
  109 | 
  110 |     await page.goto('/admin/users');
  111 | 
  112 |     const reviewButton = page.getByRole('button', {
  113 |       name: 'Manage pending.contributor@example.com',
  114 |     });
> 115 |     await reviewButton.focus();
      |                        ^ Error: locator.focus: Test timeout of 30000ms exceeded.
  116 |     await expect(reviewButton).toBeFocused();
  117 |     await page.keyboard.press('Enter');
  118 | 
  119 |     const dialog = page.getByRole('dialog', { name: 'Pending Contributor' });
  120 |     await expect(dialog).toBeVisible();
  121 |     await expect(dialog.getByText('Premier T20')).toHaveCount(2);
  122 | 
  123 |     const rejectButton = dialog.getByRole('button', { name: 'Reject request' });
  124 |     await rejectButton.focus();
  125 |     await expect(rejectButton).toBeFocused();
  126 |     await page.keyboard.press('Enter');
  127 | 
  128 |     const confirmation = dialog.getByRole('alertdialog');
  129 |     await expect(confirmation).toContainText(
  130 |       'Reject the pending submitter request from pending.contributor@example.com?',
  131 |     );
  132 |     const confirmButton = confirmation.getByRole('button', { name: 'Confirm change' });
  133 |     await expect(confirmButton).toBeFocused();
  134 |     await page.keyboard.press('Enter');
  135 | 
  136 |     await expect(dialog.getByText('Saving access change. Please wait.')).toHaveAttribute(
  137 |       'role',
  138 |       'status',
  139 |     );
  140 |     await expect(dialog.getByRole('button', { name: 'Reject request' })).toBeDisabled();
  141 | 
  142 |     releaseRejection();
  143 | 
  144 |     await expect(
  145 |       dialog.getByText('Submitter request was rejected for Pending Contributor.'),
  146 |     ).toHaveAttribute('role', 'status');
  147 |     await expect(dialog.getByText('Rejected', { exact: true })).toBeVisible();
  148 |     await expect(
  149 |       dialog.getByText(/no submitter request is currently available to manage/i),
  150 |     ).toBeVisible();
  151 |     await expect(dialog.getByRole('button', { name: 'Reject request' })).toHaveCount(0);
  152 |     await expect(dialog.getByRole('button', { name: 'Approve submitter' })).toHaveCount(0);
  153 | 
  154 |     const hasHorizontalOverflow = await page.evaluate(
  155 |       () => document.documentElement.scrollWidth > document.documentElement.clientWidth,
  156 |     );
  157 |     expect(hasHorizontalOverflow).toBe(false);
  158 | 
  159 |     const results = await new AxeBuilder({ page }).analyze();
  160 |     const seriousOrCriticalViolations = results.violations.filter(
  161 |       (violation) => violation.impact === 'serious' || violation.impact === 'critical',
  162 |     );
  163 |     expect(seriousOrCriticalViolations).toEqual([]);
  164 |   },
  165 | );
  166 | 
```