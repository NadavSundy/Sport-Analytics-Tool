# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: submitter-access.spec.ts >> eligible user requests access and reloads the persisted pending state
- Location: tests/e2e/submitter-access.spec.ts:30:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('region', { name: 'Submitter access' }).getByRole('combobox', { name: 'Competition' })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByRole('region', { name: 'Submitter access' }).getByRole('combobox', { name: 'Competition' })

```

```yaml
- link "Skip to main content":
  - /url: "#main-content"
- banner:
  - link "Stat'sTheGame home":
    - /url: /
    - img "Stat'sTheGame"
  - navigation "Public records":
    - button "Explore Data"
    - link "Downloads":
      - /url: /dataset-releases
    - link "API":
      - /url: /api
  - navigation "Account":
    - link "Sign in":
      - /url: /sign-in
  - text: Theme
  - checkbox "Switch to Night Match theme"
  - text: Day Match
- main:
  - region "Account":
    - paragraph: Identity and access
    - heading "Account" [level=1]
    - paragraph:
      - text: You are signed out.
      - link "Login or Sign up":
        - /url: /sign-in
      - text: to view your account.
- contentinfo:
  - img "Stat'sTheGame"
  - paragraph: The game, measured ball by ball.
  - navigation "Footer navigation":
    - link "API Explorer":
      - /url: /api
    - link "API Documentation":
      - /url: https://sports-analytics-tool.pages.dev/api/overview/
    - link "Privacy Notice":
      - /url: /privacy
    - link "Terms of Use":
      - /url: /terms
    - link "Accessibility":
      - /url: /accessibility
```

# Test source

```ts
  1   | import AxeBuilder from '@axe-core/playwright';
  2   | import { expect, test } from '@playwright/test';
  3   | 
  4   | test.beforeEach(async ({ page }) => {
  5   |   await page.addInitScript(() => {
  6   |     const now = Math.floor(Date.now() / 1_000);
  7   |     window.localStorage.setItem(
  8   |       'sb-e2e-auth-token',
  9   |       JSON.stringify({
  10  |         access_token: 'requesting-e2e-token',
  11  |         refresh_token: 'managed-by-supabase',
  12  |         expires_in: 3_600,
  13  |         expires_at: now + 3_600,
  14  |         token_type: 'bearer',
  15  |         user: {
  16  |           id: 'requesting-user',
  17  |           aud: 'authenticated',
  18  |           role: 'authenticated',
  19  |           email: 'viewer@example.com',
  20  |           app_metadata: {},
  21  |           user_metadata: {},
  22  |           identities: [],
  23  |           created_at: '2026-08-16T00:00:00.000Z',
  24  |         },
  25  |       }),
  26  |     );
  27  |   });
  28  | });
  29  | 
  30  | test(
  31  |   'eligible user requests access and reloads the persisted pending state',
  32  |   { tag: '@mobile' },
  33  |   async ({ page }) => {
  34  |     let approvalState: 'not_requested' | 'pending' = 'not_requested';
  35  |     let requestedCompetition: { competitionId: string; name: string } | null = null;
  36  | 
  37  |     await page.route('**/api/v1/auth/me', async (route) => {
  38  |       await route.fulfill({
  39  |         status: 200,
  40  |         contentType: 'application/json',
  41  |         body: JSON.stringify({
  42  |           user: {
  43  |             id: '17',
  44  |             subject: 'requesting-user',
  45  |             displayName: 'Requesting User',
  46  |             role: 'viewer',
  47  |             approvalState,
  48  |             requestedCompetition,
  49  |             competitionIds: [],
  50  |           },
  51  |         }),
  52  |       });
  53  |     });
  54  | 
  55  |     await page.route('**/api/v1/competitions?*', async (route) => {
  56  |       await route.fulfill({
  57  |         status: 200,
  58  |         contentType: 'application/json',
  59  |         body: JSON.stringify({
  60  |           data: [
  61  |             { competitionId: '5', name: 'Premier T20' },
  62  |             { competitionId: '8', name: 'University League' },
  63  |           ],
  64  |           pagination: { nextCursor: null },
  65  |         }),
  66  |       });
  67  |     });
  68  | 
  69  |     await page.route('**/api/v1/submitter-access-requests', async (route) => {
  70  |       expect(route.request().method()).toBe('POST');
  71  |       expect(route.request().headers().authorization).toBe('Bearer requesting-e2e-token');
  72  |       expect(route.request().postDataJSON()).toEqual({ competitionId: '8' });
  73  |       approvalState = 'pending';
  74  |       requestedCompetition = { competitionId: '8', name: 'University League' };
  75  | 
  76  |       await route.fulfill({
  77  |         status: 201,
  78  |         contentType: 'application/json',
  79  |         body: JSON.stringify({
  80  |           data: {
  81  |             accountId: '17',
  82  |             approvalState: 'pending',
  83  |             requestedCompetition,
  84  |           },
  85  |         }),
  86  |       });
  87  |     });
  88  | 
  89  |     await page.goto('/account/access');
  90  | 
  91  |     const accessPanel = page.getByRole('region', { name: 'Submitter access' });
  92  |     const competitionSelect = accessPanel.getByRole('combobox', { name: 'Competition' });
> 93  |     await expect(competitionSelect).toBeVisible();
      |                                     ^ Error: expect(locator).toBeVisible() failed
  94  |     await expect(competitionSelect.locator('option')).toHaveText([
  95  |       'Premier T20',
  96  |       'University League',
  97  |     ]);
  98  |     await competitionSelect.selectOption('8');
  99  |     await expect(accessPanel.getByRole('combobox', { name: /fixture/i })).toHaveCount(0);
  100 | 
  101 |     const requestButton = page.getByRole('button', { name: 'Request submitter access' });
  102 |     await expect(requestButton).toBeVisible();
  103 |     await requestButton.focus();
  104 |     await expect(requestButton).toBeFocused();
  105 |     await page.keyboard.press('Enter');
  106 | 
  107 |     await expect(page.getByText('Pending approval')).toBeVisible();
  108 |     await expect(
  109 |       page
  110 |         .locator('.submitter-access-panel__message')
  111 |         .filter({ hasText: /request for University League.*awaiting administrator/i }),
  112 |     ).toBeVisible();
  113 |     await expect(requestButton).toHaveCount(0);
  114 | 
  115 |     await page.reload();
  116 | 
  117 |     await expect(page.getByText('Pending approval')).toBeVisible();
  118 |     await expect(requestButton).toHaveCount(0);
  119 | 
  120 |     const hasHorizontalOverflow = await page.evaluate(
  121 |       () => document.documentElement.scrollWidth > document.documentElement.clientWidth,
  122 |     );
  123 |     expect(hasHorizontalOverflow).toBe(false);
  124 | 
  125 |     const results = await new AxeBuilder({ page }).analyze();
  126 |     const seriousOrCriticalViolations = results.violations.filter(
  127 |       (violation) => violation.impact === 'serious' || violation.impact === 'critical',
  128 |     );
  129 |     expect(seriousOrCriticalViolations).toEqual([]);
  130 |   },
  131 | );
  132 | 
  133 | test(
  134 |   'approved submitter requests an additional competition without changing current scope',
  135 |   { tag: '@mobile' },
  136 |   async ({ page }) => {
  137 |     let requestedCompetition: { competitionId: string; name: string } | null = null;
  138 | 
  139 |     await page.route('**/api/v1/auth/me', async (route) => {
  140 |       await route.fulfill({
  141 |         status: 200,
  142 |         contentType: 'application/json',
  143 |         body: JSON.stringify({
  144 |           user: {
  145 |             id: '17',
  146 |             subject: 'requesting-user',
  147 |             displayName: 'Approved Submitter',
  148 |             role: 'submitter',
  149 |             approvalState: 'approved',
  150 |             requestedCompetition,
  151 |             competitionIds: ['5'],
  152 |           },
  153 |         }),
  154 |       });
  155 |     });
  156 | 
  157 |     await page.route('**/api/v1/competitions?*', async (route) => {
  158 |       await route.fulfill({
  159 |         status: 200,
  160 |         contentType: 'application/json',
  161 |         body: JSON.stringify({
  162 |           data: [
  163 |             { competitionId: '5', name: 'Premier T20' },
  164 |             { competitionId: '8', name: 'University League' },
  165 |           ],
  166 |           pagination: { nextCursor: null },
  167 |         }),
  168 |       });
  169 |     });
  170 | 
  171 |     await page.route('**/api/v1/submitter-scope-requests', async (route) => {
  172 |       expect(route.request().method()).toBe('POST');
  173 |       expect(route.request().headers().authorization).toBe('Bearer requesting-e2e-token');
  174 |       expect(route.request().postDataJSON()).toEqual({ competitionId: '8' });
  175 |       requestedCompetition = { competitionId: '8', name: 'University League' };
  176 | 
  177 |       await route.fulfill({
  178 |         status: 201,
  179 |         contentType: 'application/json',
  180 |         body: JSON.stringify({
  181 |           data: {
  182 |             accountId: '17',
  183 |             requestedCompetition,
  184 |           },
  185 |         }),
  186 |       });
  187 |     });
  188 | 
  189 |     await page.goto('/account/access');
  190 | 
  191 |     const accessPanel = page.getByRole('region', { name: 'Submitter access' });
  192 |     const currentScope = accessPanel.locator('p').filter({ hasText: 'Current competition scope:' });
  193 |     await expect(currentScope).toContainText('Premier T20');
```