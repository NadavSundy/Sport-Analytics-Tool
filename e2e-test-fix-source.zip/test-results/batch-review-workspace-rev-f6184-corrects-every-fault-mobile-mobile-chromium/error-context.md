# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: batch-review-workspace.spec.ts >> reviewer onboards participants in one submission and corrects every fault @mobile
- Location: tests/e2e/batch-review-workspace.spec.ts:639:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: 'Participants to onboard' })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByRole('heading', { name: 'Participants to onboard' })

```

```yaml
- link "Skip to main content":
  - /url: "#main-content"
- banner:
  - link "Stat'sTheGame home":
    - /url: /
    - img "Stat'sTheGame"
  - text: Theme
  - checkbox "Switch to Night Match theme"
  - text: Day Match
  - button "Menu"
- main:
  - region "Login or Sign up":
    - paragraph: Supabase managed authentication
    - heading "Login or Sign up" [level=1]
    - paragraph: Supabase will securely handle your Google login or sign-up.
    - button "Sign in with Google"
- contentinfo:
  - img "Stat'sTheGame"
  - paragraph: The game, measured ball by ball.
  - navigation "Footer navigation":
    - link "API Explorer":
      - /url: /api
    - link "API Documentation":
      - /url: https://sports-analytics-tool.pages.dev/api/overview/
    - link "Privacy Notice":
      - /url: /privacy
    - link "Terms of Use":
      - /url: /terms
    - link "Accessibility":
      - /url: /accessibility
```

# Test source

```ts
  699 |                 { teamId: '30', name: 'Lions' },
  700 |                 { teamId: '31', name: 'Bears' },
  701 |               ],
  702 |             },
  703 |             {
  704 |               taskReference: teamTask,
  705 |               fixtureId: '22',
  706 |               submittedName: 'C. Khumalo',
  707 |               submittedTeamName: 'Wanderers',
  708 |               // The case deployed acceptance testing could not settle: the
  709 |               // reason is not team_not_recognised, but the submitted team is
  710 |               // still not one of the fixture's two, so the decision fails on
  711 |               // the team and the card has to offer that choice anyway.
  712 |               reason: 'no_durable_identifier',
  713 |               candidates: [{ personId: '13', displayName: 'Chris Khumalo' }],
  714 |               teams: [
  715 |                 { teamId: '30', name: 'Lions' },
  716 |                 { teamId: '31', name: 'Bears' },
  717 |               ],
  718 |             },
  719 |           ],
  720 |       acceptedSamples: [],
  721 |       blockingItems: [],
  722 |       items: [],
  723 |       pagination: { nextCursor: null },
  724 |       downloadUrl: `/api/v1/batches/${reference}/report/download`,
  725 |     },
  726 |   });
  727 | 
  728 |   await page.route(/\/api\/v1\/admin\/batches(?:\?.*)?$/, async (route) => {
  729 |     await route.fulfill({
  730 |       status: 200,
  731 |       contentType: 'application/json',
  732 |       body: JSON.stringify({ data: [report().data.batch], pagination: { nextCursor: null } }),
  733 |     });
  734 |   });
  735 | 
  736 |   await page.route(`**/api/v1/batches/${reference}/report`, async (route) => {
  737 |     await route.fulfill({
  738 |       status: 200,
  739 |       contentType: 'application/json',
  740 |       body: JSON.stringify(report()),
  741 |     });
  742 |   });
  743 | 
  744 |   let attempts = 0;
  745 |   await page.route(`**/api/v1/batches/${reference}/participants`, async (route) => {
  746 |     attempts += 1;
  747 |     const body = JSON.parse(route.request().postData() ?? '{}');
  748 |     // The whole array in one request, always.
  749 |     expect(body.decisions).toHaveLength(2);
  750 | 
  751 |     if (attempts === 1) {
  752 |       // All or nothing, with a fault for each decision that broke, so the
  753 |       // reviewer corrects both at once rather than one resubmission at a time.
  754 |       await route.fulfill({
  755 |         status: 409,
  756 |         contentType: 'application/json',
  757 |         body: JSON.stringify({
  758 |           error: {
  759 |             code: 'BATCH_PARTICIPANT_ONBOARDING_CONFLICT',
  760 |             message: 'One or more participant onboarding decisions could not be applied.',
  761 |             details: [
  762 |               {
  763 |                 taskReference: ambiguous,
  764 |                 code: 'CANDIDATE_NOT_OFFERED',
  765 |                 message: 'Choose one of the candidates this task offered.',
  766 |               },
  767 |               {
  768 |                 taskReference: teamTask,
  769 |                 code: 'TEAM_NOT_IN_FIXTURE',
  770 |                 message: 'Name one of the two teams of the fixture this task belongs to.',
  771 |               },
  772 |             ],
  773 |           },
  774 |         }),
  775 |       });
  776 |       return;
  777 |     }
  778 | 
  779 |     settled = true;
  780 |     await route.fulfill({
  781 |       status: 202,
  782 |       contentType: 'application/json',
  783 |       body: JSON.stringify({
  784 |         data: {
  785 |           batchReference: reference,
  786 |           decisionReference: '688a0bf0-e168-4b67-bf6f-f5857dbb1f87',
  787 |           status: 'queued',
  788 |           statusUrl: `/api/v1/batches/${reference}`,
  789 |           submittedAt: '2026-09-24T12:00:00.000Z',
  790 |           onboarded: 2,
  791 |           alreadyOnboarded: 0,
  792 |           revalidationQueued: true,
  793 |         },
  794 |       }),
  795 |     });
  796 |   });
  797 | 
  798 |   await page.goto(`/reviews/batches/${reference}`);
> 799 |   await expect(page.getByRole('heading', { name: 'Participants to onboard' })).toBeVisible();
      |                                                                                ^ Error: expect(locator).toBeVisible() failed
  800 | 
  801 |   // One card per decision, not one per delivery naming the participant.
  802 |   await expect(page.getByText('2 outstanding')).toBeVisible();
  803 |   await expect(page.getByRole('heading', { name: 'A. Smith' })).toBeVisible();
  804 |   await expect(page.getByRole('heading', { name: 'C. Khumalo' })).toBeVisible();
  805 | 
  806 |   // The team is chosen from the fixture's two, never typed.
  807 |   const teamCard = page.getByRole('article').filter({ hasText: 'C. Khumalo' });
  808 |   await expect(
  809 |     teamCard.getByRole('group', { name: 'Which team do they belong to?' }),
  810 |   ).toBeVisible();
  811 | 
  812 |   await page.getByRole('radio', { name: 'Alan Smith' }).check();
  813 |   await page.getByRole('radio', { name: 'Chris Khumalo' }).check();
  814 |   await teamCard.getByRole('radio', { name: 'Bears' }).check();
  815 | 
  816 |   const submit = page.getByRole('button', { name: 'Submit 2 decisions' });
  817 |   await expect(submit).toBeEnabled();
  818 |   await submit.click();
  819 | 
  820 |   // Every fault, each against its own card.
  821 |   await expect(
  822 |     page
  823 |       .getByRole('article')
  824 |       .filter({ hasText: 'A. Smith' })
  825 |       .getByText('Choose one of the candidates this task offered.'),
  826 |   ).toBeVisible();
  827 |   await expect(
  828 |     teamCard.getByText('Name one of the two teams of the fixture this task belongs to.'),
  829 |   ).toBeVisible();
  830 |   await expect(page.getByText('Nothing was applied.')).toBeVisible();
  831 | 
  832 |   // Correct both and resubmit. Nothing was applied, so both are still open.
  833 |   await page.getByRole('radio', { name: 'Amy Smith' }).check();
  834 |   await teamCard.getByRole('radio', { name: 'Lions' }).check();
  835 |   await page.getByRole('button', { name: 'Submit 2 decisions' }).click();
  836 | 
  837 |   // Settling the last task empties the list, which drops the needs-review count
  838 |   // to zero and moves the workspace to the decision view, taking the section
  839 |   // with it. The receipt has to outlive that, or a reviewer is never told their
  840 |   // decisions were applied.
  841 |   await expect(page.getByRole('tab', { name: 'Review decision' })).toHaveAttribute(
  842 |     'aria-selected',
  843 |     'true',
  844 |   );
  845 |   await expect(page.getByRole('heading', { name: 'Participants to onboard' })).toBeHidden();
  846 |   await expect(page.getByText(/2 settled/)).toBeVisible();
  847 | 
  848 |   expect(
  849 |     await page.evaluate(
  850 |       () => document.documentElement.scrollWidth > document.documentElement.clientWidth,
  851 |     ),
  852 |   ).toBe(false);
  853 |   const results = await new AxeBuilder({ page }).analyze();
  854 |   expect(
  855 |     results.violations.filter(
  856 |       (violation) => violation.impact === 'serious' || violation.impact === 'critical',
  857 |     ),
  858 |   ).toEqual([]);
  859 | });
  860 | 
```