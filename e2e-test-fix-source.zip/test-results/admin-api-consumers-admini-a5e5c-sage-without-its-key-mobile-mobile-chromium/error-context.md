# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: admin-api-consumers.spec.ts >> administrator manages a consumer and reviews its usage without its key @mobile
- Location: tests/e2e/admin-api-consumers.spec.ts:46:5

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('link', { name: 'Manage API consumers' })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to main content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - banner [ref=e5]:
    - generic [ref=e6]:
      - link "Stat'sTheGame home" [ref=e7] [cursor=pointer]:
        - /url: /
        - img "Stat'sTheGame" [ref=e9]
      - generic [ref=e10]:
        - generic [ref=e11]:
          - generic [ref=e12]: Theme
          - generic [ref=e13] [cursor=pointer]:
            - checkbox "Switch to Night Match theme" [ref=e14]
            - generic [ref=e17]: Day Match
        - button "Menu" [ref=e19] [cursor=pointer]
  - main [ref=e20]:
    - region [ref=e22]:
      - generic [ref=e23]:
        - paragraph [ref=e24]: Supabase managed authentication
        - heading "Login or Sign up" [level=1] [ref=e25]
        - paragraph [ref=e26]: Supabase will securely handle your Google login or sign-up.
        - button "Sign in with Google" [ref=e27] [cursor=pointer]:
          - generic [ref=e33]: Sign in
  - contentinfo [ref=e34]:
    - generic [ref=e35]:
      - generic [ref=e36]:
        - img "Stat'sTheGame" [ref=e38]
        - paragraph [ref=e39]: The game, measured ball by ball.
      - navigation "Footer navigation" [ref=e40]:
        - link "API Explorer" [ref=e41] [cursor=pointer]:
          - /url: /api
        - link "API Documentation" [ref=e42] [cursor=pointer]:
          - /url: https://sports-analytics-tool.pages.dev/api/overview/
        - link "Privacy Notice" [ref=e43] [cursor=pointer]:
          - /url: /privacy
        - link "Terms of Use" [ref=e44] [cursor=pointer]:
          - /url: /terms
        - link "Accessibility" [ref=e45] [cursor=pointer]:
          - /url: /accessibility
```

# Test source

```ts
  64  |           approvalState: 'not_requested',
  65  |           requestedCompetition: null,
  66  |           competitionIds: [],
  67  |         },
  68  |       }),
  69  |     });
  70  |   });
  71  |   await page.route('**/api/v1/admin/api-consumers', async (route) => {
  72  |     expect(route.request().headers().authorization).toContain('Bearer ');
  73  |     if (route.request().method() === 'POST') {
  74  |       expect(route.request().postDataJSON()).toEqual({
  75  |         name: 'Match data partner',
  76  |         rateLimitPerMinute: 25,
  77  |         dailyQuota: 500,
  78  |       });
  79  |       const consumer = {
  80  |         id: '17',
  81  |         name: 'Match data partner',
  82  |         rateLimitPerMinute: 25,
  83  |         dailyQuota: 500,
  84  |         createdAt,
  85  |         keys: [
  86  |           { id: String(nextKeyId), prefix: issuedKey.slice(0, 17), createdAt, revokedAt: null },
  87  |         ],
  88  |       };
  89  |       consumers = [consumer];
  90  |       await route.fulfill({
  91  |         status: 201,
  92  |         contentType: 'application/json',
  93  |         body: JSON.stringify({ data: { ...consumer, apiKey: issuedKey } }),
  94  |       });
  95  |       return;
  96  |     }
  97  |     await route.fulfill({
  98  |       status: 200,
  99  |       contentType: 'application/json',
  100 |       body: JSON.stringify({ data: { consumers } }),
  101 |     });
  102 |   });
  103 |   await page.route('**/api/v1/admin/api-consumers/17/keys/rotate', async (route) => {
  104 |     nextKeyId += 1;
  105 |     const previous = consumers[0] as { keys: Array<Record<string, unknown>> };
  106 |     const consumer = {
  107 |       ...previous,
  108 |       keys: [
  109 |         { ...previous.keys[0], revokedAt: createdAt },
  110 |         { id: String(nextKeyId), prefix: rotatedKey.slice(0, 17), createdAt, revokedAt: null },
  111 |       ],
  112 |     };
  113 |     consumers = [consumer];
  114 |     await route.fulfill({
  115 |       status: 200,
  116 |       contentType: 'application/json',
  117 |       body: JSON.stringify({ data: { ...consumer, apiKey: rotatedKey } }),
  118 |     });
  119 |   });
  120 |   await page.route('**/api/v1/admin/api-consumers/17/usage*', async (route) => {
  121 |     expect(route.request().headers().authorization).toContain('Bearer ');
  122 |     expect(route.request().url()).not.toContain(issuedKey);
  123 |     expect(route.request().url()).not.toContain(rotatedKey);
  124 |     await route.fulfill({
  125 |       status: 200,
  126 |       contentType: 'application/json',
  127 |       body: JSON.stringify({
  128 |         data: {
  129 |           consumer: {
  130 |             id: '17',
  131 |             name: 'Match data partner',
  132 |             rateLimitPerMinute: 25,
  133 |             dailyQuota: 500,
  134 |           },
  135 |           from: '2026-09-21',
  136 |           to: '2026-09-27',
  137 |           totalRequests: 14,
  138 |           entries: [
  139 |             {
  140 |               date: '2026-09-27',
  141 |               endpoint: 'GET /consumer/fixtures/:fixtureId/events',
  142 |               statusClass: '2xx',
  143 |               requestCount: 14,
  144 |             },
  145 |           ],
  146 |         },
  147 |       }),
  148 |     });
  149 |   });
  150 |   await page.route('**/api/v1/admin/api-consumers/17/keys/32', async (route) => {
  151 |     const consumer = consumers[0] as { keys: Array<Record<string, unknown>> };
  152 |     consumers = [
  153 |       {
  154 |         ...consumer,
  155 |         keys: consumer.keys.map((key) =>
  156 |           key.id === '32' ? { ...key, revokedAt: createdAt } : key,
  157 |         ),
  158 |       },
  159 |     ];
  160 |     await route.fulfill({ status: 204 });
  161 |   });
  162 | 
  163 |   await page.goto('/admin');
> 164 |   await page.getByRole('link', { name: 'Manage API consumers' }).click();
      |                                                                  ^ Error: locator.click: Test timeout of 30000ms exceeded.
  165 |   await expect(page.getByRole('heading', { level: 1, name: 'API consumers' })).toBeVisible();
  166 |   await page.getByLabel('Consumer name').fill('Match data partner');
  167 |   await page.getByLabel('Rate limit (requests per minute)').fill('25');
  168 |   await page.getByLabel('Daily quota (requests per UTC day)').fill('500');
  169 |   await page.getByRole('button', { name: 'Create consumer' }).click();
  170 | 
  171 |   const createdDialog = page.getByRole('dialog', { name: 'API key created' });
  172 |   await expect(createdDialog.getByLabel('New API key')).toHaveText(issuedKey);
  173 |   await createdDialog.getByRole('button', { name: 'Copy API key' }).click();
  174 |   await expect(createdDialog.getByRole('status')).toHaveText('API key copied.');
  175 |   expect(await page.evaluate(() => navigator.clipboard.readText())).toBe(issuedKey);
  176 |   await createdDialog.getByRole('button', { name: 'Dismiss key' }).click();
  177 |   await expect(page.getByText(issuedKey)).toHaveCount(0);
  178 | 
  179 |   await page.getByRole('link', { name: 'Manage Match data partner' }).click();
  180 |   await expect(page.getByRole('heading', { level: 1, name: 'Match data partner' })).toBeVisible();
  181 |   const usage = page.getByRole('region', { name: 'API consumer usage table' });
  182 |   await expect(usage).toContainText('2026-09-27');
  183 |   await expect(usage).toContainText('GET /consumer/fixtures/:fixtureId/events');
  184 |   await expect(usage).toContainText('2xx');
  185 |   await expect(usage).toContainText('14');
  186 |   await expect(page.getByText('2026-09-21 to 2026-09-27 UTC')).toBeVisible();
  187 |   await expect(page.getByLabel(/API key/i)).toHaveCount(0);
  188 |   await page.getByRole('button', { name: 'Rotate key' }).click();
  189 |   const rotateDialog = page.getByRole('dialog', { name: 'Rotate API key?' });
  190 |   await expect(rotateDialog).toContainText('stop every previous active key');
  191 |   await rotateDialog.getByRole('button', { name: 'Rotate key' }).click();
  192 |   const rotatedDialog = page.getByRole('dialog', { name: 'API key rotated' });
  193 |   await expect(rotatedDialog.getByLabel('New API key')).toHaveText(rotatedKey);
  194 |   await rotatedDialog.getByRole('button', { name: 'Dismiss key' }).click();
  195 |   await expect(page.getByText(rotatedKey)).toHaveCount(0);
  196 | 
  197 |   await page.getByRole('button', { name: `Revoke key ${rotatedKey.slice(0, 17)}` }).click();
  198 |   const revokeDialog = page.getByRole('dialog', { name: 'Revoke API key?' });
  199 |   await revokeDialog.getByRole('button', { name: 'Revoke key' }).click();
  200 |   await expect(page.getByText('No active keys')).toBeVisible();
  201 |   await expect(page.locator('.admin-status-badge', { hasText: 'Revoked' })).toHaveCount(2);
  202 |   await expect(page.getByRole('link', { name: 'Open API Explorer' })).toHaveAttribute(
  203 |     'href',
  204 |     '/api',
  205 |   );
  206 | 
  207 |   expect(
  208 |     await page.evaluate(
  209 |       () => document.documentElement.scrollWidth > document.documentElement.clientWidth,
  210 |     ),
  211 |   ).toBe(false);
  212 |   const results = await new AxeBuilder({ page }).analyze();
  213 |   expect(
  214 |     results.violations.filter(
  215 |       (violation) => violation.impact === 'serious' || violation.impact === 'critical',
  216 |     ),
  217 |   ).toEqual([]);
  218 | });
  219 | 
```