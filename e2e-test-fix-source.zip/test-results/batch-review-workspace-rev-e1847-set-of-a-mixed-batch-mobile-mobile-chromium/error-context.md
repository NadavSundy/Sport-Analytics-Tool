# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: batch-review-workspace.spec.ts >> reviewer publishes the accepted subset of a mixed batch @mobile
- Location: tests/e2e/batch-review-workspace.spec.ts:51:5

# Error details

```
Error: expect(page).toHaveTitle(expected) failed

Expected pattern: /Review queue/
Received string:  "Login or Sign up | Stat'sTheGame"
Timeout: 5000ms

Call log:
  - Expect "toHaveTitle" with timeout 5000ms
    - locator resolved to <html lang="en" data-theme="day">…</html>
    - unexpected value "Stat'sTheGame"
    13 × locator resolved to <html lang="en" data-theme="day">…</html>
       - unexpected value "Login or Sign up | Stat'sTheGame"

```

```yaml
- link "Skip to main content":
  - /url: "#main-content"
- banner:
  - link "Stat'sTheGame home":
    - /url: /
    - img "Stat'sTheGame"
  - text: Theme
  - checkbox "Switch to Night Match theme"
  - text: Day Match
  - button "Menu"
- main:
  - region "Login or Sign up":
    - paragraph: Supabase managed authentication
    - heading "Login or Sign up" [level=1]
    - paragraph: Supabase will securely handle your Google login or sign-up.
    - button "Sign in with Google"
- contentinfo:
  - img "Stat'sTheGame"
  - paragraph: The game, measured ball by ball.
  - navigation "Footer navigation":
    - link "API Explorer":
      - /url: /api
    - link "API Documentation":
      - /url: https://sports-analytics-tool.pages.dev/api/overview/
    - link "Privacy Notice":
      - /url: /privacy
    - link "Terms of Use":
      - /url: /terms
    - link "Accessibility":
      - /url: /accessibility
```

# Test source

```ts
  118 |       fixtureSummaries: [
  119 |         {
  120 |           fixtureId: '22',
  121 |           label: 'Lions vs Bears · 2026-09-01',
  122 |           total: 20_000,
  123 |           accepted: 19_999,
  124 |           rejected: 1,
  125 |           unresolved: 0,
  126 |         },
  127 |       ],
  128 |       participantOnboarding: [],
  129 |       acceptedSamples: [acceptedSample],
  130 |       blockingItems: [],
  131 |       items: [
  132 |         {
  133 |           ordinal: 1,
  134 |           outcome: 'rejected',
  135 |           location: {
  136 |             filePath: 'season.csv',
  137 |             sheetName: null,
  138 |             rowNumber: 3,
  139 |             jsonPath: 'runs.total',
  140 |             ordinal: 1,
  141 |           },
  142 |           context: {
  143 |             eventReference: 'event-1',
  144 |             fixtureId: '22',
  145 |             fixtureLabel: 'Lions vs Bears · 2026-09-01',
  146 |             inningsId: '31',
  147 |             overNumber: 2,
  148 |             positionInOver: 1,
  149 |             description: 'Event event-1 at over 2, delivery 1.',
  150 |           },
  151 |           stagedRecordId: '41',
  152 |           acceptedRecordId: null,
  153 |           referenceResolutions: [],
  154 |           errors: [
  155 |             {
  156 |               ruleCode: 'EVENT_SCHEMA_INVALID',
  157 |               message: 'Runs total does not match its components.',
  158 |               location: {
  159 |                 filePath: 'season.csv',
  160 |                 sheetName: null,
  161 |                 rowNumber: 3,
  162 |                 jsonPath: 'runs.total',
  163 |                 ordinal: 1,
  164 |               },
  165 |               context: {
  166 |                 eventReference: 'event-1',
  167 |                 fixtureId: '22',
  168 |                 fixtureLabel: 'Lions vs Bears · 2026-09-01',
  169 |                 inningsId: '31',
  170 |                 overNumber: 2,
  171 |                 positionInOver: 1,
  172 |                 description: 'Event event-1 at over 2, delivery 1.',
  173 |               },
  174 |             },
  175 |           ],
  176 |         },
  177 |       ],
  178 |       pagination: { nextCursor: null },
  179 |       downloadUrl: `/api/v1/batches/${reference}/report/download`,
  180 |     },
  181 |   });
  182 | 
  183 |   await page.route(/\/api\/v1\/admin\/batches(?:\?.*)?$/, async (route) => {
  184 |     const url = new URL(route.request().url());
  185 |     const isReviewQueue = url.searchParams.get('status') === 'awaiting_review';
  186 | 
  187 |     await route.fulfill({
  188 |       status: 200,
  189 |       contentType: 'application/json',
  190 |       body: JSON.stringify({
  191 |         data: isReviewQueue ? [batch()] : [],
  192 |         pagination: { nextCursor: null },
  193 |       }),
  194 |     });
  195 |   });
  196 |   await page.route(`**/api/v1/batches/${reference}/report`, async (route) => {
  197 |     await route.fulfill({
  198 |       status: 200,
  199 |       contentType: 'application/json',
  200 |       body: JSON.stringify(report()),
  201 |     });
  202 |   });
  203 |   await page.route(`**/api/v1/batches/${reference}/review`, async (route) => {
  204 |     expect(route.request().headers().authorization).toBe('Bearer reviewer-e2e-token');
  205 |     expect(route.request().postDataJSON()).toEqual({
  206 |       decision: 'approved',
  207 |       reason: 'Publish the independently accepted records.',
  208 |     });
  209 |     status = 'published';
  210 |     await route.fulfill({
  211 |       status: 200,
  212 |       contentType: 'application/json',
  213 |       body: JSON.stringify({ data: batch() }),
  214 |     });
  215 |   });
  216 | 
  217 |   await page.goto('/reviews/batches');
> 218 |   await expect(page).toHaveTitle(/Review queue/);
      |                      ^ Error: expect(page).toHaveTitle(expected) failed
  219 |   await page.getByRole('link', { name: 'season.csv' }).click();
  220 |   await expect(page.getByRole('heading', { name: 'Review staged submission' })).toBeVisible();
  221 |   await expect(page.getByRole('heading', { name: 'season.csv' })).toBeVisible();
  222 |   await expect(page.getByRole('tab', { name: 'Review decision' })).toHaveAttribute(
  223 |     'aria-selected',
  224 |     'true',
  225 |   );
  226 |   await expect(page.getByRole('list', { name: 'Batch lifecycle' })).toBeVisible();
  227 |   const decisionTab = page.getByRole('tab', { name: 'Review decision' });
  228 |   await decisionTab.focus();
  229 |   await page.keyboard.press('Home');
  230 |   await expect(page.getByRole('tab', { name: 'Needs review (0)' })).toBeFocused();
  231 |   await page.keyboard.press('ArrowRight');
  232 |   await expect(page.getByRole('tab', { name: 'References (0)' })).toBeFocused();
  233 |   await page.keyboard.press('End');
  234 |   await expect(decisionTab).toBeFocused();
  235 |   await page.getByRole('tab', { name: 'Batch summary' }).click();
  236 |   await expect(page.getByText('Data Submitter', { exact: true })).toBeVisible();
  237 |   await page.getByText(/Show resolved content/).click();
  238 |   await expect(page.getByText('cricsheet:delivery:100-original')).toBeVisible();
  239 |   await expect(page.getByText(/published delivery 88/)).toBeVisible();
  240 |   await expect(page.getByText('Lions vs Bears · 2026-09-01')).toBeVisible();
  241 |   await page.getByText(/1 rejection/).click();
  242 |   await expect(page.getByText('Runs total does not match its components.')).toBeVisible();
  243 |   await decisionTab.click();
  244 |   await expect(page.getByText('Only the accepted subset will publish')).toBeVisible();
  245 |   const approve = page.getByRole('button', { name: 'Approve and publish' });
  246 |   await expect(approve).toBeEnabled();
  247 | 
  248 |   await page.getByLabel(/Reason/).fill('Publish the independently accepted records.');
  249 |   await approve.click();
  250 |   const dialog = page.getByRole('dialog', { name: 'Confirm approve and publish' });
  251 |   await expect(dialog.getByRole('button', { name: 'Cancel' })).toBeFocused();
  252 |   await page.keyboard.press('Shift+Tab');
  253 |   await expect(dialog.getByRole('button', { name: 'Confirm approve and publish' })).toBeFocused();
  254 |   await page.keyboard.press('Tab');
  255 |   await expect(dialog.getByRole('button', { name: 'Cancel' })).toBeFocused();
  256 |   await page.keyboard.press('Escape');
  257 |   await expect(dialog).toBeHidden();
  258 |   await expect(approve).toBeFocused();
  259 |   await approve.click();
  260 |   await dialog.getByRole('button', { name: 'Confirm approve and publish' }).click();
  261 |   await expect(page.getByText('Current state: Published')).toBeVisible();
  262 |   await page.getByRole('tab', { name: 'Batch summary' }).click();
  263 |   await expect(page.getByText('Runs total does not match its components.')).toBeVisible();
  264 | 
  265 |   expect(
  266 |     await page.evaluate(
  267 |       () => document.documentElement.scrollWidth > document.documentElement.clientWidth,
  268 |     ),
  269 |   ).toBe(false);
  270 |   const results = await new AxeBuilder({ page }).analyze();
  271 |   expect(
  272 |     results.violations.filter(
  273 |       (violation) => violation.impact === 'serious' || violation.impact === 'critical',
  274 |     ),
  275 |   ).toEqual([]);
  276 |   if (process.env.ISSUE_362_SCREENSHOT_DIRECTORY) {
  277 |     await page.evaluate(() => window.scrollTo(0, 0));
  278 |     await page.screenshot({
  279 |       path: join(
  280 |         process.env.ISSUE_362_SCREENSHOT_DIRECTORY,
  281 |         `batch-review-${testInfo.project.name}.png`,
  282 |       ),
  283 |       fullPage: false,
  284 |     });
  285 |   }
  286 | });
  287 | 
  288 | test('reviewer reconciles a published delivery conflict as an immutable correction', async ({
  289 |   page,
  290 | }) => {
  291 |   let resolved = false;
  292 |   const batch = () => ({
  293 |     batchReference: reference,
  294 |     competitionId: '5',
  295 |     status: 'awaiting_review',
  296 |     statusUrl: `/api/v1/batches/${reference}`,
  297 |     receivedAt: '2026-09-13T08:00:00.000Z',
  298 |     updatedAt: '2026-09-13T08:05:00.000Z',
  299 |     source: {
  300 |       fileName: 'conflicting-season.json',
  301 |       checksum: 'b'.repeat(64),
  302 |       packageVersion: '1.0',
  303 |       submitter: { accountId: '7', displayName: 'Data Submitter' },
  304 |     },
  305 |     progress: { total: 1, processed: 1, accepted: resolved ? 1 : 0, rejected: resolved ? 0 : 1 },
  306 |     counts: {
  307 |       accepted: resolved ? 1 : 0,
  308 |       rejected: resolved ? 0 : 1,
  309 |       unresolved: 0,
  310 |       duplicate: 0,
  311 |       conflicting: resolved ? 0 : 1,
  312 |     },
  313 |     lineage: { replacesBatchReference: null, supersededByBatchReference: null },
  314 |     review: null,
  315 |   });
  316 |   const report = () => {
  317 |     const response = {
  318 |       data: {
```