# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: submissions.spec.ts >> submitter uploads and resolves a batch through the responsive guided workflow
- Location: tests/e2e/submissions.spec.ts:554:5

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('radio', { name: /Back catalogue/ })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to main content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - banner [ref=e5]:
    - generic [ref=e6]:
      - link "Stat'sTheGame home" [ref=e7] [cursor=pointer]:
        - /url: /
        - img "Stat'sTheGame" [ref=e9]
      - navigation "Public records" [ref=e10]:
        - button "Explore Data" [ref=e12] [cursor=pointer]: Explore Data ▾
        - link "Downloads" [ref=e13] [cursor=pointer]:
          - /url: /dataset-releases
        - link "API" [ref=e14] [cursor=pointer]:
          - /url: /api
      - generic [ref=e15]:
        - navigation "Account" [ref=e16]:
          - link "Sign in" [ref=e17] [cursor=pointer]:
            - /url: /sign-in
        - generic [ref=e18]:
          - generic [ref=e19]: Theme
          - generic [ref=e20] [cursor=pointer]:
            - checkbox "Switch to Night Match theme" [ref=e21]
            - generic [ref=e24]: Day Match
  - main [ref=e25]:
    - region [ref=e27]:
      - generic [ref=e28]:
        - paragraph [ref=e29]: Supabase managed authentication
        - heading "Login or Sign up" [level=1] [ref=e30]
        - paragraph [ref=e31]: Supabase will securely handle your Google login or sign-up.
        - button "Sign in with Google" [ref=e32] [cursor=pointer]:
          - generic [ref=e38]: Sign in
  - contentinfo [ref=e39]:
    - generic [ref=e40]:
      - generic [ref=e41]:
        - img "Stat'sTheGame" [ref=e43]
        - paragraph [ref=e44]: The game, measured ball by ball.
      - navigation "Footer navigation" [ref=e45]:
        - link "API Explorer" [ref=e46] [cursor=pointer]:
          - /url: /api
        - link "API Documentation" [ref=e47] [cursor=pointer]:
          - /url: https://sports-analytics-tool.pages.dev/api/overview/
        - link "Privacy Notice" [ref=e48] [cursor=pointer]:
          - /url: /privacy
        - link "Terms of Use" [ref=e49] [cursor=pointer]:
          - /url: /terms
        - link "Accessibility" [ref=e50] [cursor=pointer]:
          - /url: /accessibility
```

# Test source

```ts
  502 |     );
  503 |     expect(hasHorizontalOverflow).toBe(false);
  504 |     const results = await new AxeBuilder({ page }).analyze();
  505 |     expect(
  506 |       results.violations.filter(
  507 |         (violation) => violation.impact === 'serious' || violation.impact === 'critical',
  508 |       ),
  509 |     ).toEqual([]);
  510 |   },
  511 | );
  512 | 
  513 | test('file validation identifies a rejected CSV row and returns focus to the result', async ({
  514 |   page,
  515 | }) => {
  516 |   await page.route('**/api/v1/batches', async (route) => {
  517 |     await route.fulfill({
  518 |       status: 422,
  519 |       contentType: 'application/json',
  520 |       body: JSON.stringify({
  521 |         error: {
  522 |           code: 'VALIDATION_FAILED',
  523 |           message: 'The uploaded submission file is invalid.',
  524 |           details: [
  525 |             {
  526 |               code: 'INVALID_FILE_ROW',
  527 |               message: 'Expected number, received string',
  528 |               field: 'events.0.runs.total',
  529 |               eventIndex: 0,
  530 |             },
  531 |           ],
  532 |         },
  533 |       }),
  534 |     });
  535 |   });
  536 | 
  537 |   await page.goto('/submissions/new');
  538 |   await chooseListedFixture(page);
  539 |   const fileInput = page.getByLabel('Fixture package', { exact: true });
  540 |   await fileInput.setInputFiles({
  541 |     name: 'events.csv',
  542 |     mimeType: 'text/csv',
  543 |     buffer: Buffer.from('fixtureDate,homeTeamName,awayTeamName\n2026-08-20,Wanderers,Strikers\n'),
  544 |   });
  545 |   await page.getByRole('button', { name: 'Upload fixture package' }).click();
  546 | 
  547 |   await expect(page.getByRole('heading', { name: 'Submission rejected' })).toBeFocused();
  548 |   await expect(page.getByText('Row 1 — Total runs')).toBeVisible();
  549 |   await expect(page.getByText('Use a number here instead of text.')).toBeVisible();
  550 |   await expect(page.getByText('Technical details')).toBeVisible();
  551 |   await expect(fileInput).toHaveAttribute('aria-invalid', 'true');
  552 | });
  553 | 
  554 | test(
  555 |   'submitter uploads and resolves a batch through the responsive guided workflow',
  556 |   { tag: '@mobile' },
  557 |   async ({ page }) => {
  558 |     await page.route('**/api/v1/competitions/5', (route) =>
  559 |       route.fulfill({
  560 |         status: 200,
  561 |         contentType: 'application/json',
  562 |         body: JSON.stringify({ data: { competitionId: '5', name: 'Premier T20' } }),
  563 |       }),
  564 |     );
  565 |     await page.route('**/api/v1/seasons?**', (route) =>
  566 |       route.fulfill({
  567 |         status: 200,
  568 |         contentType: 'application/json',
  569 |         body: JSON.stringify({
  570 |           data: [
  571 |             {
  572 |               seasonId: '15',
  573 |               competitionId: '5',
  574 |               competitionName: 'Premier T20',
  575 |               label: '2026/27',
  576 |             },
  577 |           ],
  578 |           pagination: { nextCursor: null },
  579 |         }),
  580 |       }),
  581 |     );
  582 |     await page.route('**/api/v1/batches', async (route) => {
  583 |       expect(route.request().headers()['x-competition-id']).toBe('5');
  584 |       expect(route.request().headers()['x-file-name']).toBe('back-catalogue.csv');
  585 |       await new Promise((resolve) => setTimeout(resolve, 100));
  586 |       await route.fulfill({
  587 |         status: 202,
  588 |         contentType: 'application/json',
  589 |         body: JSON.stringify({
  590 |           data: {
  591 |             batchReference,
  592 |             status: 'stored',
  593 |             statusUrl: `/api/v1/batches/${batchReference}`,
  594 |             receivedAt: '2026-09-08T09:30:00.000Z',
  595 |           },
  596 |         }),
  597 |       });
  598 |     });
  599 | 
  600 |     await page.goto('/submissions/batches/new');
  601 |     await expect(page).toHaveURL(/\/submissions\/new$/);
> 602 |     await page.getByRole('radio', { name: /Back catalogue/ }).click();
      |                                                               ^ Error: locator.click: Test timeout of 30000ms exceeded.
  603 |     await expect(page.getByLabel('Competition', { exact: true })).toHaveValue('Premier T20');
  604 |     await expect(page.getByLabel('Season context')).toHaveCount(0);
  605 |     await page.getByLabel('Back catalogue package').setInputFiles({
  606 |       name: 'back-catalogue.csv',
  607 |       mimeType: 'text/csv',
  608 |       buffer: Buffer.from('contractVersion,packageId\n1.0,provider:package:2026'),
  609 |     });
  610 |     await page.getByRole('button', { name: 'Upload back catalogue package' }).click();
  611 |     await expect(page.getByRole('progressbar', { name: 'Upload progress' })).toBeVisible();
  612 |     await expect(
  613 |       page.locator(
  614 |         'h1:focus, h2:focus, h3:focus, h4:focus, h5:focus, h6:focus, [role="heading"]:focus',
  615 |       ),
  616 |     ).toBeFocused();
  617 |     await expect(page.locator(`a[href="/submissions/batches/${batchReference}"]`)).toBeVisible();
  618 | 
  619 |     await page.route(`**/api/v1/batches/${batchReference}/report`, (route) =>
  620 |       route.fulfill({
  621 |         status: 200,
  622 |         contentType: 'application/json',
  623 |         body: JSON.stringify({
  624 |           data: {
  625 |             batch: {
  626 |               batchReference,
  627 |               competitionId: '5',
  628 |               status: 'rejected',
  629 |               statusUrl: `/api/v1/batches/${batchReference}`,
  630 |               receivedAt: '2026-09-08T09:30:00.000Z',
  631 |               updatedAt: '2026-09-08T09:35:00.000Z',
  632 |               source: {
  633 |                 fileName: 'back-catalogue.csv',
  634 |                 checksum: 'a'.repeat(64),
  635 |                 packageVersion: '1.0',
  636 |                 submitter: { accountId: '17', displayName: 'E2E Submitter' },
  637 |               },
  638 |               progress: { total: 1, processed: 1, accepted: 0, rejected: 1 },
  639 |               counts: { accepted: 0, rejected: 1, unresolved: 1, duplicate: 0, conflicting: 0 },
  640 |               lineage: { replacesBatchReference: null, supersededByBatchReference: null },
  641 |               review: null,
  642 |             },
  643 |             errorGroups: [{ ruleCode: 'REFERENCE_AMBIGUOUS', count: 1 }],
  644 |             reviewSummary: {
  645 |               validation: {
  646 |                 accepted: 0,
  647 |                 rejected: 1,
  648 |                 blockingErrors: 0,
  649 |                 duplicate: 0,
  650 |                 conflicting: 0,
  651 |               },
  652 |               resolution: { resolved: 0, ambiguous: 1, unresolved: 0, invalid: 0, proposed: 1 },
  653 |               approvalBlocked: true,
  654 |               blockingReasons: ['Ambiguous references remain.'],
  655 |             },
  656 |             fixtureSummaries: [
  657 |               {
  658 |                 fixtureId: null,
  659 |                 label: 'Fixture unresolved',
  660 |                 total: 1,
  661 |                 accepted: 0,
  662 |                 rejected: 1,
  663 |                 unresolved: 1,
  664 |               },
  665 |             ],
  666 |             participantOnboarding: [],
  667 |             acceptedSamples: [],
  668 |             blockingItems: [],
  669 |             items: [
  670 |               {
  671 |                 ordinal: 0,
  672 |                 outcome: 'unresolved',
  673 |                 location: {
  674 |                   filePath: 'back-catalogue.csv',
  675 |                   sheetName: 'Events',
  676 |                   rowNumber: 2,
  677 |                   jsonPath: 'striker',
  678 |                   ordinal: 0,
  679 |                 },
  680 |                 context: {
  681 |                   eventReference: 'provider:event:1',
  682 |                   fixtureId: null,
  683 |                   fixtureLabel: null,
  684 |                   inningsId: null,
  685 |                   overNumber: 0,
  686 |                   positionInOver: 1,
  687 |                   description: 'Premier T20, Wanderers v Strikers, over 0 delivery 1.',
  688 |                 },
  689 |                 stagedRecordId: null,
  690 |                 acceptedRecordId: null,
  691 |                 errors: [
  692 |                   {
  693 |                     ruleCode: 'REFERENCE_AMBIGUOUS',
  694 |                     message: 'More than one participant is named A. Smith.',
  695 |                     location: {
  696 |                       filePath: 'back-catalogue.csv',
  697 |                       sheetName: 'Events',
  698 |                       rowNumber: 2,
  699 |                       jsonPath: 'striker',
  700 |                       ordinal: 0,
  701 |                     },
  702 |                     context: {
```