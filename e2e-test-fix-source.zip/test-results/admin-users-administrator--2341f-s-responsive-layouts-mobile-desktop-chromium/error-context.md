# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: admin-users.spec.ts >> administrator finds and safely manages a user across responsive layouts @mobile
- Location: tests/e2e/admin-users.spec.ts:63:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByText('pending.contributor@example.com')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByText('pending.contributor@example.com')

```

```yaml
- link "Skip to main content":
  - /url: "#main-content"
- banner:
  - link "Stat'sTheGame home":
    - /url: /
    - img "Stat'sTheGame"
  - navigation "Public records":
    - button "Explore Data"
    - link "Downloads":
      - /url: /dataset-releases
    - link "API":
      - /url: /api
  - navigation "Account":
    - link "Sign in":
      - /url: /sign-in
  - text: Theme
  - checkbox "Switch to Night Match theme"
  - text: Day Match
- main:
  - region "Login or Sign up":
    - paragraph: Supabase managed authentication
    - heading "Login or Sign up" [level=1]
    - paragraph: Supabase will securely handle your Google login or sign-up.
    - button "Sign in with Google"
- contentinfo:
  - img "Stat'sTheGame"
  - paragraph: The game, measured ball by ball.
  - navigation "Footer navigation":
    - link "API Explorer":
      - /url: /api
    - link "API Documentation":
      - /url: https://sports-analytics-tool.pages.dev/api/overview/
    - link "Privacy Notice":
      - /url: /privacy
    - link "Terms of Use":
      - /url: /terms
    - link "Accessibility":
      - /url: /accessibility
```

# Test source

```ts
  48  |             user_metadata: {},
  49  |             identities: [],
  50  |             created_at: '2026-08-16T12:00:00.000Z',
  51  |           },
  52  |         }),
  53  |       );
  54  |     },
  55  |     {
  56  |       storageKey: authStorageKey,
  57  |       accessToken: `${header}.${payload}.e2e-signature`,
  58  |       tokenExpiry: expiresAt,
  59  |     },
  60  |   );
  61  | });
  62  | 
  63  | test('administrator finds and safely manages a user across responsive layouts @mobile', async ({
  64  |   page,
  65  | }) => {
  66  |   const administrator: ManagedUser = {
  67  |     id: '1',
  68  |     email: 'amina.administrator@example.com',
  69  |     displayName: 'Amina Administrator',
  70  |     role: 'admin',
  71  |     approvalState: 'not_requested',
  72  |     requestedCompetition: null,
  73  |     competitionScopes: [],
  74  |     disabled: false,
  75  |     previouslyRevoked: false,
  76  |     updatedAt: accessTime,
  77  |     submitterAccessUpdatedAt: null,
  78  |     submitterAccessUpdatedBy: null,
  79  |   };
  80  |   let contributor: ManagedUser = {
  81  |     id: '42',
  82  |     email: 'pending.contributor@example.com',
  83  |     displayName: 'Pending Contributor',
  84  |     role: 'viewer',
  85  |     approvalState: 'pending',
  86  |     requestedCompetition: availableScopes[0],
  87  |     competitionScopes: [],
  88  |     disabled: false,
  89  |     previouslyRevoked: false,
  90  |     updatedAt: accessTime,
  91  |     submitterAccessUpdatedAt: null,
  92  |     submitterAccessUpdatedBy: null,
  93  |   };
  94  | 
  95  |   await page.route(
  96  |     '**/api/v1/auth/me',
  97  |     async (route) =>
  98  |       await route.fulfill({
  99  |         status: 200,
  100 |         contentType: 'application/json',
  101 |         body: JSON.stringify({
  102 |           user: {
  103 |             id: '1',
  104 |             subject: 'admin-subject',
  105 |             displayName: 'Amina Administrator',
  106 |             role: 'admin',
  107 |             approvalState: 'not_requested',
  108 |             requestedCompetition: null,
  109 |             competitionIds: [],
  110 |           },
  111 |         }),
  112 |       }),
  113 |   );
  114 |   await page.route(
  115 |     '**/api/v1/admin/users',
  116 |     async (route) =>
  117 |       await route.fulfill({
  118 |         status: 200,
  119 |         contentType: 'application/json',
  120 |         body: JSON.stringify({ data: { users: [administrator, contributor], availableScopes } }),
  121 |       }),
  122 |   );
  123 |   await page.route('**/api/v1/admin/users/42/submitter-access', async (route) => {
  124 |     expect(route.request().headers().authorization).toContain('Bearer ');
  125 |     const update = route.request().postDataJSON() as {
  126 |       approved: boolean;
  127 |       competitionIds: string[];
  128 |     };
  129 |     contributor = {
  130 |       ...contributor,
  131 |       role: update.approved ? 'submitter' : 'viewer',
  132 |       approvalState: update.approved ? 'approved' : 'rejected',
  133 |       requestedCompetition: null,
  134 |       competitionScopes: update.approved
  135 |         ? availableScopes.filter((scope) => update.competitionIds.includes(scope.competitionId))
  136 |         : [],
  137 |       submitterAccessUpdatedAt: accessTime,
  138 |       submitterAccessUpdatedBy: { id: '1', displayName: 'Amina Administrator' },
  139 |     };
  140 |     await route.fulfill({
  141 |       status: 200,
  142 |       contentType: 'application/json',
  143 |       body: JSON.stringify({ data: contributor }),
  144 |     });
  145 |   });
  146 | 
  147 |   await page.goto('/admin/users');
> 148 |   await expect(page.getByText('pending.contributor@example.com')).toBeVisible();
      |                                                                   ^ Error: expect(locator).toBeVisible() failed
  149 |   await expect(page.getByRole('table').getByText('Pending', { exact: true })).toBeVisible();
  150 |   await page.getByLabel('Role').selectOption('viewer');
  151 |   await expect(page.getByText('amina.administrator@example.com')).toBeHidden();
  152 |   await page.getByLabel('Search users').fill('pending.contributor@');
  153 | 
  154 |   const manage = page.getByRole('button', { name: 'Manage pending.contributor@example.com' });
  155 |   await manage.focus();
  156 |   await page.keyboard.press('Enter');
  157 |   const dialog = page.getByRole('dialog', { name: 'Pending Contributor' });
  158 |   await expect(dialog).toBeVisible();
  159 |   await expect(dialog.getByRole('button', { name: /close management view/i })).toBeFocused();
  160 |   await expect(dialog.getByText('Premier T20')).toHaveCount(2);
  161 | 
  162 |   await dialog.getByRole('button', { name: 'Approve submitter' }).click();
  163 |   await expect(dialog.getByRole('alertdialog')).toContainText(
  164 |     'Approve pending.contributor@example.com',
  165 |   );
  166 |   await dialog.getByRole('button', { name: 'Confirm change' }).click();
  167 |   await expect(dialog.getByText(/now an approved submitter/i)).toBeVisible();
  168 |   await expect(dialog.getByRole('checkbox', { name: 'Premier T20' })).toBeChecked();
  169 | 
  170 |   await dialog.getByRole('checkbox', { name: 'Premier T20' }).uncheck();
  171 |   await dialog.getByRole('checkbox', { name: 'University League' }).check();
  172 |   await dialog.getByRole('button', { name: 'Save scope changes' }).click();
  173 |   await dialog.getByRole('button', { name: 'Confirm change' }).click();
  174 |   await expect(dialog.getByText(/competition scope was updated/i)).toBeVisible();
  175 | 
  176 |   const revokeButton = dialog.getByRole('button', { name: 'Revoke submitter access' });
  177 |   await revokeButton.click();
  178 |   await expect(dialog.getByRole('alertdialog')).toContainText('Revoke all submitter access');
  179 |   await dialog.getByRole('button', { name: 'Cancel' }).click();
  180 |   await expect(dialog.getByRole('alertdialog')).toBeHidden();
  181 |   await expect(revokeButton).toBeFocused();
  182 | 
  183 |   await page.keyboard.press('Escape');
  184 |   await expect(dialog).toBeHidden();
  185 |   await expect(page.getByLabel('Search users')).toBeFocused();
  186 |   expect(
  187 |     await page.evaluate(
  188 |       () => document.documentElement.scrollWidth > document.documentElement.clientWidth,
  189 |     ),
  190 |   ).toBe(false);
  191 | 
  192 |   const results = await new AxeBuilder({ page }).analyze();
  193 |   expect(
  194 |     results.violations.filter(
  195 |       (violation) => violation.impact === 'serious' || violation.impact === 'critical',
  196 |     ),
  197 |   ).toEqual([]);
  198 | });
  199 | 
  200 | test('administrator distinguishes and approves an additional competition scope request @mobile', async ({
  201 |   page,
  202 | }) => {
  203 |   const administrator: ManagedUser = {
  204 |     id: '1',
  205 |     email: 'amina.administrator@example.com',
  206 |     displayName: 'Amina Administrator',
  207 |     role: 'admin',
  208 |     approvalState: 'not_requested',
  209 |     requestedCompetition: null,
  210 |     competitionScopes: [],
  211 |     disabled: false,
  212 |     previouslyRevoked: false,
  213 |     updatedAt: accessTime,
  214 |     submitterAccessUpdatedAt: null,
  215 |     submitterAccessUpdatedBy: null,
  216 |   };
  217 |   let submitter: ManagedUser = {
  218 |     id: '42',
  219 |     email: 'approved.submitter@example.com',
  220 |     displayName: 'Approved Submitter',
  221 |     role: 'submitter',
  222 |     approvalState: 'approved',
  223 |     requestedCompetition: availableScopes[1],
  224 |     competitionScopes: [availableScopes[0]],
  225 |     disabled: false,
  226 |     previouslyRevoked: false,
  227 |     updatedAt: accessTime,
  228 |     submitterAccessUpdatedAt: accessTime,
  229 |     submitterAccessUpdatedBy: { id: '1', displayName: 'Amina Administrator' },
  230 |   };
  231 | 
  232 |   await page.route('**/api/v1/auth/me', async (route) => {
  233 |     await route.fulfill({
  234 |       status: 200,
  235 |       contentType: 'application/json',
  236 |       body: JSON.stringify({
  237 |         user: {
  238 |           id: '1',
  239 |           subject: 'admin-subject',
  240 |           displayName: 'Amina Administrator',
  241 |           role: 'admin',
  242 |           approvalState: 'not_requested',
  243 |           requestedCompetition: null,
  244 |           competitionIds: [],
  245 |         },
  246 |       }),
  247 |     });
  248 |   });
```