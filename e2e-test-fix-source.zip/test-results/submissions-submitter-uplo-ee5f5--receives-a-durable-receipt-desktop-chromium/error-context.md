# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: submissions.spec.ts >> submitter uploads a readable fixture package and receives a durable receipt
- Location: tests/e2e/submissions.spec.ts:403:5

# Error details

```
Error: expect(locator).toBeDisabled() failed

Locator: getByLabel('Fixture', { exact: true })
Expected: disabled
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeDisabled" with timeout 5000ms
  - waiting for getByLabel('Fixture', { exact: true })

```

```yaml
- link "Skip to main content":
  - /url: "#main-content"
- banner:
  - link "Stat'sTheGame home":
    - /url: /
    - img "Stat'sTheGame"
  - navigation "Public records":
    - button "Explore Data"
    - link "Downloads":
      - /url: /dataset-releases
    - link "API":
      - /url: /api
  - navigation "Account":
    - link "Sign in":
      - /url: /sign-in
  - text: Theme
  - checkbox "Switch to Night Match theme"
  - text: Day Match
- main:
  - region "Login or Sign up":
    - paragraph: Supabase managed authentication
    - heading "Login or Sign up" [level=1]
    - paragraph: Supabase will securely handle your Google login or sign-up.
    - button "Sign in with Google"
- contentinfo:
  - img "Stat'sTheGame"
  - paragraph: The game, measured ball by ball.
  - navigation "Footer navigation":
    - link "API Explorer":
      - /url: /api
    - link "API Documentation":
      - /url: https://sports-analytics-tool.pages.dev/api/overview/
    - link "Privacy Notice":
      - /url: /privacy
    - link "Terms of Use":
      - /url: /terms
    - link "Accessibility":
      - /url: /accessibility
```

# Test source

```ts
  1   | import { readFileSync } from 'node:fs';
  2   | 
  3   | import AxeBuilder from '@axe-core/playwright';
  4   | import { expect, test, type Page } from '@playwright/test';
  5   | import { seasonUploadPackageSchema } from '@sport-analytics/contracts';
  6   | 
  7   | const fixture = {
  8   |   fixtureId: '7',
  9   |   competitionId: '5',
  10  |   competitionName: 'Example Competition',
  11  |   seasonId: '15',
  12  |   season: '2026',
  13  |   seasonLabel: '2026',
  14  |   competitors: [
  15  |     { competitorId: '20', name: 'Wanderers' },
  16  |     { competitorId: '21', name: 'Strikers' },
  17  |   ],
  18  |   matchType: 'T20',
  19  |   teamType: 'international',
  20  |   gender: 'female',
  21  |   ballsPerOver: 6,
  22  |   scheduledOvers: 20,
  23  |   venue: null,
  24  |   toss: null,
  25  |   startDate: '2026-08-20',
  26  |   endDate: '2026-08-20',
  27  | };
  28  | 
  29  | const events = [
  30  |   {
  31  |     eventId: '123e4567-e89b-42d3-a456-426614174000',
  32  |     inningsId: '10',
  33  |     sequenceNumber: 1,
  34  |     overNumber: 0,
  35  |     positionInOver: 0,
  36  |     ballNumber: '0.1',
  37  |     strikerId: '20',
  38  |     nonStrikerId: '21',
  39  |     bowlerId: '22',
  40  |     runs: { offBat: 4, extras: 0, total: 4, nonBoundary: false },
  41  |     extras: {},
  42  |     wickets: [],
  43  |   },
  44  | ];
  45  | 
  46  | const batchReference = '123e4567-e89b-42d3-a456-426614174000';
  47  | 
  48  | /**
  49  |  * The downloadable JSON template completed with readable names for the listed
  50  |  * fixture only, as the guided page asks (#500). Every placeholder must exist, so
  51  |  * a template change cannot quietly make the journey vacuous.
  52  |  */
  53  | function readableFixturePackage(): string {
  54  |   let text = readFileSync('apps/frontend/public/season-upload-template.json', 'utf8');
  55  |   const readableValues: [placeholder: string, value: string][] = [
  56  |     ['"Competition name"', `"${fixture.competitionName}"`],
  57  |     ['"2026-03-14"', `"${fixture.startDate}"`],
  58  |     ['"Home team"', '"Wanderers"'],
  59  |     ['"Away team"', '"Strikers"'],
  60  |   ];
  61  |   for (const [placeholder, value] of readableValues) {
  62  |     expect(text).toContain(placeholder);
  63  |     text = text.replaceAll(placeholder, value);
  64  |   }
  65  |   return text;
  66  | }
  67  | 
  68  | /**
  69  |  * Choose the competition and then its fixture. Since #779 the page loads
  70  |  * fixtures only for the competition that has been chosen, so the fixture
  71  |  * selector starts empty and disabled and a journey that reaches a submit has to
  72  |  * make the selection a submitter would make.
  73  |  */
  74  | async function chooseListedFixture(page: Page) {
  75  |   const competitionSelector = page.getByRole('combobox', { name: 'Competition' });
  76  |   const fixtureSelector = page.getByLabel('Fixture', { exact: true });
  77  | 
> 78  |   await expect(fixtureSelector).toBeDisabled();
      |                                 ^ Error: expect(locator).toBeDisabled() failed
  79  |   await page.getByRole('button', { name: 'Show competition options' }).click();
  80  |   await page.getByRole('option', { name: 'Example Competition' }).click();
  81  |   await expect(competitionSelector).toHaveValue('Example Competition');
  82  | 
  83  |   await page.getByRole('button', { name: 'Show fixture options' }).click();
  84  |   await page
  85  |     .getByRole('option', {
  86  |       name: /2026-08-20 — Wanderers v Strikers — Example Competition, 2026 \(T20\)/,
  87  |     })
  88  |     .click();
  89  |   await expect(fixtureSelector).toHaveValue(
  90  |     '2026-08-20 — Wanderers v Strikers — Example Competition, 2026 (T20)',
  91  |   );
  92  | }
  93  | 
  94  | test.beforeEach(async ({ page }) => {
  95  |   await page.addInitScript(() => {
  96  |     const now = Math.floor(Date.now() / 1_000);
  97  |     window.localStorage.setItem(
  98  |       'sb-e2e-auth-token',
  99  |       JSON.stringify({
  100 |         access_token: 'approved-e2e-token',
  101 |         refresh_token: 'managed-by-supabase',
  102 |         expires_in: 3_600,
  103 |         expires_at: now + 3_600,
  104 |         token_type: 'bearer',
  105 |         user: {
  106 |           id: 'approved-user',
  107 |           aud: 'authenticated',
  108 |           role: 'authenticated',
  109 |           email: 'submitter@example.com',
  110 |           app_metadata: {},
  111 |           user_metadata: {},
  112 |           identities: [],
  113 |           created_at: '2026-08-16T00:00:00.000Z',
  114 |         },
  115 |       }),
  116 |     );
  117 |   });
  118 | 
  119 |   await page.route('**/api/v1/auth/me', async (route) => {
  120 |     await route.fulfill({
  121 |       status: 200,
  122 |       contentType: 'application/json',
  123 |       body: JSON.stringify({
  124 |         user: {
  125 |           id: '17',
  126 |           subject: 'approved-user',
  127 |           displayName: 'Submitter User',
  128 |           role: 'submitter',
  129 |           approvalState: 'approved',
  130 |           requestedCompetition: { competitionId: '5', name: 'Premier T20' },
  131 |           competitionIds: ['5'],
  132 |         },
  133 |       }),
  134 |     });
  135 |   });
  136 | 
  137 |   await page.route('**/api/v1/competitions?*', async (route) => {
  138 |     await route.fulfill({
  139 |       status: 200,
  140 |       contentType: 'application/json',
  141 |       body: JSON.stringify({
  142 |         data: [
  143 |           { competitionId: '5', name: 'Premier T20' },
  144 |           { competitionId: '8', name: 'University League' },
  145 |         ],
  146 |         pagination: { nextCursor: null },
  147 |       }),
  148 |     });
  149 |   });
  150 | 
  151 |   await page.route('**/api/v1/competitions/5', async (route) => {
  152 |     await route.fulfill({
  153 |       status: 200,
  154 |       contentType: 'application/json',
  155 |       body: JSON.stringify({ data: { competitionId: '5', name: 'Example Competition' } }),
  156 |     });
  157 |   });
  158 | 
  159 |   await page.route('**/api/v1/fixtures?**', async (route) => {
  160 |     await route.fulfill({
  161 |       status: 200,
  162 |       contentType: 'application/json',
  163 |       body: JSON.stringify({ data: [fixture], pagination: { nextCursor: null, totalPages: 1 } }),
  164 |     });
  165 |   });
  166 | });
  167 | 
  168 | test('Manage Submission opens the unified submission workflow', async ({ page }) => {
  169 |   await page.goto('/account/overview');
  170 |   await page.getByRole('button', { name: 'Manage Submission' }).click();
  171 |   await page.getByRole('link', { name: 'Submit data' }).click();
  172 | 
  173 |   await expect(page).toHaveURL(/\/submissions\/new$/);
  174 |   await expect(page.getByRole('heading', { name: 'Submit data' })).toBeVisible();
  175 |   await expect(page.getByRole('radio', { name: /Single fixture/ })).toBeChecked();
  176 |   await expect(page.getByRole('radio', { name: /Season/ })).toBeVisible();
  177 |   await expect(page.getByRole('radio', { name: /Back catalogue/ })).toBeVisible();
  178 |   await expect(page.getByRole('radio', { name: /Advanced technical JSON/ })).toBeVisible();
```