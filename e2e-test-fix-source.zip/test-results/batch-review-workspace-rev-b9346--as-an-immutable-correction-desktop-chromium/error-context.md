# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: batch-review-workspace.spec.ts >> reviewer reconciles a published delivery conflict as an immutable correction
- Location: tests/e2e/batch-review-workspace.spec.ts:288:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: 'Published delivery conflicts' })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByRole('heading', { name: 'Published delivery conflicts' })

```

```yaml
- link "Skip to main content":
  - /url: "#main-content"
- banner:
  - link "Stat'sTheGame home":
    - /url: /
    - img "Stat'sTheGame"
  - navigation "Public records":
    - button "Explore Data"
    - link "Downloads":
      - /url: /dataset-releases
    - link "API":
      - /url: /api
  - navigation "Account":
    - link "Sign in":
      - /url: /sign-in
  - text: Theme
  - checkbox "Switch to Night Match theme"
  - text: Day Match
- main:
  - region "Login or Sign up":
    - paragraph: Supabase managed authentication
    - heading "Login or Sign up" [level=1]
    - paragraph: Supabase will securely handle your Google login or sign-up.
    - button "Sign in with Google"
- contentinfo:
  - img "Stat'sTheGame"
  - paragraph: The game, measured ball by ball.
  - navigation "Footer navigation":
    - link "API Explorer":
      - /url: /api
    - link "API Documentation":
      - /url: https://sports-analytics-tool.pages.dev/api/overview/
    - link "Privacy Notice":
      - /url: /privacy
    - link "Terms of Use":
      - /url: /terms
    - link "Accessibility":
      - /url: /accessibility
```

# Test source

```ts
  347 |         items: [
  348 |           {
  349 |             ordinal: 0,
  350 |             outcome: resolved ? 'accepted' : 'conflicting',
  351 |             location: {
  352 |               filePath: 'events.json',
  353 |               sheetName: null,
  354 |               rowNumber: null,
  355 |               jsonPath: 'delivery',
  356 |               ordinal: 0,
  357 |             },
  358 |             context: {
  359 |               eventReference: 'cricsheet:delivery:fixture-1:0',
  360 |               fixtureId: '22',
  361 |               fixtureLabel: 'Lions vs Bears · 2026-09-01',
  362 |               inningsId: '31',
  363 |               overNumber: 1,
  364 |               positionInOver: 1,
  365 |               description: 'Event cricsheet:delivery:fixture-1:0 at over 1, delivery 1.',
  366 |             },
  367 |             stagedRecordId: '41',
  368 |             acceptedRecordId: null,
  369 |             operation: resolved ? 'correction' : 'upsert',
  370 |             correctionTarget: resolved
  371 |               ? {
  372 |                   sourceEventId: 'cricsheet:delivery:fixture-1:0',
  373 |                   resolvedDeliveryId: '88',
  374 |                 }
  375 |               : null,
  376 |             publishedConflict: resolved
  377 |               ? null
  378 |               : {
  379 |                   existingDeliveryId: '88',
  380 |                   existingSourceEventId: null,
  381 |                   correctionPermitted: true,
  382 |                   differences: [{ fieldPath: 'runs.offBat', submittedValue: 4, publishedValue: 0 }],
  383 |                 },
  384 |             referenceResolutions: [],
  385 |             errors: resolved
  386 |               ? []
  387 |               : [
  388 |                   {
  389 |                     ruleCode: 'PUBLISHED_DELIVERY_CONFLICT',
  390 |                     message:
  391 |                       'A published delivery or published source identity exists with different cricket content.',
  392 |                     location: {
  393 |                       filePath: 'events.json',
  394 |                       sheetName: null,
  395 |                       rowNumber: null,
  396 |                       jsonPath: 'delivery',
  397 |                       ordinal: 0,
  398 |                     },
  399 |                     context: {
  400 |                       eventReference: 'cricsheet:delivery:fixture-1:0',
  401 |                       fixtureId: '22',
  402 |                       fixtureLabel: 'Lions vs Bears · 2026-09-01',
  403 |                       inningsId: '31',
  404 |                       overNumber: 1,
  405 |                       positionInOver: 1,
  406 |                       description: 'Event cricsheet:delivery:fixture-1:0 at over 1, delivery 1.',
  407 |                     },
  408 |                   },
  409 |                 ],
  410 |           },
  411 |         ],
  412 |         pagination: { nextCursor: null },
  413 |         downloadUrl: `/api/v1/batches/${reference}/report/download`,
  414 |       },
  415 |     };
  416 |     return {
  417 |       data: {
  418 |         ...response.data,
  419 |         blockingItems: resolved ? [] : response.data.items,
  420 |       },
  421 |     };
  422 |   };
  423 | 
  424 |   await page.route(`**/api/v1/batches/${reference}/report`, async (route) => {
  425 |     await route.fulfill({
  426 |       status: 200,
  427 |       contentType: 'application/json',
  428 |       body: JSON.stringify(report()),
  429 |     });
  430 |   });
  431 |   await page.route(`**/api/v1/batches/${reference}/conflicts/resolve`, async (route) => {
  432 |     expect(route.request().postDataJSON()).toEqual({
  433 |       itemOrdinal: 0,
  434 |       existingDeliveryId: '88',
  435 |       decision: 'replace_published',
  436 |       reason: 'Correct the published score from the verified source.',
  437 |     });
  438 |     resolved = true;
  439 |     await route.fulfill({
  440 |       status: 200,
  441 |       contentType: 'application/json',
  442 |       body: JSON.stringify({ data: batch() }),
  443 |     });
  444 |   });
  445 | 
  446 |   await page.goto(`/reviews/batches/${reference}`);
> 447 |   await expect(page.getByRole('heading', { name: 'Published delivery conflicts' })).toBeVisible();
      |                                                                                     ^ Error: expect(locator).toBeVisible() failed
  448 |   const conflictCard = page.locator('.published-conflict-resolution');
  449 |   const differenceRow = conflictCard.getByRole('row', { name: /runs\.offBat/ });
  450 |   await expect(differenceRow).toContainText('4');
  451 |   await expect(differenceRow).toContainText('0');
  452 | 
  453 |   await page
  454 |     .getByLabel('Resolution reason')
  455 |     .fill('Correct the published score from the verified source.');
  456 |   await page.getByRole('button', { name: 'Approve submitted correction' }).click();
  457 | 
  458 |   await page.getByRole('tab', { name: 'Review decision' }).click();
  459 |   await expect(page.getByRole('button', { name: 'Approve and publish' })).toBeEnabled();
  460 | });
  461 | 
  462 | test('reviewer sees a generic failure, then keeps the published delivery', async ({ page }) => {
  463 |   // #529: the deployed resolution failed as an unexpected server error. The
  464 |   // reviewer must see the generic message with no server detail, and a retry that
  465 |   // keeps the published delivery must clear the conflict.
  466 |   let kept = false;
  467 |   const requests: unknown[] = [];
  468 |   const context = {
  469 |     eventReference: 'cricsheet:delivery:fixture-0-innings-0-delivery-32',
  470 |     fixtureId: '22',
  471 |     fixtureLabel: 'Lions vs Bears · 2026-09-01',
  472 |     inningsId: '31',
  473 |     overNumber: 5,
  474 |     positionInOver: 1,
  475 |     description: 'Event cricsheet:delivery:fixture-0-innings-0-delivery-32 at over 5, delivery 1.',
  476 |   };
  477 |   const location = {
  478 |     filePath: 'conflicting-season.json',
  479 |     sheetName: null,
  480 |     rowNumber: null,
  481 |     jsonPath: 'delivery',
  482 |     ordinal: 0,
  483 |   };
  484 |   const batch = () => ({
  485 |     batchReference: reference,
  486 |     competitionId: '5',
  487 |     status: 'awaiting_review',
  488 |     statusUrl: `/api/v1/batches/${reference}`,
  489 |     receivedAt: '2026-09-13T08:00:00.000Z',
  490 |     updatedAt: '2026-09-13T08:05:00.000Z',
  491 |     source: {
  492 |       fileName: 'conflicting-season.json',
  493 |       checksum: 'b'.repeat(64),
  494 |       packageVersion: '1.0',
  495 |       submitter: { accountId: '7', displayName: 'Data Submitter' },
  496 |     },
  497 |     progress: { total: 1, processed: 1, accepted: 0, rejected: kept ? 0 : 1 },
  498 |     counts: {
  499 |       accepted: 0,
  500 |       rejected: kept ? 0 : 1,
  501 |       unresolved: 0,
  502 |       duplicate: kept ? 1 : 0,
  503 |       conflicting: kept ? 0 : 1,
  504 |     },
  505 |     lineage: { replacesBatchReference: null, supersededByBatchReference: null },
  506 |     review: null,
  507 |   });
  508 |   const report = () => {
  509 |     const response = {
  510 |       data: {
  511 |         batch: batch(),
  512 |         errorGroups: kept ? [] : [{ ruleCode: 'PUBLISHED_DELIVERY_CONFLICT', count: 1 }],
  513 |         reviewSummary: {
  514 |           validation: {
  515 |             accepted: 0,
  516 |             rejected: kept ? 0 : 1,
  517 |             blockingErrors: kept ? 0 : 1,
  518 |             duplicate: kept ? 1 : 0,
  519 |             conflicting: kept ? 0 : 1,
  520 |           },
  521 |           resolution: { resolved: 1, ambiguous: 0, unresolved: 0, invalid: 0, proposed: 0 },
  522 |           approvalBlocked: !kept,
  523 |           blockingReasons: kept
  524 |             ? []
  525 |             : ['Blocking validation errors remain.', 'Conflicting records remain.'],
  526 |         },
  527 |         fixtureSummaries: [
  528 |           {
  529 |             fixtureId: '22',
  530 |             label: 'Lions vs Bears · 2026-09-01',
  531 |             total: 1,
  532 |             accepted: 0,
  533 |             rejected: kept ? 0 : 1,
  534 |             unresolved: 0,
  535 |           },
  536 |         ],
  537 |         participantOnboarding: [],
  538 |         acceptedSamples: [],
  539 |         items: [
  540 |           {
  541 |             ordinal: 0,
  542 |             outcome: kept ? 'duplicate' : 'conflicting',
  543 |             location,
  544 |             context,
  545 |             stagedRecordId: '41',
  546 |             acceptedRecordId: kept ? '2342246' : null,
  547 |             operation: 'upsert',
```