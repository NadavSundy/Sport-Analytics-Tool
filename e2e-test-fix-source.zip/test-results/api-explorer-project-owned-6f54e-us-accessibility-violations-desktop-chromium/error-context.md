# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: api-explorer.spec.ts >> project-owned explorer shell and controls have no serious accessibility violations
- Location: tests/e2e/api-explorer.spec.ts:148:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('.swagger-ui')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for locator('.swagger-ui')

```

```yaml
- link "Skip to main content":
  - /url: "#main-content"
- banner:
  - link "Stat'sTheGame home":
    - /url: /
    - img "Stat'sTheGame"
  - navigation "Public records":
    - button "Explore Data"
    - link "Downloads":
      - /url: /dataset-releases
    - link "API":
      - /url: /api
  - navigation "Account":
    - link "Sign in":
      - /url: /sign-in
  - text: Theme
  - checkbox "Switch to Night Match theme"
  - text: Day Match
- main:
  - heading "API Explorer" [level=1]
  - paragraph: Explore the authoritative Sport Analytics OpenAPI contract and try implemented endpoints directly from the browser.
  - 'region "Supported API major version: v1"':
    - paragraph: Public developer interface
    - 'heading "Supported API major version: v1" [level=2]'
    - paragraph: Choose the access type that matches your use case before exploring individual operations below.
    - navigation "API supporting resources":
      - link "API documentation":
        - /url: https://sports-analytics-tool.pages.dev/api/overview/
      - link "Dataset downloads":
        - /url: /dataset-releases
  - region "How to access the API":
    - paragraph: Access and authentication
    - heading "How to access the API" [level=2]
    - article:
      - heading "Public API" [level=3]
      - paragraph: Public operations can be used without authentication. They provide browsing and read access to published sports data.
    - article:
      - heading "Consumer API" [level=3]
      - paragraph:
        - text: External integrations use
        - code: /api/v1/consumer
        - text: operations. Every consumer operation requires an administrator-issued API key sent in the
        - code: X-API-Key
        - text: request header.
      - paragraph: Under the current access model, ask a Stat'sTheGame administrator or project administrator for API consumer access. Consumer requests have per-consumer rate limits and daily quotas.
      - paragraph: Keep the issued key in secure secret storage. Never place it in a URL, query string, browser bundle or logs.
      - link "Consumer API access and key guidance":
        - /url: https://sports-analytics-tool.pages.dev/api/consumer-keys/
    - article:
      - heading "Application and admin API" [level=3]
      - paragraph: Other authenticated application and administrator operations use the application's bearer authentication and role checks. A consumer API key does not grant administrator, submission or batch access.
    - paragraph:
      - text: In the explorer, use
      - strong: Authorize
      - text: to supply an issued credential at runtime.
  - region "Implementation status":
    - heading "Implementation status" [level=2]
    - paragraph: Implemented operations are interactive in Swagger. Planned contract entries are hidden by default and, when shown, appear separately as non-executable information.
    - checkbox "Show planned operations (1)"
    - text: Show planned operations (1)
  - region "OpenAPI v1 PUBLIC":
    - heading "OpenAPI v1 PUBLIC" [level=2]
    - paragraph: The interactive explorer is loaded on demand to keep this public page responsive.
    - button "Load interactive API Explorer"
- contentinfo:
  - img "Stat'sTheGame"
  - paragraph: The game, measured ball by ball.
  - navigation "Footer navigation":
    - link "API Explorer":
      - /url: /api
    - link "API Documentation":
      - /url: https://sports-analytics-tool.pages.dev/api/overview/
    - link "Privacy Notice":
      - /url: /privacy
    - link "Terms of Use":
      - /url: /terms
    - link "Accessibility":
      - /url: /accessibility
```

# Test source

```ts
  55  |     await page.goto('/');
  56  | 
  57  |     if ((page.viewportSize()?.width ?? 0) < 900) {
  58  |       await page.getByRole('button', { name: 'Menu' }).click();
  59  |       await page
  60  |         .getByRole('navigation', { name: 'Mobile navigation' })
  61  |         .getByRole('link', { name: 'API' })
  62  |         .click();
  63  |     } else {
  64  |       const navigation = page.getByRole('navigation', { name: 'Public records' });
  65  |       await expect(navigation.getByRole('link', { name: 'API' })).toBeVisible();
  66  |       await navigation.getByRole('link', { name: 'API' }).click();
  67  |     }
  68  | 
  69  |     await expect(page).toHaveURL(/\/api$/);
  70  |     await expect(page.getByRole('heading', { level: 1, name: 'API Explorer' })).toBeVisible();
  71  |     await expect(page.getByText('Supported API major version: v1')).toBeVisible();
  72  | 
  73  |     const accessRegion = page.getByRole('region', { name: 'How to access the API' });
  74  |     await expect(accessRegion.getByRole('heading', { name: 'Public API' })).toBeVisible();
  75  |     await expect(accessRegion.getByText(/without authentication/)).toBeVisible();
  76  |     await expect(accessRegion.getByRole('heading', { name: 'Consumer API' })).toBeVisible();
  77  |     await expect(accessRegion.getByText(/administrator-issued API key/)).toBeVisible();
  78  |     await expect(accessRegion.getByText(/X-API-Key/)).toBeVisible();
  79  |     await expect(accessRegion.getByText(/ask a Stat'sTheGame administrator/)).toBeVisible();
  80  |     await expect(accessRegion.getByText(/rate limits and daily quotas/)).toBeVisible();
  81  |     await expect(
  82  |       accessRegion.getByRole('link', { name: 'Consumer API access and key guidance' }),
  83  |     ).toHaveAttribute('href', 'https://sports-analytics-tool.pages.dev/api/consumer-keys/');
  84  |     await expect(
  85  |       accessRegion.getByRole('heading', { name: 'Application and admin API' }),
  86  |     ).toBeVisible();
  87  |     await expect(accessRegion.getByText(/does not grant administrator/)).toBeVisible();
  88  |     await expect(accessRegion).not.toContainText('sat_live_');
  89  | 
  90  |     await expect(
  91  |       page.locator('.swagger-ui .opblock-summary-path', { hasText: '/api/v1/health' }),
  92  |     ).toBeVisible();
  93  | 
  94  |     // The app owns title/version/onboarding, while endpoint-level Schema tabs
  95  |     // remain available inside Swagger. Duplicate/global Swagger chrome stays hidden.
  96  |     await expect(page.locator('.swagger-ui .info')).toBeHidden();
  97  |     await expect(page.locator('.swagger-ui section.models')).toHaveCount(0);
  98  | 
  99  |     await expect(
  100 |       page.locator('.swagger-ui .opblock-summary-path', {
  101 |         hasText: '/api/v1/future-statistic',
  102 |       }),
  103 |     ).toHaveCount(0);
  104 | 
  105 |     const pageOverflows = await page.evaluate(
  106 |       () => document.documentElement.scrollWidth > window.innerWidth + 1,
  107 |     );
  108 |     expect(pageOverflows).toBe(false);
  109 | 
  110 |     const footer = page.getByRole('contentinfo');
  111 |     await expect(footer.getByRole('link', { name: 'API Explorer' })).toHaveAttribute(
  112 |       'href',
  113 |       '/api',
  114 |     );
  115 |     await expect(footer.getByRole('link', { name: 'API Documentation' })).toHaveAttribute(
  116 |       'href',
  117 |       'https://sports-analytics-tool.pages.dev/api/overview/',
  118 |     );
  119 |   },
  120 | );
  121 | 
  122 | test('planned operations are explicit, separate from Swagger, and non-executable', async ({
  123 |   page,
  124 | }) => {
  125 |   await stubOpenApi(page);
  126 |   await page.goto('/api');
  127 | 
  128 |   await page.getByRole('checkbox', { name: /Show planned operations/ }).check();
  129 | 
  130 |   const plannedRegion = page.getByRole('region', { name: 'Planned operations' });
  131 |   await expect(plannedRegion).toBeVisible();
  132 |   await expect(plannedRegion.getByText('/api/v1/future-statistic')).toBeVisible();
  133 |   await expect(plannedRegion.getByText('Future statistic')).toBeVisible();
  134 |   await expect(plannedRegion.locator('.api-explorer__planned-state')).toHaveText('PLANNED');
  135 |   await expect(plannedRegion.getByRole('button')).toHaveCount(0);
  136 | 
  137 |   await expect(
  138 |     page.locator('.swagger-ui .opblock-summary-path', {
  139 |       hasText: '/api/v1/future-statistic',
  140 |     }),
  141 |   ).toHaveCount(0);
  142 | 
  143 |   await expect(
  144 |     page.locator('.swagger-ui .opblock-summary-path', { hasText: '/api/v1/health' }),
  145 |   ).toBeVisible();
  146 | });
  147 | 
  148 | test('project-owned explorer shell and controls have no serious accessibility violations', async ({
  149 |   page,
  150 | }) => {
  151 |   await stubOpenApi(page);
  152 |   await page.goto('/api');
  153 | 
  154 |   await expect(page.getByRole('heading', { level: 1, name: 'API Explorer' })).toBeVisible();
> 155 |   await expect(page.locator('.swagger-ui')).toBeVisible();
      |                                             ^ Error: expect(locator).toBeVisible() failed
  156 | 
  157 |   const results = await new AxeBuilder({ page }).exclude('.swagger-ui').analyze();
  158 |   const seriousOrCritical = results.violations.filter(
  159 |     (violation) => violation.impact === 'serious' || violation.impact === 'critical',
  160 |   );
  161 | 
  162 |   expect(seriousOrCritical).toEqual([]);
  163 | });
  164 | 
```