# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: corrections.spec.ts >> viewer is denied submission and is never offered a correction action
- Location: tests/e2e/corrections.spec.ts:358:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('heading', { name: 'Submitter role required' })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByRole('heading', { name: 'Submitter role required' })

```

```yaml
- link "Skip to main content":
  - /url: "#main-content"
- banner:
  - link "Stat'sTheGame home":
    - /url: /
    - img "Stat'sTheGame"
  - navigation "Public records":
    - button "Explore Data"
    - link "Downloads":
      - /url: /dataset-releases
    - link "API":
      - /url: /api
  - navigation "Account":
    - link "Sign in":
      - /url: /sign-in
  - text: Theme
  - checkbox "Switch to Night Match theme"
  - text: Day Match
- main:
  - region "Login or Sign up":
    - paragraph: Supabase managed authentication
    - heading "Login or Sign up" [level=1]
    - paragraph: Supabase will securely handle your Google login or sign-up.
    - button "Sign in with Google"
- contentinfo:
  - img "Stat'sTheGame"
  - paragraph: The game, measured ball by ball.
  - navigation "Footer navigation":
    - link "API Explorer":
      - /url: /api
    - link "API Documentation":
      - /url: https://sports-analytics-tool.pages.dev/api/overview/
    - link "Privacy Notice":
      - /url: /privacy
    - link "Terms of Use":
      - /url: /terms
    - link "Accessibility":
      - /url: /accessibility
```

# Test source

```ts
  269 |   await expect.poll(() => statisticsRequests).toBe(2);
  270 | 
  271 |   expect(
  272 |     await page.evaluate(
  273 |       () => document.documentElement.scrollWidth > document.documentElement.clientWidth,
  274 |     ),
  275 |   ).toBe(false);
  276 |   const accessibilityResults = await new AxeBuilder({ page }).analyze();
  277 |   expect(
  278 |     accessibilityResults.violations.filter(
  279 |       (violation) => violation.impact === 'serious' || violation.impact === 'critical',
  280 |     ),
  281 |   ).toEqual([]);
  282 | });
  283 | 
  284 | test('administrator correction validation remains associated with the relevant input', async ({
  285 |   page,
  286 | }) => {
  287 |   let statisticsRequests = 0;
  288 | 
  289 |   await page.route('**/api/v1/**', async (route) => {
  290 |     const request = route.request();
  291 |     const url = new URL(request.url());
  292 | 
  293 |     if (url.pathname.endsWith('/auth/me')) {
  294 |       await fulfill(route, 200, currentUser('admin'));
  295 |     } else if (url.pathname.endsWith('/competitions')) {
  296 |       await fulfill(route, 200, { data: competitions, pagination: { nextCursor: null } });
  297 |     } else if (url.pathname.endsWith('/fixtures')) {
  298 |       await fulfill(route, 200, {
  299 |         data: [fixture],
  300 |         pagination: { nextCursor: null, totalPages: 1 },
  301 |       });
  302 |     } else if (url.pathname.endsWith('/submissions') && request.method() === 'POST') {
  303 |       await fulfill(route, 201, {
  304 |         data: {
  305 |           submissionId: '300',
  306 |           fixtureId: '7',
  307 |           submitterId: '17',
  308 |           status: 'accepted',
  309 |           receivedAt: '2026-08-16T09:30:00.000Z',
  310 |           schemaVersion: '1.0',
  311 |           eventCount: 1,
  312 |         },
  313 |       });
  314 |     } else if (url.pathname.endsWith('/participants')) {
  315 |       await fulfill(route, 200, {
  316 |         data: [
  317 |           { participantId: '20', displayName: 'Opening Batter' },
  318 |           { participantId: '21', displayName: 'Non-striker' },
  319 |           { participantId: '22', displayName: 'Opening Bowler' },
  320 |         ],
  321 |         pagination: { nextCursor: null },
  322 |       });
  323 |     } else if (url.pathname.endsWith('/fixtures/7/statistics')) {
  324 |       statisticsRequests += 1;
  325 |       await fulfill(route, 200, statistics(4));
  326 |     } else if (url.pathname.endsWith(`/submissions/events/${eventId}`)) {
  327 |       await fulfill(route, 422, {
  328 |         error: {
  329 |           code: 'VALIDATION_FAILED',
  330 |           message: 'The correction is invalid.',
  331 |           details: [
  332 |             {
  333 |               code: 'INVALID_FIELD',
  334 |               message: 'Use a printed ball number such as 5.1.',
  335 |               field: 'event.ballNumber',
  336 |             },
  337 |           ],
  338 |         },
  339 |       });
  340 |     } else {
  341 |       await fulfill(route, 404, { error: { code: 'NOT_FOUND', message: 'Not found.' } });
  342 |     }
  343 |   });
  344 | 
  345 |   await openAcceptedSubmission(page);
  346 |   const ballNumber = page.getByLabel(/Printed ball number/);
  347 |   await ballNumber.fill('invalid');
  348 |   await page.getByLabel('Reason for correction').fill('Correct scorer transcription.');
  349 |   await page.getByRole('button', { name: 'Save correction' }).click();
  350 | 
  351 |   await expect(page.getByRole('heading', { name: 'Correction rejected' })).toBeFocused();
  352 |   await expect(ballNumber).toHaveAttribute('aria-invalid', 'true');
  353 |   await expect(ballNumber).toHaveAttribute('aria-describedby', /correction-ball-number-error/);
  354 |   await expect(page.getByText('Use a printed ball number such as 5.1.')).toBeVisible();
  355 |   expect(statisticsRequests).toBe(1);
  356 | });
  357 | 
  358 | test('viewer is denied submission and is never offered a correction action', async ({ page }) => {
  359 |   await page.route('**/api/v1/**', async (route) => {
  360 |     const url = new URL(route.request().url());
  361 |     if (url.pathname.endsWith('/auth/me')) {
  362 |       await fulfill(route, 200, currentUser('viewer'));
  363 |       return;
  364 |     }
  365 |     await fulfill(route, 403, { error: { code: 'FORBIDDEN', message: 'Forbidden.' } });
  366 |   });
  367 | 
  368 |   await page.goto('/submissions/new');
> 369 |   await expect(page.getByRole('heading', { name: 'Submitter role required' })).toBeVisible();
      |                                                                                ^ Error: expect(locator).toBeVisible() failed
  370 |   await expect(page.getByRole('button', { name: 'Submit events' })).toHaveCount(0);
  371 |   await expect(page.getByRole('button', { name: 'Save correction' })).toHaveCount(0);
  372 | });
  373 | 
```