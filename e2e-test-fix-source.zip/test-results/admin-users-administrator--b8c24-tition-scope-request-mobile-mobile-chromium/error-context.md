# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: admin-users.spec.ts >> administrator distinguishes and approves an additional competition scope request @mobile
- Location: tests/e2e/admin-users.spec.ts:200:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('table').getByText('Scope request pending')
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByRole('table').getByText('Scope request pending')

```

```yaml
- link "Skip to main content":
  - /url: "#main-content"
- banner:
  - link "Stat'sTheGame home":
    - /url: /
    - img "Stat'sTheGame"
  - text: Theme
  - checkbox "Switch to Night Match theme"
  - text: Day Match
  - button "Menu"
- main:
  - region "Login or Sign up":
    - paragraph: Supabase managed authentication
    - heading "Login or Sign up" [level=1]
    - paragraph: Supabase will securely handle your Google login or sign-up.
    - button "Sign in with Google"
- contentinfo:
  - img "Stat'sTheGame"
  - paragraph: The game, measured ball by ball.
  - navigation "Footer navigation":
    - link "API Explorer":
      - /url: /api
    - link "API Documentation":
      - /url: https://sports-analytics-tool.pages.dev/api/overview/
    - link "Privacy Notice":
      - /url: /privacy
    - link "Terms of Use":
      - /url: /terms
    - link "Accessibility":
      - /url: /accessibility
```

# Test source

```ts
  181 |   await expect(revokeButton).toBeFocused();
  182 | 
  183 |   await page.keyboard.press('Escape');
  184 |   await expect(dialog).toBeHidden();
  185 |   await expect(page.getByLabel('Search users')).toBeFocused();
  186 |   expect(
  187 |     await page.evaluate(
  188 |       () => document.documentElement.scrollWidth > document.documentElement.clientWidth,
  189 |     ),
  190 |   ).toBe(false);
  191 | 
  192 |   const results = await new AxeBuilder({ page }).analyze();
  193 |   expect(
  194 |     results.violations.filter(
  195 |       (violation) => violation.impact === 'serious' || violation.impact === 'critical',
  196 |     ),
  197 |   ).toEqual([]);
  198 | });
  199 | 
  200 | test('administrator distinguishes and approves an additional competition scope request @mobile', async ({
  201 |   page,
  202 | }) => {
  203 |   const administrator: ManagedUser = {
  204 |     id: '1',
  205 |     email: 'amina.administrator@example.com',
  206 |     displayName: 'Amina Administrator',
  207 |     role: 'admin',
  208 |     approvalState: 'not_requested',
  209 |     requestedCompetition: null,
  210 |     competitionScopes: [],
  211 |     disabled: false,
  212 |     previouslyRevoked: false,
  213 |     updatedAt: accessTime,
  214 |     submitterAccessUpdatedAt: null,
  215 |     submitterAccessUpdatedBy: null,
  216 |   };
  217 |   let submitter: ManagedUser = {
  218 |     id: '42',
  219 |     email: 'approved.submitter@example.com',
  220 |     displayName: 'Approved Submitter',
  221 |     role: 'submitter',
  222 |     approvalState: 'approved',
  223 |     requestedCompetition: availableScopes[1],
  224 |     competitionScopes: [availableScopes[0]],
  225 |     disabled: false,
  226 |     previouslyRevoked: false,
  227 |     updatedAt: accessTime,
  228 |     submitterAccessUpdatedAt: accessTime,
  229 |     submitterAccessUpdatedBy: { id: '1', displayName: 'Amina Administrator' },
  230 |   };
  231 | 
  232 |   await page.route('**/api/v1/auth/me', async (route) => {
  233 |     await route.fulfill({
  234 |       status: 200,
  235 |       contentType: 'application/json',
  236 |       body: JSON.stringify({
  237 |         user: {
  238 |           id: '1',
  239 |           subject: 'admin-subject',
  240 |           displayName: 'Amina Administrator',
  241 |           role: 'admin',
  242 |           approvalState: 'not_requested',
  243 |           requestedCompetition: null,
  244 |           competitionIds: [],
  245 |         },
  246 |       }),
  247 |     });
  248 |   });
  249 | 
  250 |   await page.route('**/api/v1/admin/users', async (route) => {
  251 |     await route.fulfill({
  252 |       status: 200,
  253 |       contentType: 'application/json',
  254 |       body: JSON.stringify({ data: { users: [administrator, submitter], availableScopes } }),
  255 |     });
  256 |   });
  257 | 
  258 |   await page.route('**/api/v1/admin/users/42/submitter-access', async (route) => {
  259 |     expect(route.request().method()).toBe('PATCH');
  260 |     expect(route.request().headers().authorization).toContain('Bearer ');
  261 |     expect(route.request().postDataJSON()).toEqual({
  262 |       approved: true,
  263 |       competitionIds: ['7', '8'],
  264 |     });
  265 |     submitter = {
  266 |       ...submitter,
  267 |       requestedCompetition: null,
  268 |       competitionScopes: availableScopes,
  269 |       submitterAccessUpdatedAt: accessTime,
  270 |       submitterAccessUpdatedBy: { id: '1', displayName: 'Amina Administrator' },
  271 |     };
  272 |     await route.fulfill({
  273 |       status: 200,
  274 |       contentType: 'application/json',
  275 |       body: JSON.stringify({ data: submitter }),
  276 |     });
  277 |   });
  278 | 
  279 |   await page.goto('/admin/users');
  280 | 
> 281 |   await expect(page.getByRole('table').getByText('Scope request pending')).toBeVisible();
      |                                                                            ^ Error: expect(locator).toBeVisible() failed
  282 |   const manage = page.getByRole('button', { name: 'Manage approved.submitter@example.com' });
  283 |   await manage.click();
  284 | 
  285 |   const dialog = page.getByRole('dialog', { name: 'Approved Submitter' });
  286 |   await expect(dialog.getByText('Pending additional scope request')).toBeVisible();
  287 |   await expect(
  288 |     dialog.locator('.admin-user-facts').getByText('University League', { exact: true }),
  289 |   ).toBeVisible();
  290 |   await expect(dialog.getByText(/requested University League/i)).toBeVisible();
  291 |   await expect(dialog.getByRole('checkbox', { name: 'Premier T20' })).toBeChecked();
  292 |   await expect(dialog.getByRole('checkbox', { name: 'University League' })).toBeChecked();
  293 |   await expect(dialog.getByRole('button', { name: 'Reject scope request' })).toBeVisible();
  294 | 
  295 |   await dialog.getByRole('button', { name: 'Approve additional scope' }).click();
  296 |   await expect(dialog.getByRole('alertdialog')).toContainText(
  297 |     "Approve approved.submitter@example.com's additional scope request for University League?",
  298 |   );
  299 |   await dialog.getByRole('button', { name: 'Confirm change' }).click();
  300 | 
  301 |   await expect(dialog.getByText(/competition scope was updated/i)).toBeVisible();
  302 |   await expect(dialog.getByText('Pending additional scope request')).toHaveCount(0);
  303 |   await expect(dialog.getByRole('checkbox', { name: 'Premier T20' })).toBeChecked();
  304 |   await expect(dialog.getByRole('checkbox', { name: 'University League' })).toBeChecked();
  305 | 
  306 |   const hasHorizontalOverflow = await page.evaluate(
  307 |     () => document.documentElement.scrollWidth > document.documentElement.clientWidth,
  308 |   );
  309 |   expect(hasHorizontalOverflow).toBe(false);
  310 | 
  311 |   const results = await new AxeBuilder({ page }).analyze();
  312 |   expect(
  313 |     results.violations.filter(
  314 |       (violation) => violation.impact === 'serious' || violation.impact === 'critical',
  315 |     ),
  316 |   ).toEqual([]);
  317 | });
  318 | 
```