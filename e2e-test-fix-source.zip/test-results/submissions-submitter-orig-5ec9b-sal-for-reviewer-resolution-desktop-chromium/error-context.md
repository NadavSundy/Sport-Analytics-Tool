# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: submissions.spec.ts >> submitter originates a new fixture proposal for reviewer resolution
- Location: tests/e2e/submissions.spec.ts:218:5

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: 'Propose a new fixture' })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to main content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - banner [ref=e5]:
    - generic [ref=e6]:
      - link "Stat'sTheGame home" [ref=e7] [cursor=pointer]:
        - /url: /
        - img "Stat'sTheGame" [ref=e9]
      - navigation "Public records" [ref=e10]:
        - button "Explore Data" [ref=e12] [cursor=pointer]: Explore Data ▾
        - link "Downloads" [ref=e13] [cursor=pointer]:
          - /url: /dataset-releases
        - link "API" [ref=e14] [cursor=pointer]:
          - /url: /api
      - generic [ref=e15]:
        - navigation "Account" [ref=e16]:
          - link "Sign in" [ref=e17] [cursor=pointer]:
            - /url: /sign-in
        - generic [ref=e18]:
          - generic [ref=e19]: Theme
          - generic [ref=e20] [cursor=pointer]:
            - checkbox "Switch to Night Match theme" [ref=e21]
            - generic [ref=e24]: Day Match
  - main [ref=e25]:
    - region [ref=e27]:
      - generic [ref=e28]:
        - paragraph [ref=e29]: Supabase managed authentication
        - heading "Login or Sign up" [level=1] [ref=e30]
        - paragraph [ref=e31]: Supabase will securely handle your Google login or sign-up.
        - button "Sign in with Google" [ref=e32] [cursor=pointer]:
          - generic [ref=e38]: Sign in
  - contentinfo [ref=e39]:
    - generic [ref=e40]:
      - generic [ref=e41]:
        - img "Stat'sTheGame" [ref=e43]
        - paragraph [ref=e44]: The game, measured ball by ball.
      - navigation "Footer navigation" [ref=e45]:
        - link "API Explorer" [ref=e46] [cursor=pointer]:
          - /url: /api
        - link "API Documentation" [ref=e47] [cursor=pointer]:
          - /url: https://sports-analytics-tool.pages.dev/api/overview/
        - link "Privacy Notice" [ref=e48] [cursor=pointer]:
          - /url: /privacy
        - link "Terms of Use" [ref=e49] [cursor=pointer]:
          - /url: /terms
        - link "Accessibility" [ref=e50] [cursor=pointer]:
          - /url: /accessibility
```

# Test source

```ts
  165 |   });
  166 | });
  167 | 
  168 | test('Manage Submission opens the unified submission workflow', async ({ page }) => {
  169 |   await page.goto('/account/overview');
  170 |   await page.getByRole('button', { name: 'Manage Submission' }).click();
  171 |   await page.getByRole('link', { name: 'Submit data' }).click();
  172 | 
  173 |   await expect(page).toHaveURL(/\/submissions\/new$/);
  174 |   await expect(page.getByRole('heading', { name: 'Submit data' })).toBeVisible();
  175 |   await expect(page.getByRole('radio', { name: /Single fixture/ })).toBeChecked();
  176 |   await expect(page.getByRole('radio', { name: /Season/ })).toBeVisible();
  177 |   await expect(page.getByRole('radio', { name: /Back catalogue/ })).toBeVisible();
  178 |   await expect(page.getByRole('radio', { name: /Advanced technical JSON/ })).toBeVisible();
  179 |   await expect(page.getByRole('link', { name: 'Upload a batch' })).toHaveCount(0);
  180 | 
  181 |   // #500: the guided scopes and the identifier-based mode are separate groups,
  182 |   // and the default guided path shows no JSON editor.
  183 |   const guided = page.getByRole('group', { name: /Guided upload/ });
  184 |   const advanced = page.getByRole('group', { name: /application identifiers required/ });
  185 |   await expect(guided.getByRole('radio')).toHaveCount(3);
  186 |   await expect(guided.getByRole('radio', { name: /Advanced technical JSON/ })).toHaveCount(0);
  187 |   await expect(advanced.getByRole('radio', { name: /Advanced technical JSON/ })).toBeVisible();
  188 |   await expect(page.getByLabel('Delivery events JSON')).toHaveCount(0);
  189 | });
  190 | 
  191 | test('submission workspace uses the centred responsive content boundary', async ({ page }) => {
  192 |   await page.goto('/submissions/new');
  193 | 
  194 |   for (const viewport of [
  195 |     { width: 375, expectedWidth: 351 },
  196 |     { width: 768, expectedWidth: 720 },
  197 |     { width: 1440, expectedWidth: 1200 },
  198 |     { width: 1920, expectedWidth: 1200 },
  199 |   ]) {
  200 |     await page.setViewportSize({ width: viewport.width, height: 900 });
  201 | 
  202 |     const layout = await page.locator('.submission-page').evaluate((element) => {
  203 |       const rect = element.getBoundingClientRect();
  204 |       return {
  205 |         left: Math.round(rect.left),
  206 |         right: Math.round(window.innerWidth - rect.right),
  207 |         width: Math.round(rect.width),
  208 |         overflows: document.documentElement.scrollWidth > document.documentElement.clientWidth,
  209 |       };
  210 |     });
  211 | 
  212 |     expect(layout.width).toBe(viewport.expectedWidth);
  213 |     expect(Math.abs(layout.left - layout.right)).toBeLessThanOrEqual(1);
  214 |     expect(layout.overflows).toBe(false);
  215 |   }
  216 | });
  217 | 
  218 | test('submitter originates a new fixture proposal for reviewer resolution', async ({ page }) => {
  219 |   await page.route('**/api/v1/batches', async (route) => {
  220 |     const request = route.request();
  221 |     expect(request.method()).toBe('POST');
  222 |     expect(request.headers()['x-batch-package-version']).toBe('1.1');
  223 |     expect(request.headers()['x-competition-id']).toBe('5');
  224 |     expect(request.postDataJSON()).toMatchObject({
  225 |       contractVersion: '1.1',
  226 |       competition: { context: { name: 'Example Competition' } },
  227 |       season: { context: { name: '2026' } },
  228 |       fixtures: [
  229 |         {
  230 |           sourceId: expect.stringMatching(/^submitter:fixture:/),
  231 |           context: {
  232 |             date: fixture.startDate,
  233 |             teams: [{ context: { name: 'Wanderers' } }, { context: { name: 'Strikers' } }],
  234 |           },
  235 |           proposal: {
  236 |             endDate: fixture.startDate,
  237 |             matchType: 'T20',
  238 |             teamType: 'club',
  239 |             gender: 'female',
  240 |             ballsPerOver: 6,
  241 |             outcome: 'won',
  242 |             winner: 'Wanderers',
  243 |             sourceVersion: '1',
  244 |             sourceRevision: 0,
  245 |           },
  246 |         },
  247 |       ],
  248 |     });
  249 |     expect(seasonUploadPackageSchema.safeParse(request.postDataJSON()).success).toBe(true);
  250 |     await route.fulfill({
  251 |       status: 202,
  252 |       contentType: 'application/json',
  253 |       body: JSON.stringify({
  254 |         data: {
  255 |           batchReference,
  256 |           status: 'stored',
  257 |           statusUrl: `/api/v1/batches/${batchReference}`,
  258 |           receivedAt: '2026-09-15T09:30:00.000Z',
  259 |         },
  260 |       }),
  261 |     });
  262 |   });
  263 | 
  264 |   await page.goto('/submissions/new');
> 265 |   await page.getByRole('button', { name: 'Propose a new fixture' }).click();
      |                                                                     ^ Error: locator.click: Test timeout of 30000ms exceeded.
  266 |   await expect(page.getByRole('group', { name: 'New fixture metadata' })).toBeVisible();
  267 |   await expect(page.getByRole('combobox', { name: 'Competition' })).toHaveValue(
  268 |     'Example Competition',
  269 |   );
  270 |   await page.getByLabel('Season name').fill('2026');
  271 |   await page.getByLabel('Fixture date').fill(fixture.startDate);
  272 |   await page.getByLabel('Home team name').fill('Wanderers');
  273 |   await page.getByLabel('Away team name').fill('Strikers');
  274 |   await expect(page.getByLabel('Match type')).toHaveValue('T20');
  275 |   await page.getByLabel('Team type').selectOption('club');
  276 |   await page.getByLabel('Gender').selectOption('female');
  277 |   await page.getByLabel('Outcome').selectOption('won');
  278 |   await page.getByLabel('Winning team').selectOption('Wanderers');
  279 |   await page.getByLabel('Fixture package').setInputFiles({
  280 |     name: 'new-fixture.json',
  281 |     mimeType: 'application/json',
  282 |     buffer: Buffer.from(readableFixturePackage()),
  283 |   });
  284 |   await page.getByRole('button', { name: 'Upload fixture package' }).click();
  285 | 
  286 |   await expect(page.getByRole('heading', { name: 'Fixture upload received' })).toBeFocused();
  287 |   await expect(page.getByText(batchReference, { exact: true })).toBeVisible();
  288 |   await expect(page.getByText(/administrator can create the canonical fixture/i)).toBeVisible();
  289 | });
  290 | 
  291 | test('submitter stages advanced technical JSON with a keyboard', async ({ page }) => {
  292 |   await page.route('**/api/v1/batches', async (route) => {
  293 |     const request = route.request();
  294 |     expect(request.method()).toBe('POST');
  295 |     expect(request.headers()['x-competition-id']).toBe('5');
  296 |     expect(request.headers()['x-file-name']).toBe('technical-7.json');
  297 |     expect(request.postDataJSON()).toMatchObject({
  298 |       contractVersion: '1.0',
  299 |       fixtures: [
  300 |         {
  301 |           sourceId: 'app:fixture:7',
  302 |           innings: [
  303 |             {
  304 |               sourceId: 'app:innings:10',
  305 |               events: [
  306 |                 {
  307 |                   eventId: `app:delivery:${events[0]!.eventId}`,
  308 |                   striker: { sourceId: 'app:participant:20' },
  309 |                   nonStriker: { sourceId: 'app:participant:21' },
  310 |                   bowler: { sourceId: 'app:participant:22' },
  311 |                 },
  312 |               ],
  313 |             },
  314 |           ],
  315 |         },
  316 |       ],
  317 |     });
  318 | 
  319 |     await route.fulfill({
  320 |       status: 202,
  321 |       contentType: 'application/json',
  322 |       body: JSON.stringify({
  323 |         data: {
  324 |           batchReference,
  325 |           status: 'stored',
  326 |           statusUrl: `/api/v1/batches/${batchReference}`,
  327 |           receivedAt: '2026-08-16T09:30:00.000Z',
  328 |         },
  329 |       }),
  330 |     });
  331 |   });
  332 | 
  333 |   await page.goto('/submissions/new');
  334 |   await page.getByRole('radio', { name: /Advanced technical JSON/ }).click();
  335 | 
  336 |   const competitionSelector = page.getByRole('combobox', { name: 'Competition' });
  337 |   const fixtureSelector = page.getByLabel('Fixture', { exact: true });
  338 |   const editor = page.getByLabel('Delivery events JSON');
  339 |   const submitButton = page.getByRole('button', { name: 'Submit events' });
  340 | 
  341 |   await competitionSelector.fill('Exam Comp');
  342 |   await expect(page.getByRole('option', { name: /Example Competition/ })).toBeVisible();
  343 |   await competitionSelector.press('ArrowDown');
  344 |   await competitionSelector.press('Enter');
  345 |   await expect(competitionSelector).toHaveValue('Example Competition');
  346 | 
  347 |   await fixtureSelector.fill('wander');
  348 |   await expect(page.getByRole('option', { name: /Wanderers v Strikers/ })).toBeVisible();
  349 |   await fixtureSelector.press('ArrowDown');
  350 |   await fixtureSelector.press('Enter');
  351 |   await expect(fixtureSelector).toHaveValue(
  352 |     '2026-08-20 — Wanderers v Strikers — Example Competition, 2026 (T20)',
  353 |   );
  354 |   await editor.fill(JSON.stringify(events, null, 2));
  355 | 
  356 |   await submitButton.focus();
  357 |   await page.keyboard.press('Enter');
  358 | 
  359 |   const stagedHeading = page.locator(
  360 |     'h1:focus, h2:focus, h3:focus, h4:focus, h5:focus, h6:focus, [role="heading"]:focus',
  361 |   );
  362 |   await expect(stagedHeading).toBeFocused();
  363 |   await expect(page.getByText(batchReference, { exact: true })).toBeVisible();
  364 |   await expect(page.locator(`a[href="/submissions/batches/${batchReference}"]`)).toHaveAttribute(
  365 |     'href',
```