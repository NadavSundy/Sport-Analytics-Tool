# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: admin-dataset-releases.spec.ts >> administrator publishes a snapshot that appears in the public catalogue @mobile
- Location: tests/e2e/admin-dataset-releases.spec.ts:71:5

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('link', { name: 'Publish dataset release' })
Expected: visible
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" with timeout 5000ms
  - waiting for getByRole('link', { name: 'Publish dataset release' })

```

```yaml
- link "Skip to main content":
  - /url: "#main-content"
- banner:
  - link "Stat'sTheGame home":
    - /url: /
    - img "Stat'sTheGame"
  - text: Theme
  - checkbox "Switch to Night Match theme"
  - text: Day Match
  - button "Menu"
- main:
  - region "Login or Sign up":
    - paragraph: Supabase managed authentication
    - heading "Login or Sign up" [level=1]
    - paragraph: Supabase will securely handle your Google login or sign-up.
    - button "Sign in with Google"
- contentinfo:
  - img "Stat'sTheGame"
  - paragraph: The game, measured ball by ball.
  - navigation "Footer navigation":
    - link "API Explorer":
      - /url: /api
    - link "API Documentation":
      - /url: https://sports-analytics-tool.pages.dev/api/overview/
    - link "Privacy Notice":
      - /url: /privacy
    - link "Terms of Use":
      - /url: /terms
    - link "Accessibility":
      - /url: /accessibility
```

# Test source

```ts
  34  | test.beforeEach(async ({ page }) => {
  35  |   const expiresAt = Math.floor(Date.now() / 1_000) + 3_600;
  36  |   const header = Buffer.from(JSON.stringify({ alg: 'HS256', typ: 'JWT' })).toString('base64url');
  37  |   const payload = Buffer.from(
  38  |     JSON.stringify({ aud: 'authenticated', exp: expiresAt, sub: 'admin-subject' }),
  39  |   ).toString('base64url');
  40  |   await page.addInitScript(
  41  |     ({ storageKey, accessToken, tokenExpiry }) => {
  42  |       window.localStorage.setItem(
  43  |         storageKey,
  44  |         JSON.stringify({
  45  |           access_token: accessToken,
  46  |           refresh_token: 'managed-by-supabase',
  47  |           expires_in: 3_600,
  48  |           expires_at: tokenExpiry,
  49  |           token_type: 'bearer',
  50  |           user: {
  51  |             id: 'admin-subject',
  52  |             aud: 'authenticated',
  53  |             role: 'authenticated',
  54  |             email: 'admin@example.com',
  55  |             app_metadata: {},
  56  |             user_metadata: {},
  57  |             identities: [],
  58  |             created_at: '2026-09-10T10:00:00.000Z',
  59  |           },
  60  |         }),
  61  |       );
  62  |     },
  63  |     {
  64  |       storageKey: authStorageKey,
  65  |       accessToken: `${header}.${payload}.e2e-signature`,
  66  |       tokenExpiry: expiresAt,
  67  |     },
  68  |   );
  69  | });
  70  | 
  71  | test('administrator publishes a snapshot that appears in the public catalogue @mobile', async ({
  72  |   page,
  73  | }) => {
  74  |   let releaseRequests = 0;
  75  |   let jobRequests = 0;
  76  | 
  77  |   await page.route('**/api/v1/auth/me', async (route) => {
  78  |     await route.fulfill({
  79  |       status: 200,
  80  |       contentType: 'application/json',
  81  |       body: JSON.stringify({
  82  |         user: {
  83  |           id: '1',
  84  |           subject: 'admin-subject',
  85  |           displayName: 'Amina Administrator',
  86  |           role: 'admin',
  87  |           approvalState: 'not_requested',
  88  |           requestedCompetition: null,
  89  |           competitionIds: [],
  90  |         },
  91  |       }),
  92  |     });
  93  |   });
  94  |   await page.route('**/api/v1/admin/dataset-releases', async (route) => {
  95  |     releaseRequests += 1;
  96  |     expect(route.request().headers().authorization).toContain('Bearer ');
  97  |     expect(route.request().postDataJSON()).toEqual({ version: release.version });
  98  |     await route.fulfill({
  99  |       status: 202,
  100 |       contentType: 'application/json',
  101 |       body: JSON.stringify({ data: job }),
  102 |     });
  103 |   });
  104 |   await page.route(`**/api/v1/admin/dataset-release-jobs/${job.jobId}`, async (route) => {
  105 |     jobRequests += 1;
  106 |     const generating = jobRequests === 1;
  107 |     await route.fulfill({
  108 |       status: 200,
  109 |       contentType: 'application/json',
  110 |       body: JSON.stringify({
  111 |         data: {
  112 |           ...job,
  113 |           status: generating ? 'generating' : 'completed',
  114 |           eventsProcessed: generating ? 10000 : release.eventCount,
  115 |           bytesWritten: generating ? 42000 : 123456,
  116 |           pageNumber: 1,
  117 |           startedAt: release.createdAt,
  118 |           completedAt: generating ? null : release.createdAt,
  119 |           release: generating ? null : release,
  120 |         },
  121 |       }),
  122 |     });
  123 |   });
  124 |   await page.route('**/api/v1/dataset-releases', async (route) => {
  125 |     await route.fulfill({
  126 |       status: 200,
  127 |       contentType: 'application/json',
  128 |       body: JSON.stringify({ data: [release] }),
  129 |     });
  130 |   });
  131 | 
  132 |   await page.goto('/admin');
  133 |   const publishLink = page.getByRole('link', { name: 'Publish dataset release' });
> 134 |   await expect(publishLink).toBeVisible();
      |                             ^ Error: expect(locator).toBeVisible() failed
  135 |   await publishLink.click();
  136 | 
  137 |   await expect(page.getByRole('heading', { name: 'Publish dataset release' })).toBeVisible();
  138 |   await expect(page.getByText(/queues generation outside this page/i)).toBeVisible();
  139 |   await page.getByRole('textbox', { name: 'Release version' }).fill(release.version);
  140 |   await page.getByRole('button', { name: 'Generate and publish snapshot' }).click();
  141 | 
  142 |   const status = page.getByRole('status');
  143 |   await expect(status.getByRole('heading', { name: `Dataset ${release.version}` })).toBeVisible();
  144 |   await expect(status.getByText('10 000')).toBeVisible();
  145 |   expect(releaseRequests).toBe(1);
  146 |   await status.getByRole('link', { name: 'Browse release catalogue' }).click({ timeout: 4000 });
  147 |   await expect(page.getByRole('link', { name: `Dataset ${release.version}` })).toBeVisible();
  148 |   await expect(page.getByText('3 207 110')).toBeVisible();
  149 |   await expect(page.getByText(/unexpected response/i)).toHaveCount(0);
  150 | 
  151 |   expect(
  152 |     await page.evaluate(
  153 |       () => document.documentElement.scrollWidth > document.documentElement.clientWidth,
  154 |     ),
  155 |   ).toBe(false);
  156 |   const results = await new AxeBuilder({ page }).analyze();
  157 |   expect(
  158 |     results.violations.filter(
  159 |       (violation) => violation.impact === 'serious' || violation.impact === 'critical',
  160 |     ),
  161 |   ).toEqual([]);
  162 | });
  163 | 
```