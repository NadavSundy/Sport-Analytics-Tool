# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: authentication.spec.ts >> stored Supabase identity updates navigation and can sign out
- Location: tests/e2e/authentication.spec.ts:165:5

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator: getByRole('link', { name: 'Manage account' })
Expected: "/account"
Timeout: 5000ms
Error: element(s) not found

Call log:
  - Expect "toHaveAttribute" with timeout 5000ms
  - waiting for getByRole('link', { name: 'Manage account' })

```

```yaml
- link "Skip to main content":
  - /url: "#main-content"
- banner:
  - link "Stat'sTheGame home":
    - /url: /
    - img "Stat'sTheGame"
  - navigation "Public records":
    - button "Explore Data"
    - link "Downloads":
      - /url: /dataset-releases
    - link "API":
      - /url: /api
  - navigation "Account":
    - link "Sign in":
      - /url: /sign-in
  - text: Theme
  - checkbox "Switch to Night Match theme"
  - text: Day Match
- main:
  - region "Account":
    - paragraph: Identity and access
    - heading "Account" [level=1]
    - paragraph:
      - text: You are signed out.
      - link "Login or Sign up":
        - /url: /sign-in
      - text: to view your account.
- contentinfo:
  - img "Stat'sTheGame"
  - paragraph: The game, measured ball by ball.
  - navigation "Footer navigation":
    - link "API Explorer":
      - /url: /api
    - link "API Documentation":
      - /url: https://sports-analytics-tool.pages.dev/api/overview/
    - link "Privacy Notice":
      - /url: /privacy
    - link "Terms of Use":
      - /url: /terms
    - link "Accessibility":
      - /url: /accessibility
```

# Test source

```ts
  77  |     await expect(googleAction).toBeFocused();
  78  | 
  79  |     const oauthRequest = page.waitForRequest(
  80  |       (request) =>
  81  |         request.url().startsWith('https://e2e.supabase.co/auth/v1/authorize') &&
  82  |         request.url().includes('provider=google'),
  83  |     );
  84  |     await page.route('https://e2e.supabase.co/auth/v1/authorize**', async (route) => {
  85  |       await route.fulfill({ contentType: 'text/html', body: '<p>Managed OAuth boundary</p>' });
  86  |     });
  87  | 
  88  |     await page.keyboard.press('Enter');
  89  | 
  90  |     const port = process.env.PLAYWRIGHT_PORT ?? '4173';
  91  |     expect((await oauthRequest).url()).toContain(encodeURIComponent(`http://127.0.0.1:${port}/`));
  92  |   },
  93  | );
  94  | 
  95  | test('OAuth cancellation returns a safe signed-out callback state', async ({ page }) => {
  96  |   await isolateSupabaseClientLock(page);
  97  | 
  98  |   await page.goto('/auth/callback#error=access_denied&error_description=private+provider+detail');
  99  | 
  100 |   await expect(page.getByRole('heading', { name: 'Completing Sign In' })).toBeVisible();
  101 | 
  102 |   await expect(page.getByRole('alert')).toHaveText('Sign-in was cancelled. No changes were made.');
  103 | 
  104 |   await expect(page).toHaveURL(/\/auth\/callback$/);
  105 | 
  106 |   await expect(page.getByText(/private provider detail/i)).toHaveCount(0);
  107 | 
  108 |   await expect(page.getByRole('link', { name: 'Try Again' })).toHaveAttribute('href', '/sign-in');
  109 | 
  110 |   await expect(page.getByRole('link', { name: 'Return Home' })).toHaveAttribute('href', '/');
  111 | 
  112 |   await expect(
  113 |     page.getByRole('navigation', { name: 'Account' }).getByRole('link', {
  114 |       name: 'Sign in',
  115 |     }),
  116 |   ).toBeVisible();
  117 | });
  118 | 
  119 | test('OAuth provider failure returns a safe recoverable callback state', async ({ page }) => {
  120 |   await isolateSupabaseClientLock(page);
  121 | 
  122 |   await page.goto(
  123 |     '/auth/callback?error=server_error&error_code=500&error_description=provider+secret+response',
  124 |   );
  125 | 
  126 |   await expect(page.getByRole('alert')).toHaveText(
  127 |     'We could not complete sign-in. Please try again.',
  128 |   );
  129 | 
  130 |   await expect(page).toHaveURL(/\/auth\/callback$/);
  131 | 
  132 |   await expect(page.getByText(/provider secret response/i)).toHaveCount(0);
  133 | 
  134 |   await expect(page.getByRole('link', { name: 'Try Again' })).toBeVisible();
  135 | 
  136 |   await expect(page.getByRole('link', { name: 'Return Home' })).toBeVisible();
  137 | });
  138 | 
  139 | test('stored Supabase identity completes the callback and opens the account', async ({ page }) => {
  140 |   await isolateSupabaseClientLock(page);
  141 | 
  142 |   await page.addInitScript(({ key, value }) => window.localStorage.setItem(key, value), {
  143 |     key: authStorageKey,
  144 |     value: createStoredSession(),
  145 |   });
  146 | 
  147 |   await page.goto('/auth/callback');
  148 | 
  149 |   await expect(page).toHaveURL(/\/account\/overview$/);
  150 | 
  151 |   await expect(page.getByRole('heading', { name: 'Account', exact: true })).toBeVisible();
  152 | 
  153 |   await expect(page.getByText('browser@example.com')).toBeVisible();
  154 | 
  155 |   await expect(page.getByRole('link', { name: 'Account management' })).toHaveAttribute(
  156 |     'href',
  157 |     '/account/security',
  158 |   );
  159 |   await expect(page.getByRole('link', { name: 'Manage account' })).toHaveAttribute(
  160 |     'href',
  161 |     '/account',
  162 |   );
  163 | });
  164 | 
  165 | test('stored Supabase identity updates navigation and can sign out', async ({ page }) => {
  166 |   await isolateSupabaseClientLock(page);
  167 |   await page.addInitScript(({ key, value }) => window.localStorage.setItem(key, value), {
  168 |     key: authStorageKey,
  169 |     value: createStoredSession(),
  170 |   });
  171 |   await page.route('https://e2e.supabase.co/auth/v1/logout**', async (route) => {
  172 |     await route.fulfill({ status: 204 });
  173 |   });
  174 | 
  175 |   await page.goto('/account/security');
  176 | 
> 177 |   await expect(page.getByRole('link', { name: 'Manage account' })).toHaveAttribute(
      |                                                                    ^ Error: expect(locator).toHaveAttribute(expected) failed
  178 |     'href',
  179 |     '/account',
  180 |   );
  181 |   await expect(page.getByRole('link', { name: 'Account management' })).toHaveAttribute(
  182 |     'href',
  183 |     '/account/security',
  184 |   );
  185 |   await expect(page.getByRole('button', { name: 'Sign out' })).toBeVisible();
  186 |   await expect(page.getByRole('link', { name: 'Sign in' })).toHaveCount(0);
  187 | 
  188 |   const signOut = page.getByRole('button', { name: 'Sign out' });
  189 |   await signOut.focus();
  190 |   await expect(signOut).toBeFocused();
  191 |   await page.keyboard.press('Enter');
  192 | 
  193 |   await expect(page).toHaveURL('/');
  194 |   await expect(await signedOutNavigationAction(page)).toBeVisible();
  195 |   await expect(page.getByRole('button', { name: 'Sign out' })).toHaveCount(0);
  196 | });
  197 | 
```