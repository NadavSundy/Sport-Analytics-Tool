# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: submissions.spec.ts >> technical JSON schema errors remain associated with the editor and receive focus
- Location: tests/e2e/submissions.spec.ts:382:5

# Error details

```
Test timeout of 30000ms exceeded.
```

```
Error: locator.click: Test timeout of 30000ms exceeded.
Call log:
  - waiting for getByRole('radio', { name: /Advanced technical JSON/ })

```

# Page snapshot

```yaml
- generic [ref=e3]:
  - link "Skip to main content" [ref=e4] [cursor=pointer]:
    - /url: "#main-content"
  - banner [ref=e5]:
    - generic [ref=e6]:
      - link "Stat'sTheGame home" [ref=e7] [cursor=pointer]:
        - /url: /
        - img "Stat'sTheGame" [ref=e9]
      - navigation "Public records" [ref=e10]:
        - button "Explore Data" [ref=e12] [cursor=pointer]: Explore Data ▾
        - link "Downloads" [ref=e13] [cursor=pointer]:
          - /url: /dataset-releases
        - link "API" [ref=e14] [cursor=pointer]:
          - /url: /api
      - generic [ref=e15]:
        - navigation "Account" [ref=e16]:
          - link "Sign in" [ref=e17] [cursor=pointer]:
            - /url: /sign-in
        - generic [ref=e18]:
          - generic [ref=e19]: Theme
          - generic [ref=e20] [cursor=pointer]:
            - checkbox "Switch to Night Match theme" [ref=e21]
            - generic [ref=e24]: Day Match
  - main [ref=e25]:
    - region [ref=e27]:
      - generic [ref=e28]:
        - paragraph [ref=e29]: Supabase managed authentication
        - heading "Login or Sign up" [level=1] [ref=e30]
        - paragraph [ref=e31]: Supabase will securely handle your Google login or sign-up.
        - button "Sign in with Google" [ref=e32] [cursor=pointer]:
          - generic [ref=e38]: Sign in
  - contentinfo [ref=e39]:
    - generic [ref=e40]:
      - generic [ref=e41]:
        - img "Stat'sTheGame" [ref=e43]
        - paragraph [ref=e44]: The game, measured ball by ball.
      - navigation "Footer navigation" [ref=e45]:
        - link "API Explorer" [ref=e46] [cursor=pointer]:
          - /url: /api
        - link "API Documentation" [ref=e47] [cursor=pointer]:
          - /url: https://sports-analytics-tool.pages.dev/api/overview/
        - link "Privacy Notice" [ref=e48] [cursor=pointer]:
          - /url: /privacy
        - link "Terms of Use" [ref=e49] [cursor=pointer]:
          - /url: /terms
        - link "Accessibility" [ref=e50] [cursor=pointer]:
          - /url: /accessibility
```

# Test source

```ts
  291 | test('submitter stages advanced technical JSON with a keyboard', async ({ page }) => {
  292 |   await page.route('**/api/v1/batches', async (route) => {
  293 |     const request = route.request();
  294 |     expect(request.method()).toBe('POST');
  295 |     expect(request.headers()['x-competition-id']).toBe('5');
  296 |     expect(request.headers()['x-file-name']).toBe('technical-7.json');
  297 |     expect(request.postDataJSON()).toMatchObject({
  298 |       contractVersion: '1.0',
  299 |       fixtures: [
  300 |         {
  301 |           sourceId: 'app:fixture:7',
  302 |           innings: [
  303 |             {
  304 |               sourceId: 'app:innings:10',
  305 |               events: [
  306 |                 {
  307 |                   eventId: `app:delivery:${events[0]!.eventId}`,
  308 |                   striker: { sourceId: 'app:participant:20' },
  309 |                   nonStriker: { sourceId: 'app:participant:21' },
  310 |                   bowler: { sourceId: 'app:participant:22' },
  311 |                 },
  312 |               ],
  313 |             },
  314 |           ],
  315 |         },
  316 |       ],
  317 |     });
  318 | 
  319 |     await route.fulfill({
  320 |       status: 202,
  321 |       contentType: 'application/json',
  322 |       body: JSON.stringify({
  323 |         data: {
  324 |           batchReference,
  325 |           status: 'stored',
  326 |           statusUrl: `/api/v1/batches/${batchReference}`,
  327 |           receivedAt: '2026-08-16T09:30:00.000Z',
  328 |         },
  329 |       }),
  330 |     });
  331 |   });
  332 | 
  333 |   await page.goto('/submissions/new');
  334 |   await page.getByRole('radio', { name: /Advanced technical JSON/ }).click();
  335 | 
  336 |   const competitionSelector = page.getByRole('combobox', { name: 'Competition' });
  337 |   const fixtureSelector = page.getByLabel('Fixture', { exact: true });
  338 |   const editor = page.getByLabel('Delivery events JSON');
  339 |   const submitButton = page.getByRole('button', { name: 'Submit events' });
  340 | 
  341 |   await competitionSelector.fill('Exam Comp');
  342 |   await expect(page.getByRole('option', { name: /Example Competition/ })).toBeVisible();
  343 |   await competitionSelector.press('ArrowDown');
  344 |   await competitionSelector.press('Enter');
  345 |   await expect(competitionSelector).toHaveValue('Example Competition');
  346 | 
  347 |   await fixtureSelector.fill('wander');
  348 |   await expect(page.getByRole('option', { name: /Wanderers v Strikers/ })).toBeVisible();
  349 |   await fixtureSelector.press('ArrowDown');
  350 |   await fixtureSelector.press('Enter');
  351 |   await expect(fixtureSelector).toHaveValue(
  352 |     '2026-08-20 — Wanderers v Strikers — Example Competition, 2026 (T20)',
  353 |   );
  354 |   await editor.fill(JSON.stringify(events, null, 2));
  355 | 
  356 |   await submitButton.focus();
  357 |   await page.keyboard.press('Enter');
  358 | 
  359 |   const stagedHeading = page.locator(
  360 |     'h1:focus, h2:focus, h3:focus, h4:focus, h5:focus, h6:focus, [role="heading"]:focus',
  361 |   );
  362 |   await expect(stagedHeading).toBeFocused();
  363 |   await expect(page.getByText(batchReference, { exact: true })).toBeVisible();
  364 |   await expect(page.locator(`a[href="/submissions/batches/${batchReference}"]`)).toHaveAttribute(
  365 |     'href',
  366 |     `/submissions/batches/${batchReference}`,
  367 |   );
  368 |   await expect(page.getByRole('button', { name: 'Save correction' })).toHaveCount(0);
  369 | 
  370 |   const hasHorizontalOverflow = await page.evaluate(
  371 |     () => document.documentElement.scrollWidth > document.documentElement.clientWidth,
  372 |   );
  373 |   expect(hasHorizontalOverflow).toBe(false);
  374 | 
  375 |   const results = await new AxeBuilder({ page }).analyze();
  376 |   const seriousOrCriticalViolations = results.violations.filter(
  377 |     (violation) => violation.impact === 'serious' || violation.impact === 'critical',
  378 |   );
  379 |   expect(seriousOrCriticalViolations).toEqual([]);
  380 | });
  381 | 
  382 | test('technical JSON schema errors remain associated with the editor and receive focus', async ({
  383 |   page,
  384 | }) => {
  385 |   const invalidEvents = events.map((event) => ({
  386 |     ...event,
  387 |     runs: { ...event.runs, total: event.runs.total + 1 },
  388 |   }));
  389 | 
  390 |   await page.goto('/submissions/new');
> 391 |   await page.getByRole('radio', { name: /Advanced technical JSON/ }).click();
      |                                                                      ^ Error: locator.click: Test timeout of 30000ms exceeded.
  392 |   await chooseListedFixture(page);
  393 |   const editor = page.getByLabel('Delivery events JSON');
  394 |   await editor.fill(JSON.stringify(invalidEvents));
  395 |   await page.getByRole('button', { name: 'Submit events' }).click();
  396 | 
  397 |   await expect(page.getByRole('heading', { name: 'Submission rejected' })).toBeFocused();
  398 |   await expect(page.getByText('Total runs must equal off-bat runs plus extras.')).toBeVisible();
  399 |   await expect(editor).toHaveAttribute('aria-invalid', 'true');
  400 |   await expect(editor).toHaveAttribute('aria-describedby', /submission-validation-results/);
  401 | });
  402 | 
  403 | test(
  404 |   'submitter uploads a readable fixture package and receives a durable receipt',
  405 |   { tag: '@mobile' },
  406 |   async ({ page }) => {
  407 |     const uploadedPackage = readableFixturePackage();
  408 |     await page.route('**/api/v1/batches', async (route) => {
  409 |       expect(route.request().method()).toBe('POST');
  410 |       expect(route.request().headers().authorization).toBe('Bearer approved-e2e-token');
  411 |       expect(route.request().headers()['x-competition-id']).toBe('5');
  412 |       expect(route.request().headers()['x-file-name']).toBe('fixture-package.json');
  413 |       // The receipt is mocked, so the body must satisfy the real package contract.
  414 |       const body = route.request().postDataBuffer()?.toString('utf8') ?? '';
  415 |       expect(body).toBe(uploadedPackage);
  416 |       expect(seasonUploadPackageSchema.safeParse(JSON.parse(body)).success).toBe(true);
  417 |       await new Promise((resolve) => setTimeout(resolve, 100));
  418 |       await route.fulfill({
  419 |         status: 202,
  420 |         contentType: 'application/json',
  421 |         body: JSON.stringify({
  422 |           data: {
  423 |             batchReference,
  424 |             status: 'stored',
  425 |             statusUrl: `/api/v1/batches/${batchReference}`,
  426 |             receivedAt: '2026-08-16T09:30:00.000Z',
  427 |           },
  428 |         }),
  429 |       });
  430 |     });
  431 | 
  432 |     await page.route('**/api/v1/batches', async (route) => {
  433 |       if (route.request().method() !== 'GET') return route.fallback();
  434 |       await route.fulfill({
  435 |         status: 200,
  436 |         contentType: 'application/json',
  437 |         body: JSON.stringify({
  438 |           data: [
  439 |             {
  440 |               batchReference,
  441 |               competitionId: '5',
  442 |               status: 'stored',
  443 |               statusUrl: `/api/v1/batches/${batchReference}`,
  444 |               receivedAt: '2026-08-16T09:30:00.000Z',
  445 |               updatedAt: '2026-08-16T09:30:00.000Z',
  446 |               source: {
  447 |                 fileName: 'fixture-package.json',
  448 |                 checksum: null,
  449 |                 packageVersion: '1.0',
  450 |                 submitter: { accountId: '17', displayName: 'Submitter User' },
  451 |               },
  452 |               progress: { total: 0, processed: 0, accepted: 0, rejected: 0 },
  453 |               counts: { accepted: 0, rejected: 0, unresolved: 0, duplicate: 0, conflicting: 0 },
  454 |               lineage: { replacesBatchReference: null, supersededByBatchReference: null },
  455 |               review: null,
  456 |             },
  457 |           ],
  458 |           pagination: { nextCursor: null },
  459 |         }),
  460 |       });
  461 |     });
  462 | 
  463 |     await page.goto('/submissions/new');
  464 |     await chooseListedFixture(page);
  465 |     await expect(page.getByRole('button', { name: 'Propose a new fixture' })).toBeVisible();
  466 |     await expect(
  467 |       page.getByText(/Upload one JSON or CSV spreadsheet package up to 50 MB/),
  468 |     ).toBeVisible();
  469 |     await expect(page.getByText(/You never need a database ID/)).toBeVisible();
  470 |     const fileInput = page.getByLabel('Fixture package', { exact: true });
  471 |     await fileInput.setInputFiles({
  472 |       name: 'fixture-package.json',
  473 |       mimeType: 'application/json',
  474 |       buffer: Buffer.from(uploadedPackage),
  475 |     });
  476 |     await expect(page.getByText(/Selected: fixture-package.json/)).toBeVisible();
  477 |     await page.getByRole('button', { name: 'Upload fixture package' }).click();
  478 |     await expect(
  479 |       page.getByRole('status').filter({ hasText: 'creating its durable receipt' }),
  480 |     ).toBeVisible();
  481 | 
  482 |     await expect(
  483 |       page.locator(
  484 |         'h1:focus, h2:focus, h3:focus, h4:focus, h5:focus, h6:focus, [role="heading"]:focus',
  485 |       ),
  486 |     ).toBeFocused();
  487 |     await expect(page.getByText(batchReference)).toBeVisible();
  488 |     await expect(page.locator(`a[href="/submissions/batches/${batchReference}"]`)).toHaveAttribute(
  489 |       'href',
  490 |       `/submissions/batches/${batchReference}`,
  491 |     );
```