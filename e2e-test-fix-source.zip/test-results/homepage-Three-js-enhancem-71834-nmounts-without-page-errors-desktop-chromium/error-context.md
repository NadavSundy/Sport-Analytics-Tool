# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: homepage.spec.ts >> Three.js enhancement pauses off-screen and unmounts without page errors
- Location: tests/e2e/homepage.spec.ts:139:5

# Error details

```
Error: expect(locator).toHaveAttribute(expected) failed

Locator:  locator('[data-hero-enhancement]')
Expected: "three"
Received: "fallback"
Timeout:  5000ms

Call log:
  - Expect "toHaveAttribute" with timeout 5000ms
  - waiting for locator('[data-hero-enhancement]')
    14 × locator resolved to <div class="home-hero__visual" data-hero-enhancement="fallback">…</div>
       - unexpected value "fallback"

```

```yaml
- text: Illustrative delivery
- strong: Event → derived values
```

# Test source

```ts
  67  |     }
  68  | 
  69  |     if (!isMobile) {
  70  |       const viewport = page.viewportSize();
  71  |       if (!viewport) {
  72  |         throw new Error('The desktop viewport is unavailable.');
  73  |       }
  74  |       const session = await page.context().newCDPSession(page);
  75  |       await session.send('Emulation.setDeviceMetricsOverride', {
  76  |         width: Math.floor(viewport.width / 2),
  77  |         height: viewport.height,
  78  |         deviceScaleFactor: 2,
  79  |         mobile: false,
  80  |       });
  81  |       await expect(
  82  |         page.getByRole('heading', { level: 1, name: 'The game, measured ball by ball.' }),
  83  |       ).toBeVisible();
  84  |       await expectNoHorizontalOverflow(page);
  85  |       await session.send('Emulation.clearDeviceMetricsOverride');
  86  |       await session.detach();
  87  |     }
  88  |   },
  89  | );
  90  | 
  91  | test('homepage remains complete with reduced motion and without WebGL', async ({ page }) => {
  92  |   await page.emulateMedia({ reducedMotion: 'reduce' });
  93  |   await page.goto('/');
  94  | 
  95  |   const visual = page.locator('[data-hero-enhancement]');
  96  |   await expect(visual).toHaveAttribute('data-hero-enhancement', 'fallback');
  97  |   await expect(visual.locator('canvas')).toHaveCount(0);
  98  |   await expect(page.getByTestId('hero-scene-fallback')).toBeVisible();
  99  |   await expect(page.getByText('Event → derived values')).toBeVisible();
  100 |   expect(
  101 |     await visual.evaluate((element) =>
  102 |       element
  103 |         .getAnimations({ subtree: true })
  104 |         .some((animation) => animation.playState === 'running'),
  105 |     ),
  106 |   ).toBe(false);
  107 | 
  108 |   await page.addInitScript(() => {
  109 |     Object.defineProperty(window, 'WebGLRenderingContext', {
  110 |       configurable: true,
  111 |       value: undefined,
  112 |     });
  113 |   });
  114 |   await page.emulateMedia({ reducedMotion: 'no-preference' });
  115 |   await page.reload();
  116 | 
  117 |   await expect(visual).toHaveAttribute('data-hero-enhancement', 'fallback');
  118 |   await expect(visual.locator('canvas')).toHaveCount(0);
  119 |   await expect(page.getByText('Event → derived values')).toBeVisible();
  120 | });
  121 | 
  122 | test('primary homepage journey works from the keyboard', async ({ page }) => {
  123 |   await page.goto('/');
  124 |   const primaryLink = page.getByRole('link', { name: 'Browse fixtures' }).first();
  125 | 
  126 |   for (let index = 0; index < 16; index += 1) {
  127 |     await page.keyboard.press('Tab');
  128 |     if (await primaryLink.evaluate((element) => element === document.activeElement)) {
  129 |       break;
  130 |     }
  131 |   }
  132 | 
  133 |   await expect(primaryLink).toBeFocused();
  134 |   await page.keyboard.press('Enter');
  135 |   await expect(page).toHaveURL(/\/fixtures$/);
  136 |   await expect(page.getByRole('heading', { level: 1, name: 'Fixtures' })).toBeVisible();
  137 | });
  138 | 
  139 | test('Three.js enhancement pauses off-screen and unmounts without page errors', async ({
  140 |   page,
  141 | }) => {
  142 |   const pageErrors: string[] = [];
  143 |   page.on('pageerror', (error) => pageErrors.push(error.stack ?? error.message));
  144 |   await page.addInitScript(() => {
  145 |     const diagnostics = window as typeof window & { __heroContextLosses?: number };
  146 |     diagnostics.__heroContextLosses = 0;
  147 |     document.addEventListener(
  148 |       'webglcontextlost',
  149 |       (event) => {
  150 |         if (event.target instanceof HTMLCanvasElement && event.target.matches('.hero-scene')) {
  151 |           diagnostics.__heroContextLosses = (diagnostics.__heroContextLosses ?? 0) + 1;
  152 |         }
  153 |       },
  154 |       true,
  155 |     );
  156 |   });
  157 |   await page.goto('/');
  158 | 
  159 |   const visual = page.locator('[data-hero-enhancement]');
  160 |   const canvas = visual.locator('canvas');
  161 |   const webglAvailable = await hasWebGL(page);
  162 | 
  163 |   if (!webglAvailable) {
  164 |     test.skip(true, 'WebGL is unavailable in this browser runtime.');
  165 |   }
  166 | 
> 167 |   await expect(visual).toHaveAttribute('data-hero-enhancement', 'three');
      |                        ^ Error: expect(locator).toHaveAttribute(expected) failed
  168 |   await expect(canvas).toHaveCount(1);
  169 |   await expect(canvas).toHaveAttribute('data-context-state', 'ready');
  170 |   await expect(canvas).toHaveAttribute('data-animation-state', /running|idle/);
  171 |   await page.waitForTimeout(3_000);
  172 |   expect(
  173 |     await page.evaluate(
  174 |       () => (window as typeof window & { __heroContextLosses?: number }).__heroContextLosses,
  175 |     ),
  176 |   ).toBe(0);
  177 |   await expect(canvas).toHaveAttribute('data-animation-state', /running|idle/);
  178 |   await page.locator('.home-cta').scrollIntoViewIfNeeded();
  179 |   await expect(canvas).toHaveAttribute('data-animation-state', 'paused');
  180 | 
  181 |   await page.getByRole('link', { name: 'Browse fixtures' }).last().click();
  182 |   await expect(page.getByRole('heading', { level: 1, name: 'Fixtures' })).toBeVisible();
  183 |   await expect(page.locator('.hero-scene')).toHaveCount(0);
  184 |   expect(pageErrors).toEqual([]);
  185 | });
  186 | 
  187 | test('Three.js enhancement reveals the fallback during context loss and restores in place', async ({
  188 |   page,
  189 | }) => {
  190 |   const pageErrors: string[] = [];
  191 |   page.on('pageerror', (error) => pageErrors.push(error.stack ?? error.message));
  192 |   await page.goto('/');
  193 | 
  194 |   const webglAvailable = await hasWebGL(page);
  195 |   test.skip(!webglAvailable, 'WebGL is unavailable in this browser runtime.');
  196 | 
  197 |   const visual = page.locator('[data-hero-enhancement]');
  198 |   const canvas = visual.locator('.hero-scene');
  199 | 
  200 |   await expect(
  201 |     canvas,
  202 |     'Three.js should initialise when the browser runtime reports WebGL support.',
  203 |   ).toHaveAttribute('data-context-state', 'ready', {
  204 |     timeout: THREE_INITIALISATION_TIMEOUT_MS,
  205 |   });
  206 |   await expect(visual).toHaveAttribute('data-hero-enhancement', 'three');
  207 | 
  208 |   const canSimulateContextLoss = await canvas.evaluate((element) => {
  209 |     const context = element.getContext('webgl2') ?? element.getContext('webgl');
  210 |     const extension = context?.getExtension('WEBGL_lose_context');
  211 |     if (!extension) {
  212 |       return false;
  213 |     }
  214 | 
  215 |     element.dataset.rendererInstance = 'original';
  216 |     const diagnostics = window as typeof window & { __restoreHeroContext?: () => void };
  217 |     diagnostics.__restoreHeroContext = () => extension.restoreContext();
  218 |     extension.loseContext();
  219 |     return true;
  220 |   });
  221 |   test.skip(!canSimulateContextLoss, 'WEBGL_lose_context is unavailable in this browser runtime.');
  222 | 
  223 |   await expect(visual).toHaveAttribute('data-hero-enhancement', 'fallback');
  224 |   await expect(canvas).toHaveAttribute('data-context-state', 'lost');
  225 |   await expect(canvas).toHaveAttribute('data-animation-state', 'context-lost');
  226 |   await expect(canvas).toHaveCSS('opacity', '0');
  227 |   await expect(canvas).toHaveCount(1);
  228 | 
  229 |   await page.evaluate(() => {
  230 |     (window as typeof window & { __restoreHeroContext?: () => void }).__restoreHeroContext?.();
  231 |   });
  232 | 
  233 |   await expect(visual).toHaveAttribute('data-hero-enhancement', 'three');
  234 |   await expect(canvas).toHaveAttribute('data-context-state', 'ready');
  235 |   await expect(canvas).toHaveAttribute('data-animation-state', /running|idle/);
  236 |   await expect(canvas).toHaveAttribute('data-renderer-instance', 'original');
  237 |   await expect(canvas).toHaveCount(1);
  238 |   expect(pageErrors).toEqual([]);
  239 | });
  240 | 
```