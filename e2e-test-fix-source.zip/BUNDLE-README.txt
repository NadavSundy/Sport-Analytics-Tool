E2E repair source bundle for PR #825 / issue #797.
Contains relevant tracked frontend source, Playwright tests and failure context text.
DO NOT INCLUDE secrets, runtime .env files, Playwright storage state or node_modules.
This is an evidence bundle, not a patch and not proof that tests pass.
