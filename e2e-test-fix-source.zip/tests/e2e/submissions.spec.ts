import { readFileSync } from 'node:fs';

import AxeBuilder from '@axe-core/playwright';
import { expect, test, type Page } from '@playwright/test';
import { seasonUploadPackageSchema } from '@sport-analytics/contracts';

const fixture = {
  fixtureId: '7',
  competitionId: '5',
  competitionName: 'Example Competition',
  seasonId: '15',
  season: '2026',
  seasonLabel: '2026',
  competitors: [
    { competitorId: '20', name: 'Wanderers' },
    { competitorId: '21', name: 'Strikers' },
  ],
  matchType: 'T20',
  teamType: 'international',
  gender: 'female',
  ballsPerOver: 6,
  scheduledOvers: 20,
  venue: null,
  toss: null,
  startDate: '2026-08-20',
  endDate: '2026-08-20',
};

const events = [
  {
    eventId: '123e4567-e89b-42d3-a456-426614174000',
    inningsId: '10',
    sequenceNumber: 1,
    overNumber: 0,
    positionInOver: 0,
    ballNumber: '0.1',
    strikerId: '20',
    nonStrikerId: '21',
    bowlerId: '22',
    runs: { offBat: 4, extras: 0, total: 4, nonBoundary: false },
    extras: {},
    wickets: [],
  },
];

const batchReference = '123e4567-e89b-42d3-a456-426614174000';

/**
 * The downloadable JSON template completed with readable names for the listed
 * fixture only, as the guided page asks (#500). Every placeholder must exist, so
 * a template change cannot quietly make the journey vacuous.
 */
function readableFixturePackage(): string {
  let text = readFileSync('apps/frontend/public/season-upload-template.json', 'utf8');
  const readableValues: [placeholder: string, value: string][] = [
    ['"Competition name"', `"${fixture.competitionName}"`],
    ['"2026-03-14"', `"${fixture.startDate}"`],
    ['"Home team"', '"Wanderers"'],
    ['"Away team"', '"Strikers"'],
  ];
  for (const [placeholder, value] of readableValues) {
    expect(text).toContain(placeholder);
    text = text.replaceAll(placeholder, value);
  }
  return text;
}

/**
 * Choose the competition and then its fixture. Since #779 the page loads
 * fixtures only for the competition that has been chosen, so the fixture
 * selector starts empty and disabled and a journey that reaches a submit has to
 * make the selection a submitter would make.
 */
async function chooseListedFixture(page: Page) {
  const competitionSelector = page.getByRole('combobox', { name: 'Competition' });
  const fixtureSelector = page.getByLabel('Fixture', { exact: true });

  await expect(fixtureSelector).toBeDisabled();
  await page.getByRole('button', { name: 'Show competition options' }).click();
  await page.getByRole('option', { name: 'Example Competition' }).click();
  await expect(competitionSelector).toHaveValue('Example Competition');

  await page.getByRole('button', { name: 'Show fixture options' }).click();
  await page
    .getByRole('option', {
      name: /2026-08-20 — Wanderers v Strikers — Example Competition, 2026 \(T20\)/,
    })
    .click();
  await expect(fixtureSelector).toHaveValue(
    '2026-08-20 — Wanderers v Strikers — Example Competition, 2026 (T20)',
  );
}

test.beforeEach(async ({ page }) => {
  await page.addInitScript(() => {
    const now = Math.floor(Date.now() / 1_000);
    window.localStorage.setItem(
      'sb-e2e-auth-token',
      JSON.stringify({
        access_token: 'approved-e2e-token',
        refresh_token: 'managed-by-supabase',
        expires_in: 3_600,
        expires_at: now + 3_600,
        token_type: 'bearer',
        user: {
          id: 'approved-user',
          aud: 'authenticated',
          role: 'authenticated',
          email: 'submitter@example.com',
          app_metadata: {},
          user_metadata: {},
          identities: [],
          created_at: '2026-08-16T00:00:00.000Z',
        },
      }),
    );
  });

  await page.route('**/api/v1/auth/me', async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        user: {
          id: '17',
          subject: 'approved-user',
          displayName: 'Submitter User',
          role: 'submitter',
          approvalState: 'approved',
          requestedCompetition: { competitionId: '5', name: 'Premier T20' },
          competitionIds: ['5'],
        },
      }),
    });
  });

  await page.route('**/api/v1/competitions?*', async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({
        data: [
          { competitionId: '5', name: 'Premier T20' },
          { competitionId: '8', name: 'University League' },
        ],
        pagination: { nextCursor: null },
      }),
    });
  });

  await page.route('**/api/v1/competitions/5', async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ data: { competitionId: '5', name: 'Example Competition' } }),
    });
  });

  await page.route('**/api/v1/fixtures?**', async (route) => {
    await route.fulfill({
      status: 200,
      contentType: 'application/json',
      body: JSON.stringify({ data: [fixture], pagination: { nextCursor: null, totalPages: 1 } }),
    });
  });
});

test('Manage Submission opens the unified submission workflow', async ({ page }) => {
  await page.goto('/account/overview');
  await page.getByRole('button', { name: 'Manage Submission' }).click();
  await page.getByRole('link', { name: 'Submit data' }).click();

  await expect(page).toHaveURL(/\/submissions\/new$/);
  await expect(page.getByRole('heading', { name: 'Submit data' })).toBeVisible();
  await expect(page.getByRole('radio', { name: /Single fixture/ })).toBeChecked();
  await expect(page.getByRole('radio', { name: /Season/ })).toBeVisible();
  await expect(page.getByRole('radio', { name: /Back catalogue/ })).toBeVisible();
  await expect(page.getByRole('radio', { name: /Advanced technical JSON/ })).toBeVisible();
  await expect(page.getByRole('link', { name: 'Upload a batch' })).toHaveCount(0);

  // #500: the guided scopes and the identifier-based mode are separate groups,
  // and the default guided path shows no JSON editor.
  const guided = page.getByRole('group', { name: /Guided upload/ });
  const advanced = page.getByRole('group', { name: /application identifiers required/ });
  await expect(guided.getByRole('radio')).toHaveCount(3);
  await expect(guided.getByRole('radio', { name: /Advanced technical JSON/ })).toHaveCount(0);
  await expect(advanced.getByRole('radio', { name: /Advanced technical JSON/ })).toBeVisible();
  await expect(page.getByLabel('Delivery events JSON')).toHaveCount(0);
});

test('submission workspace uses the centred responsive content boundary', async ({ page }) => {
  await page.goto('/submissions/new');

  for (const viewport of [
    { width: 375, expectedWidth: 351 },
    { width: 768, expectedWidth: 720 },
    { width: 1440, expectedWidth: 1200 },
    { width: 1920, expectedWidth: 1200 },
  ]) {
    await page.setViewportSize({ width: viewport.width, height: 900 });

    const layout = await page.locator('.submission-page').evaluate((element) => {
      const rect = element.getBoundingClientRect();
      return {
        left: Math.round(rect.left),
        right: Math.round(window.innerWidth - rect.right),
        width: Math.round(rect.width),
        overflows: document.documentElement.scrollWidth > document.documentElement.clientWidth,
      };
    });

    expect(layout.width).toBe(viewport.expectedWidth);
    expect(Math.abs(layout.left - layout.right)).toBeLessThanOrEqual(1);
    expect(layout.overflows).toBe(false);
  }
});

test('submitter originates a new fixture proposal for reviewer resolution', async ({ page }) => {
  await page.route('**/api/v1/batches', async (route) => {
    const request = route.request();
    expect(request.method()).toBe('POST');
    expect(request.headers()['x-batch-package-version']).toBe('1.1');
    expect(request.headers()['x-competition-id']).toBe('5');
    expect(request.postDataJSON()).toMatchObject({
      contractVersion: '1.1',
      competition: { context: { name: 'Example Competition' } },
      season: { context: { name: '2026' } },
      fixtures: [
        {
          sourceId: expect.stringMatching(/^submitter:fixture:/),
          context: {
            date: fixture.startDate,
            teams: [{ context: { name: 'Wanderers' } }, { context: { name: 'Strikers' } }],
          },
          proposal: {
            endDate: fixture.startDate,
            matchType: 'T20',
            teamType: 'club',
            gender: 'female',
            ballsPerOver: 6,
            outcome: 'won',
            winner: 'Wanderers',
            sourceVersion: '1',
            sourceRevision: 0,
          },
        },
      ],
    });
    expect(seasonUploadPackageSchema.safeParse(request.postDataJSON()).success).toBe(true);
    await route.fulfill({
      status: 202,
      contentType: 'application/json',
      body: JSON.stringify({
        data: {
          batchReference,
          status: 'stored',
          statusUrl: `/api/v1/batches/${batchReference}`,
          receivedAt: '2026-09-15T09:30:00.000Z',
        },
      }),
    });
  });

  await page.goto('/submissions/new');
  await page.getByRole('button', { name: 'Propose a new fixture' }).click();
  await expect(page.getByRole('group', { name: 'New fixture metadata' })).toBeVisible();
  await expect(page.getByRole('combobox', { name: 'Competition' })).toHaveValue(
    'Example Competition',
  );
  await page.getByLabel('Season name').fill('2026');
  await page.getByLabel('Fixture date').fill(fixture.startDate);
  await page.getByLabel('Home team name').fill('Wanderers');
  await page.getByLabel('Away team name').fill('Strikers');
  await expect(page.getByLabel('Match type')).toHaveValue('T20');
  await page.getByLabel('Team type').selectOption('club');
  await page.getByLabel('Gender').selectOption('female');
  await page.getByLabel('Outcome').selectOption('won');
  await page.getByLabel('Winning team').selectOption('Wanderers');
  await page.getByLabel('Fixture package').setInputFiles({
    name: 'new-fixture.json',
    mimeType: 'application/json',
    buffer: Buffer.from(readableFixturePackage()),
  });
  await page.getByRole('button', { name: 'Upload fixture package' }).click();

  await expect(page.getByRole('heading', { name: 'Fixture upload received' })).toBeFocused();
  await expect(page.getByText(batchReference, { exact: true })).toBeVisible();
  await expect(page.getByText(/administrator can create the canonical fixture/i)).toBeVisible();
});

test('submitter stages advanced technical JSON with a keyboard', async ({ page }) => {
  await page.route('**/api/v1/batches', async (route) => {
    const request = route.request();
    expect(request.method()).toBe('POST');
    expect(request.headers()['x-competition-id']).toBe('5');
    expect(request.headers()['x-file-name']).toBe('technical-7.json');
    expect(request.postDataJSON()).toMatchObject({
      contractVersion: '1.0',
      fixtures: [
        {
          sourceId: 'app:fixture:7',
          innings: [
            {
              sourceId: 'app:innings:10',
              events: [
                {
                  eventId: `app:delivery:${events[0]!.eventId}`,
                  striker: { sourceId: 'app:participant:20' },
                  nonStriker: { sourceId: 'app:participant:21' },
                  bowler: { sourceId: 'app:participant:22' },
                },
              ],
            },
          ],
        },
      ],
    });

    await route.fulfill({
      status: 202,
      contentType: 'application/json',
      body: JSON.stringify({
        data: {
          batchReference,
          status: 'stored',
          statusUrl: `/api/v1/batches/${batchReference}`,
          receivedAt: '2026-08-16T09:30:00.000Z',
        },
      }),
    });
  });

  await page.goto('/submissions/new');
  await page.getByRole('radio', { name: /Advanced technical JSON/ }).click();

  const competitionSelector = page.getByRole('combobox', { name: 'Competition' });
  const fixtureSelector = page.getByLabel('Fixture', { exact: true });
  const editor = page.getByLabel('Delivery events JSON');
  const submitButton = page.getByRole('button', { name: 'Submit events' });

  await competitionSelector.fill('Exam Comp');
  await expect(page.getByRole('option', { name: /Example Competition/ })).toBeVisible();
  await competitionSelector.press('ArrowDown');
  await competitionSelector.press('Enter');
  await expect(competitionSelector).toHaveValue('Example Competition');

  await fixtureSelector.fill('wander');
  await expect(page.getByRole('option', { name: /Wanderers v Strikers/ })).toBeVisible();
  await fixtureSelector.press('ArrowDown');
  await fixtureSelector.press('Enter');
  await expect(fixtureSelector).toHaveValue(
    '2026-08-20 — Wanderers v Strikers — Example Competition, 2026 (T20)',
  );
  await editor.fill(JSON.stringify(events, null, 2));

  await submitButton.focus();
  await page.keyboard.press('Enter');

  const stagedHeading = page.locator(
    'h1:focus, h2:focus, h3:focus, h4:focus, h5:focus, h6:focus, [role="heading"]:focus',
  );
  await expect(stagedHeading).toBeFocused();
  await expect(page.getByText(batchReference, { exact: true })).toBeVisible();
  await expect(page.locator(`a[href="/submissions/batches/${batchReference}"]`)).toHaveAttribute(
    'href',
    `/submissions/batches/${batchReference}`,
  );
  await expect(page.getByRole('button', { name: 'Save correction' })).toHaveCount(0);

  const hasHorizontalOverflow = await page.evaluate(
    () => document.documentElement.scrollWidth > document.documentElement.clientWidth,
  );
  expect(hasHorizontalOverflow).toBe(false);

  const results = await new AxeBuilder({ page }).analyze();
  const seriousOrCriticalViolations = results.violations.filter(
    (violation) => violation.impact === 'serious' || violation.impact === 'critical',
  );
  expect(seriousOrCriticalViolations).toEqual([]);
});

test('technical JSON schema errors remain associated with the editor and receive focus', async ({
  page,
}) => {
  const invalidEvents = events.map((event) => ({
    ...event,
    runs: { ...event.runs, total: event.runs.total + 1 },
  }));

  await page.goto('/submissions/new');
  await page.getByRole('radio', { name: /Advanced technical JSON/ }).click();
  await chooseListedFixture(page);
  const editor = page.getByLabel('Delivery events JSON');
  await editor.fill(JSON.stringify(invalidEvents));
  await page.getByRole('button', { name: 'Submit events' }).click();

  await expect(page.getByRole('heading', { name: 'Submission rejected' })).toBeFocused();
  await expect(page.getByText('Total runs must equal off-bat runs plus extras.')).toBeVisible();
  await expect(editor).toHaveAttribute('aria-invalid', 'true');
  await expect(editor).toHaveAttribute('aria-describedby', /submission-validation-results/);
});

test(
  'submitter uploads a readable fixture package and receives a durable receipt',
  { tag: '@mobile' },
  async ({ page }) => {
    const uploadedPackage = readableFixturePackage();
    await page.route('**/api/v1/batches', async (route) => {
      expect(route.request().method()).toBe('POST');
      expect(route.request().headers().authorization).toBe('Bearer approved-e2e-token');
      expect(route.request().headers()['x-competition-id']).toBe('5');
      expect(route.request().headers()['x-file-name']).toBe('fixture-package.json');
      // The receipt is mocked, so the body must satisfy the real package contract.
      const body = route.request().postDataBuffer()?.toString('utf8') ?? '';
      expect(body).toBe(uploadedPackage);
      expect(seasonUploadPackageSchema.safeParse(JSON.parse(body)).success).toBe(true);
      await new Promise((resolve) => setTimeout(resolve, 100));
      await route.fulfill({
        status: 202,
        contentType: 'application/json',
        body: JSON.stringify({
          data: {
            batchReference,
            status: 'stored',
            statusUrl: `/api/v1/batches/${batchReference}`,
            receivedAt: '2026-08-16T09:30:00.000Z',
          },
        }),
      });
    });

    await page.route('**/api/v1/batches', async (route) => {
      if (route.request().method() !== 'GET') return route.fallback();
      await route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          data: [
            {
              batchReference,
              competitionId: '5',
              status: 'stored',
              statusUrl: `/api/v1/batches/${batchReference}`,
              receivedAt: '2026-08-16T09:30:00.000Z',
              updatedAt: '2026-08-16T09:30:00.000Z',
              source: {
                fileName: 'fixture-package.json',
                checksum: null,
                packageVersion: '1.0',
                submitter: { accountId: '17', displayName: 'Submitter User' },
              },
              progress: { total: 0, processed: 0, accepted: 0, rejected: 0 },
              counts: { accepted: 0, rejected: 0, unresolved: 0, duplicate: 0, conflicting: 0 },
              lineage: { replacesBatchReference: null, supersededByBatchReference: null },
              review: null,
            },
          ],
          pagination: { nextCursor: null },
        }),
      });
    });

    await page.goto('/submissions/new');
    await chooseListedFixture(page);
    await expect(page.getByRole('button', { name: 'Propose a new fixture' })).toBeVisible();
    await expect(
      page.getByText(/Upload one JSON or CSV spreadsheet package up to 50 MB/),
    ).toBeVisible();
    await expect(page.getByText(/You never need a database ID/)).toBeVisible();
    const fileInput = page.getByLabel('Fixture package', { exact: true });
    await fileInput.setInputFiles({
      name: 'fixture-package.json',
      mimeType: 'application/json',
      buffer: Buffer.from(uploadedPackage),
    });
    await expect(page.getByText(/Selected: fixture-package.json/)).toBeVisible();
    await page.getByRole('button', { name: 'Upload fixture package' }).click();
    await expect(
      page.getByRole('status').filter({ hasText: 'creating its durable receipt' }),
    ).toBeVisible();

    await expect(
      page.locator(
        'h1:focus, h2:focus, h3:focus, h4:focus, h5:focus, h6:focus, [role="heading"]:focus',
      ),
    ).toBeFocused();
    await expect(page.getByText(batchReference)).toBeVisible();
    await expect(page.locator(`a[href="/submissions/batches/${batchReference}"]`)).toHaveAttribute(
      'href',
      `/submissions/batches/${batchReference}`,
    );
    await expect(page.getByRole('button', { name: 'Upload fixture package' })).toHaveCount(0);
    await page
      .locator('.submission-result')
      .getByRole('link', { name: 'View submission history' })
      .click();
    await expect(page).toHaveURL(/\/submissions\/batches$/);
    await expect(page.getByRole('link', { name: 'fixture-package.json' })).toBeVisible();
    await expect(page.getByText(batchReference)).toBeVisible();
    const hasHorizontalOverflow = await page.evaluate(
      () => document.documentElement.scrollWidth > document.documentElement.clientWidth,
    );
    expect(hasHorizontalOverflow).toBe(false);
    const results = await new AxeBuilder({ page }).analyze();
    expect(
      results.violations.filter(
        (violation) => violation.impact === 'serious' || violation.impact === 'critical',
      ),
    ).toEqual([]);
  },
);

test('file validation identifies a rejected CSV row and returns focus to the result', async ({
  page,
}) => {
  await page.route('**/api/v1/batches', async (route) => {
    await route.fulfill({
      status: 422,
      contentType: 'application/json',
      body: JSON.stringify({
        error: {
          code: 'VALIDATION_FAILED',
          message: 'The uploaded submission file is invalid.',
          details: [
            {
              code: 'INVALID_FILE_ROW',
              message: 'Expected number, received string',
              field: 'events.0.runs.total',
              eventIndex: 0,
            },
          ],
        },
      }),
    });
  });

  await page.goto('/submissions/new');
  await chooseListedFixture(page);
  const fileInput = page.getByLabel('Fixture package', { exact: true });
  await fileInput.setInputFiles({
    name: 'events.csv',
    mimeType: 'text/csv',
    buffer: Buffer.from('fixtureDate,homeTeamName,awayTeamName\n2026-08-20,Wanderers,Strikers\n'),
  });
  await page.getByRole('button', { name: 'Upload fixture package' }).click();

  await expect(page.getByRole('heading', { name: 'Submission rejected' })).toBeFocused();
  await expect(page.getByText('Row 1 — Total runs')).toBeVisible();
  await expect(page.getByText('Use a number here instead of text.')).toBeVisible();
  await expect(page.getByText('Technical details')).toBeVisible();
  await expect(fileInput).toHaveAttribute('aria-invalid', 'true');
});

test(
  'submitter uploads and resolves a batch through the responsive guided workflow',
  { tag: '@mobile' },
  async ({ page }) => {
    await page.route('**/api/v1/competitions/5', (route) =>
      route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({ data: { competitionId: '5', name: 'Premier T20' } }),
      }),
    );
    await page.route('**/api/v1/seasons?**', (route) =>
      route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          data: [
            {
              seasonId: '15',
              competitionId: '5',
              competitionName: 'Premier T20',
              label: '2026/27',
            },
          ],
          pagination: { nextCursor: null },
        }),
      }),
    );
    await page.route('**/api/v1/batches', async (route) => {
      expect(route.request().headers()['x-competition-id']).toBe('5');
      expect(route.request().headers()['x-file-name']).toBe('back-catalogue.csv');
      await new Promise((resolve) => setTimeout(resolve, 100));
      await route.fulfill({
        status: 202,
        contentType: 'application/json',
        body: JSON.stringify({
          data: {
            batchReference,
            status: 'stored',
            statusUrl: `/api/v1/batches/${batchReference}`,
            receivedAt: '2026-09-08T09:30:00.000Z',
          },
        }),
      });
    });

    await page.goto('/submissions/batches/new');
    await expect(page).toHaveURL(/\/submissions\/new$/);
    await page.getByRole('radio', { name: /Back catalogue/ }).click();
    await expect(page.getByLabel('Competition', { exact: true })).toHaveValue('Premier T20');
    await expect(page.getByLabel('Season context')).toHaveCount(0);
    await page.getByLabel('Back catalogue package').setInputFiles({
      name: 'back-catalogue.csv',
      mimeType: 'text/csv',
      buffer: Buffer.from('contractVersion,packageId\n1.0,provider:package:2026'),
    });
    await page.getByRole('button', { name: 'Upload back catalogue package' }).click();
    await expect(page.getByRole('progressbar', { name: 'Upload progress' })).toBeVisible();
    await expect(
      page.locator(
        'h1:focus, h2:focus, h3:focus, h4:focus, h5:focus, h6:focus, [role="heading"]:focus',
      ),
    ).toBeFocused();
    await expect(page.locator(`a[href="/submissions/batches/${batchReference}"]`)).toBeVisible();

    await page.route(`**/api/v1/batches/${batchReference}/report`, (route) =>
      route.fulfill({
        status: 200,
        contentType: 'application/json',
        body: JSON.stringify({
          data: {
            batch: {
              batchReference,
              competitionId: '5',
              status: 'rejected',
              statusUrl: `/api/v1/batches/${batchReference}`,
              receivedAt: '2026-09-08T09:30:00.000Z',
              updatedAt: '2026-09-08T09:35:00.000Z',
              source: {
                fileName: 'back-catalogue.csv',
                checksum: 'a'.repeat(64),
                packageVersion: '1.0',
                submitter: { accountId: '17', displayName: 'E2E Submitter' },
              },
              progress: { total: 1, processed: 1, accepted: 0, rejected: 1 },
              counts: { accepted: 0, rejected: 1, unresolved: 1, duplicate: 0, conflicting: 0 },
              lineage: { replacesBatchReference: null, supersededByBatchReference: null },
              review: null,
            },
            errorGroups: [{ ruleCode: 'REFERENCE_AMBIGUOUS', count: 1 }],
            reviewSummary: {
              validation: {
                accepted: 0,
                rejected: 1,
                blockingErrors: 0,
                duplicate: 0,
                conflicting: 0,
              },
              resolution: { resolved: 0, ambiguous: 1, unresolved: 0, invalid: 0, proposed: 1 },
              approvalBlocked: true,
              blockingReasons: ['Ambiguous references remain.'],
            },
            fixtureSummaries: [
              {
                fixtureId: null,
                label: 'Fixture unresolved',
                total: 1,
                accepted: 0,
                rejected: 1,
                unresolved: 1,
              },
            ],
            participantOnboarding: [],
            acceptedSamples: [],
            blockingItems: [],
            items: [
              {
                ordinal: 0,
                outcome: 'unresolved',
                location: {
                  filePath: 'back-catalogue.csv',
                  sheetName: 'Events',
                  rowNumber: 2,
                  jsonPath: 'striker',
                  ordinal: 0,
                },
                context: {
                  eventReference: 'provider:event:1',
                  fixtureId: null,
                  fixtureLabel: null,
                  inningsId: null,
                  overNumber: 0,
                  positionInOver: 1,
                  description: 'Premier T20, Wanderers v Strikers, over 0 delivery 1.',
                },
                stagedRecordId: null,
                acceptedRecordId: null,
                errors: [
                  {
                    ruleCode: 'REFERENCE_AMBIGUOUS',
                    message: 'More than one participant is named A. Smith.',
                    location: {
                      filePath: 'back-catalogue.csv',
                      sheetName: 'Events',
                      rowNumber: 2,
                      jsonPath: 'striker',
                      ordinal: 0,
                    },
                    context: {
                      eventReference: 'provider:event:1',
                      fixtureId: null,
                      fixtureLabel: null,
                      inningsId: null,
                      overNumber: 0,
                      positionInOver: 1,
                      description: 'Premier T20, Wanderers v Strikers, over 0 delivery 1.',
                    },
                  },
                ],
                referenceResolutions: [
                  {
                    referencePath: 'events.0.striker',
                    entityType: 'participant',
                    state: 'ambiguous',
                    submittedReference: { name: 'A. Smith' },
                    reason: 'Two participants have this alias.',
                    requiredAction: 'select_candidate',
                    candidates: [
                      {
                        candidateReference: '223e4567-e89b-42d3-a456-426614174000',
                        label: 'Alex Smith — Wanderers, 2026/27',
                      },
                    ],
                  },
                ],
              },
            ],
            pagination: { nextCursor: null },
            downloadUrl: `/api/v1/batches/${batchReference}/report/download`,
          },
        }),
      }),
    );
    await page.route(`**/api/v1/batches/${batchReference}/reference-mappings`, (route) =>
      route.fulfill({
        status: 202,
        contentType: 'application/json',
        body: JSON.stringify({
          data: {
            batchReference,
            decisionReference: '323e4567-e89b-42d3-a456-426614174000',
            status: 'queued',
            statusUrl: `/api/v1/batches/${batchReference}`,
            submittedAt: '2026-09-08T09:40:00.000Z',
          },
        }),
      }),
    );

    await page.locator(`a[href="/submissions/batches/${batchReference}"]`).click();
    await expect(page.getByText('More than one match was found (1)')).toBeVisible();
    await expect(
      page.getByText(
        'More than one participant is named A. Smith. Choose the correct match before continuing.',
      ),
    ).toBeVisible();
    await expect(page.getByText('Technical validation details')).toBeVisible();
    await expect(page.getByLabel('Choose the matching participant')).toHaveValue(
      '223e4567-e89b-42d3-a456-426614174000',
    );
    const mapButton = page.getByRole('button', { name: 'Use selected match' });
    await mapButton.focus();
    await page.keyboard.press('Enter');
    await expect(page.getByRole('button', { name: 'Match queued' })).toBeDisabled();
    await expect(page.getByText(/Background validation continues after you leave/)).toBeVisible();

    const hasHorizontalOverflow = await page.evaluate(
      () => document.documentElement.scrollWidth > document.documentElement.clientWidth,
    );
    expect(hasHorizontalOverflow).toBe(false);
    const results = await new AxeBuilder({ page }).analyze();
    expect(
      results.violations.filter(
        (violation) => violation.impact === 'serious' || violation.impact === 'critical',
      ),
    ).toEqual([]);
  },
);
